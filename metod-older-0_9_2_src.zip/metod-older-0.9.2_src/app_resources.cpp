#include"app_resources.h"
extern SDL_Surface *MainScreen;
extern int scrWidth;
extern int scrHeight;
extern int TileWidth;

tileSequences* newTileSequencesFrom( tileSet *ts, int id ) {
  tileSequences *t = new tileSequences;
  t->ts = ts;
 // t->createSeq( 0, 0 );
  t->createSeq();
//  t->collisionCheck = true;
  t->fullCollisionCheck = true;
  t->collisionPercentage = SHOT_COLLISION_PERCENT;
// t->useCounter = true;
//  t->stop = true;
 // t->stopAtCollision = false;
  t->eraseAtEndThread = true;
  t->loopedAnimation = false;
  t->id = id;
  return t;
}

void readFile( char *file, char **buf, long &fSize ) {
  FILE *f;

  fSize = 0;

  f = fopen( file, "rb" );
  if( f == NULL ) {
    printf( "Error: Can not read file %s", file );
    exit( EXIT_FAILURE );

  }

  fseek( f , 0L , SEEK_END);
  fSize = ftell( f );
  rewind( f );

  *buf = new char [fSize + 1];
  (*buf)[ fSize ] = 0;
  if( fread( *buf , fSize, 1 , f ) != 1 ) {
    printf( "Error: Can not read file %s", file );
    exit( EXIT_FAILURE );
  }
  fclose( f );
}

bool nextLevelName( char *buf, char *actual, char *next ) {
  int s = strlen( actual );

  char *pos;
  while( (pos = strstr( buf, actual )) != NULL ) {
    if( (pos == buf && pos[ s ] == '\n') || (pos != buf && pos[ -1 ] == '\n' && pos[ s ] == '\n') )
      break;
    buf = pos + 1;
  }
  if( pos[ s + 1 ] == 0 ) { next[ 0 ] = 0; return false; }
  else {
    int i = 0;
    for( ; pos[ s + 1 + i ] != '\n'; i++ )
      next[ i ] = pos[ s + 1 + i ];
    next[ i ] = 0;
    return true;
  }
}
bool prevLevelName( char *buf, char *actual, char *previous ) {
  int s = strlen( actual );

  char *pos;
  while( (pos = strstr( buf, actual )) != NULL ) {
    if( (pos == buf && pos[ s ] == '\n') || (pos != buf && pos[ -1 ] == '\n' && pos[ s ] == '\n') )
      break;
    buf = pos + 1;
  }
  if( pos == buf ) { previous[ 0 ] = 0; return false; }
  else {
    int i = -2;
    while( &(pos[ i ]) != buf && pos[ i ] != '\n' ) i--;
    pos += i;
    if( *pos == '\n' ) pos++;
    i = 0;
    for( ; pos[ i ] != '\n'; i++ )
      previous[ i ] = pos[ i ];
    previous[ i ] = 0;
    return true;
  }
}

void prepareLevelsList( char *buf, long fSize ) {
  for( int i = 0; i < fSize; i++ )
    if( buf[ i ] == '>' || buf[ i ] == '\r' )
	  buf[ i ] = 0;
  for( int i = 1; i < fSize; i++ ) {
    if( buf[ i - 1 ] == 0 ) {
      int j = 1;
      while( (i - j > -1) && buf[ i - j ] == 0 ) j++;
      buf[ i - --j ] = buf[ i ];
      buf[ i ] = 0;
    }
  }

}

void appResources::loadLevelsList() {
  //char *buf;
  if( menu.levelsList != NULL ) delete[] menu.levelsList;
  long fSize;
  readFile( RES_LEVELS_LIST, &menu.levelsList, fSize );
  char *pos = strstr( menu.levelsList, ">" );
  if( pos == NULL ) pos = menu.levelsList;
  else pos++;
  //char levelName[ MAX_LINE ] = {0};
  int i = 0;
  for( ; pos[ i ] != '\r' && pos[ i ] != '\n'; i++ )
    menu.actualLevel[ i ] = pos[ i ];
  menu.actualLevel[ i ] = 0;
  prepareLevelsList( menu.levelsList, fSize );
 // prevLevelName( levelsList, actualLevel );
 // printf( "%s", actualLevel );
}

void appResources::saveLevelsList()
{
  char *pos;
  int fSize = strlen( menu.levelsList ) + 1;
  int s = strlen( menu.actualLevel );
  while( (pos = strstr( menu.levelsList, menu.actualLevel )) != NULL ) {
    if( (pos == menu.levelsList && pos[ s ] == '\n') || (pos != menu.levelsList && pos[ -1 ] == '\n' && pos[ s ] == '\n') )
      break;
    menu.levelsList = pos + 1;
  }
  int i = fSize - 1;
  while( menu.levelsList[ i ] == 0 ) i--;

  for( ; &(menu.levelsList[ i ]) > pos - 1; i-- ) {
    menu.levelsList[ i + 1 ] = menu.levelsList[ i ];
  }
  *pos = '>';


  FILE *f;



  f = fopen( RES_LEVELS_LIST, "wb" );
  if( f == NULL ) {
    printf( "Error: Can not write to file %s", RES_LEVELS_LIST );
    exit( EXIT_FAILURE );

  }


  if( fwrite( menu.levelsList , fSize, 1 , f ) != 1 ) {
    printf( "Error: Can not write to file %s", RES_LEVELS_LIST );
    exit( EXIT_FAILURE );
  }
  fclose( f );
}


appResources::appResources() {
  menu.levelsList = NULL;
  loadLevelsList();
/*
  createDXYTable( dxTable, true );
  createDXYTable( dyTable, false );
  for( int i = 0; i < MOVING_DEGREES; i++ )
    printf( "%d %d\n", dxTable[ i ], dyTable[ i ] );
 */
  font.loadFromFile( RES_FONT1, 16, 20 );
//  ball.loadFromFile( RES_TEST2, 30, 30 );
  font.changeColor( 0xffffffff, FONT_MENU_COLOR );
  //font.changeColorAtAlpha( 0xc8dd77ff );
  //font.changeColorAtAlpha( 0xff0000ff );

  mainTileset.loadFromFile( RES_MAIN_TILESET, 0, 0 );

  font.translucentToTransparent();
 // ball.opaqueToTranslucent( 0xffffff99 );

/*  test1.loadFromFile( RES_TEST1, 0, 0 );

  tileSet test2;
  test2.loadFromFile( RES_TEST1, 0, 0 );
  test2.mirror();
  test1.merge( test2 );

  tSeqs.ts = &test1;
  tSeqs2.ts = &test1;
  tSeqs3.ts = &test1;

  //tSeqs2.movAngle = 45;
  tSeqs2.movDX = 1;
  tSeqs2.movDY = 0;
  tSeqs.movDX = -1;
  tSeqs.movDY = 0;
  tSeqs.collisionCheck = true;
  tSeqs2.collisionCheck = true;

  tSeqs.createSeq( 0, 5 );
  tSeqs.createSeq( 6, 11 );
  tSeqs2.createSeq( 0, 5 );
  tSeqs2.createSeq( 6, 11 );
*/
  screens.resize( 3 );
  screens[ 0 ].windows.push_back( new Window );

/*
  //screens[ 0 ].windows.resize( 2 );
  screens[ 0 ].windows[ 0 ]->regularPlanesNR = 3;
  screens[ 0 ].windows[ 0 ]->associate( 1, &tSeqs, 1, 230, 30, 300 );
  screens[ 0 ].windows[ 0 ]->associate( 1, &tSeqs2, 0, 50, 50, 30 );
  //tSeqs2.endThreadAtCollision  = false;
  tSeqs2.eraseAtEndThread = false;
  //tSeqs2.stopOnCollision = false;

  //screens[ 0 ].windows[ 0 ]->associate( 3, &tSeqs3, 0, 200, 50, 100 );

  screens[ 0 ].windows[ 0 ]->planes.resize( 4 );
  //screens[ 0 ].windows[ 0 ]->planes[ 0 ] = optimizedSurface( "art.jpg", mainScreen->format, 0, 0 );
  screens[ 0 ].windows[ 0 ]->planes[ 0 ] = optimizedSurface( RES_BACKGROUND, MainScreen->format, 801, 700 );
  screens[ 0 ].windows[ 0 ]->planesWidth = screens[ 0 ].windows[ 0 ]->planes[ 0 ]->w;
  screens[ 0 ].windows[ 0 ]->planesHeight = screens[ 0 ].windows[ 0 ]->planes[ 0 ]->h;

  screens[ 0 ].windows[ 0 ]->planes[ 1 ] = emptyPlane( screens[ 0 ].windows[ 0 ]->planes[ 0 ]->w, screens[ 0 ].windows[ 0 ]->planes[ 0 ]->h );
  screens[ 0 ].windows[ 0 ]->planes[ 2 ] = emptyPlane( screens[ 0 ].windows[ 0 ]->planes[ 0 ]->w, screens[ 0 ].windows[ 0 ]->planes[ 0 ]->h );
  //screens[ 0 ].windows[ 0 ]->planes[ 2 ] = optimizedSurface( "red_ball.png", mainScreen->format, screens[ 0 ].windows[ 0 ]->planes[ 0 ]->w, screens[ 0 ].windows[ 0 ]->planes[ 0 ]->h );
  screens[ 0 ].windows[ 0 ]->planes[ 3 ] = emptyPlane( screens[ 0 ].windows[ 0 ]->planes[ 0 ]->w, screens[ 0 ].windows[ 0 ]->planes[ 0 ]->h );
  //screens[ 0 ].windows[ 0 ]->drawOnPlane( ball.tiles[ 0 ], screens[ 0 ].windows[ 0 ]->planes[ 2 ], 240, 50 );
  //screens[ 0 ].windows[ 0 ]->planes[ 3 ] = emptyPlane( screens[ 0 ].windows[ 0 ]->planes[ 0 ]->w, screens[ 0 ].windows[ 0 ]->planes[ 0 ]->h );
  test1.copyTile( 1 );
  test1.simpleRotation( -1, -90 );
*/
  animations.resize( 5 );
  animations[ ID_ANIMATION_CRUMBLE ].loadFromFile( RES_ANIMATION_CRUMBLE, 0, 0 );
  animations[ ID_ANIMATION_EXPLODE_EA ].loadFromFile( RES_ANIMATION_EXPLODE_EA, 0, 0 );
  animations[ ID_ANIMATION_EXPLODE_MSA ].loadFromFile( RES_ANIMATION_EXPLODE_MSA, 0, 0 );
  animations[ ID_ANIMATION_EXPLODE ].loadFromFile( RES_ANIMATION_EXPLODE, 40, 40 );
  animations[ ID_ANIMATION_SPLASH ].loadFromFile( RES_ANIMATION_SPLASH, 0, 0 );


  mainTileset.tiles[ T_HOLE ] = apply_pixelsRev( 0, 0, mainTileset.tiles[ T_FLOOR ], mainTileset.tiles[ T_HOLE ] );

  mainTileset.copyTile( T_N0 );
  mainTileset.copyTile( T_N1 );
  mainTileset.copyTile( T_N2 );
  mainTileset.copyTile( T_N3 );
  mainTileset.copyTile( T_N4 );
  mainTileset.copyTile( T_N5 );
  mainTileset.copyTile( T_N6 );
  mainTileset.copyTile( T_N7 );
  mainTileset.copyTile( T_N8 );
  mainTileset.copyTile( T_N9 );


  for( Uint32 i = T_N0; i <= T_N9; i++ ) {
    mainTileset.changeColor( 0xffffffff, NUMBER_COLOR1, i );
    mainTileset.tiles[ i ] = apply_pixelsRev( 0, 0, mainTileset.tiles[ T_BOX ], mainTileset.tiles[ i ] );

  }
  for( Uint32 i = T_DN0; i <= T_DN9; i++ ) {
    mainTileset.changeColor( 0xffffffff, NUMBER_COLOR2, i );
    mainTileset.tiles[ i ] = apply_pixelsRev( 0, 0, mainTileset.tiles[ T_BOX ], mainTileset.tiles[ i ] );
  }

  mainTileset.copyTile( T_MAGNET );
  mainTileset.simpleRotation( -1, -90 );
  mainTileset.copyTile( T_MAGNET );
  mainTileset.simpleRotation( -1, 90 );
  mainTileset.copyTile( T_MAGNET );
  mainTileset.simpleRotation( -1, 180 );

  mainTileset.copyTile( T_QUARTER1 );       //red up
  mainTileset.copyTile( T_QUARTER1 );       //red down
  mainTileset.simpleRotation( -1, 180 );
  mainTileset.copyTile( T_QUARTER2 );       //yellow left
  mainTileset.simpleRotation( -1, -90 );
  mainTileset.copyTile( T_QUARTER2 );       //yellow right
  mainTileset.simpleRotation( -1, 90 );
  mainTileset.copyTile( T_QUARTER3 );       //blue left
  mainTileset.simpleRotation( -1, -90 );
  mainTileset.copyTile( T_QUARTER3 );       //blue right
  mainTileset.simpleRotation( -1, 90 );
  mainTileset.copyTile( T_QUARTER3 );       //blue up
  mainTileset.copyTile( T_QUARTER3 );       //blue down
  mainTileset.simpleRotation( -1, 180 );
  mainTileset.copyTile( T_QUARTER2 );       //yellow up
  mainTileset.copyTile( T_QUARTER2 );       //yellow down
  mainTileset.simpleRotation( -1, 180 );
  mainTileset.copyTile( T_QUARTER1 );       //red left
  mainTileset.simpleRotation( -1, -90 );
  mainTileset.copyTile( T_QUARTER1 );       //red right
  mainTileset.simpleRotation( -1, 90 );

  mainTileset.copyTile( T_PLAYER_EA );
  mainTileset.simpleRotation( -1, 180 );
  mainTileset.copyTile( T_PLAYER_EA );
  mainTileset.simpleRotation( -1, -90 );
  mainTileset.copyTile( T_PLAYER_EA );
  mainTileset.simpleRotation( -1, 90 );
  mainTileset.copyTile( T_PLAYER_MSA );
  mainTileset.simpleRotation( -1, 180 );
  mainTileset.copyTile( T_PLAYER_MSA );
  mainTileset.simpleRotation( -1, -90 );
  mainTileset.copyTile( T_PLAYER_MSA );
  mainTileset.simpleRotation( -1, 90 );
  mainTileset.copyTile( T_PLAYER_PU );
  mainTileset.simpleRotation( -1, 180 );
  mainTileset.copyTile( T_PLAYER_PU );
  mainTileset.simpleRotation( -1, -90 );
  mainTileset.copyTile( T_PLAYER_PU );
  mainTileset.simpleRotation( -1, 90 );
  mainTileset.copyTile( T_PASS1 );
  mainTileset.simpleRotation( -1, 90 );
  mainTileset.copyTile( T_PASS2 );
  mainTileset.simpleRotation( -1, 90 );
  mainTileset.copyTile( T_PASS3 );
  mainTileset.simpleRotation( -1, 90 );
  mainTileset.copyTile( T_PASS4 );
  mainTileset.simpleRotation( -1, 90 );
  mainTileset.copyTile( T_PASS5 );
  mainTileset.simpleRotation( -1, 90 );
  mainTileset.copyTile( T_PASS6 );
  mainTileset.simpleRotation( -1, 90 );
  mainTileset.copyTile( T_PLATFORM_UP );
  mainTileset.simpleRotation( -1, 180 );
  mainTileset.copyTile( T_PLATFORM_UP );
  mainTileset.simpleRotation( -1, -90 );
  mainTileset.copyTile( T_PLATFORM_UP );
  mainTileset.simpleRotation( -1, 90 );
  mainTileset.copyTile( T_PLATFORM_VERTICAL );
  mainTileset.simpleRotation( -1, 90 );
  mainTileset.copyTile( T_ARROW_UP );
  mainTileset.simpleRotation( -1, 180 );
  mainTileset.copyTile( T_ARROW_UP );
  mainTileset.simpleRotation( -1, -90 );
  mainTileset.copyTile( T_ARROW_UP );
  mainTileset.simpleRotation( -1, 90 );
  mainTileset.copyTile( T_PASS1_H );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_LEFT ], mainTileset.tiles[ T_PASS1_LEFT ] );
  mainTileset.copyTile( T_PASS2_H );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_LEFT ], mainTileset.tiles[ T_PASS2_LEFT ] );
  mainTileset.copyTile( T_PASS3_H );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_LEFT ], mainTileset.tiles[ T_PASS3_LEFT ] );
  mainTileset.copyTile( T_PASS4_H );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_LEFT ], mainTileset.tiles[ T_PASS4_LEFT ] );
  mainTileset.copyTile( T_PASS5_H );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_LEFT ], mainTileset.tiles[ T_PASS5_LEFT ] );
  mainTileset.copyTile( T_PASS6_H );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_LEFT ], mainTileset.tiles[ T_PASS6_LEFT ] );

  mainTileset.copyTile( T_PASS1_H );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_RIGHT ], mainTileset.tiles[ T_PASS1_RIGHT ] );
  mainTileset.copyTile( T_PASS2_H );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_RIGHT ], mainTileset.tiles[ T_PASS2_RIGHT ] );
  mainTileset.copyTile( T_PASS3_H );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_RIGHT ], mainTileset.tiles[ T_PASS3_RIGHT ] );
  mainTileset.copyTile( T_PASS4_H );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_RIGHT ], mainTileset.tiles[ T_PASS4_RIGHT ] );
  mainTileset.copyTile( T_PASS5_H );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_RIGHT ], mainTileset.tiles[ T_PASS5_RIGHT ] );
  mainTileset.copyTile( T_PASS6_H );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_RIGHT ], mainTileset.tiles[ T_PASS6_RIGHT ] );

  mainTileset.copyTile( T_PASS1 );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_UP ], mainTileset.tiles[ T_PASS1_UP ] );
  mainTileset.copyTile( T_PASS2 );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_UP ], mainTileset.tiles[ T_PASS2_UP ] );
  mainTileset.copyTile( T_PASS3 );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_UP ], mainTileset.tiles[ T_PASS3_UP ] );
  mainTileset.copyTile( T_PASS4 );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_UP ], mainTileset.tiles[ T_PASS4_UP ] );
  mainTileset.copyTile( T_PASS5 );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_UP ], mainTileset.tiles[ T_PASS5_UP ] );
  mainTileset.copyTile( T_PASS6 );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_UP ], mainTileset.tiles[ T_PASS6_UP ] );

  mainTileset.copyTile( T_PASS1 );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_DOWN ], mainTileset.tiles[ T_PASS1_DOWN ] );
  mainTileset.copyTile( T_PASS2 );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_DOWN ], mainTileset.tiles[ T_PASS2_DOWN ] );
  mainTileset.copyTile( T_PASS3 );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_DOWN ], mainTileset.tiles[ T_PASS3_DOWN ] );
  mainTileset.copyTile( T_PASS4 );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_DOWN ], mainTileset.tiles[ T_PASS4_DOWN ] );
  mainTileset.copyTile( T_PASS5 );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_DOWN ], mainTileset.tiles[ T_PASS5_DOWN ] );
  mainTileset.copyTile( T_PASS6 );
  apply_surface( 0, 0, mainTileset.tiles[ T_ARROW_DOWN ], mainTileset.tiles[ T_PASS6_DOWN ] );

  mainTileset.tiles.push_back( animations[ ID_ANIMATION_CRUMBLE ].tiles[ 0 ] );
  mainTileset.tiles.push_back( animations[ ID_ANIMATION_EXPLODE_MSA ].tiles[ 0 ] );
  mainTileset.tiles.push_back( animations[ ID_ANIMATION_EXPLODE_EA ].tiles[ 0 ] );
  shotMSA = newTileSequencesFrom( &animations[ ID_ANIMATION_EXPLODE_MSA ], ID_ANIMATION_EXPLODE_MSA );
  shotEA = newTileSequencesFrom( &animations[ ID_ANIMATION_EXPLODE_EA ], ID_ANIMATION_EXPLODE_EA );
  shotMSA->createSeq( 1, 1 );
  shotMSA->actualSeq = 1;
  shotEA->createSeq( 0, 0 );
  shotEA->actualSeq = 1;
  /*shotMSA->movDX = MOV_DELTA;
  shotMSA->movDY = MOV_DELTA;
  shotEA->movDX = MOV_DELTA;
  shotEA->movDX = MOV_DELTA;
*/

  playerSeq = new tileSequences;
  playerSeq->ts = new tileSet;
  playerSeq->ts->tiles.resize( 12 );
  playerSeq->ts->tiles[ 0 ] = mainTileset.tiles[ T_PLAYER_MSA ];
  playerSeq->ts->tiles[ 1 ] = mainTileset.tiles[ T_PLAYER_MSA_LEFT ];
  playerSeq->ts->tiles[ 2 ] = mainTileset.tiles[ T_PLAYER_MSA_RIGHT ];
  playerSeq->ts->tiles[ 3 ] = mainTileset.tiles[ T_PLAYER_MSA_DOWN ];
  playerSeq->ts->tiles[ 4 ] = mainTileset.tiles[ T_PLAYER_EA ];
  playerSeq->ts->tiles[ 5 ] = mainTileset.tiles[ T_PLAYER_EA_LEFT ];
  playerSeq->ts->tiles[ 6 ] = mainTileset.tiles[ T_PLAYER_EA_RIGHT ];
  playerSeq->ts->tiles[ 7 ] = mainTileset.tiles[ T_PLAYER_EA_DOWN ];
  playerSeq->ts->tiles[ 8 ] = mainTileset.tiles[ T_PLAYER_PU ];
  playerSeq->ts->tiles[ 9 ] = mainTileset.tiles[ T_PLAYER_PU_LEFT ];
  playerSeq->ts->tiles[ 10 ] = mainTileset.tiles[ T_PLAYER_PU_RIGHT ];
  playerSeq->ts->tiles[ 11 ] = mainTileset.tiles[ T_PLAYER_PU_DOWN ];

  //playerSeq->ts = playerTileSet;
  for( int i = 0; i <= 11; i++ )
    playerSeq->createSeq( i, i );
  //playerSeq->createSeq();
  //printf( "%d ",playerSeq->sv[0].end);
 // playerSeq->actualSeq = 4;
 //playerSeq->eraseAtEndThread = true;
   playerSeq->useCounter = true;
  // playerSeq->useIdleCheck = true;
  // playerSeq->idleCounter = 50;
   playerSeq->stopAtCollision = true;
   playerSeq->id = T_PLAYER;


//  screens[ 0 ].windows[ 0 ]->drawOnPlane( mainTileset.tiles[ T_PASS2_UP ], screens[ 0 ].windows[ 0 ]->planes[ 2 ], 0, 0 );
  //apply_surface( 750, 0, playerSeq->ts->tiles[ 11 ], MainScreen );
  //apply_surface( 750, 50, font.tiles[44], MainScreen );
  //screens[ 0 ].windows[ 0 ]->drawOnPlane( font.tiles[3], screens[ 0 ].windows[ 0 ]->planes[ 0 ], 50, 50 );
//  screens[ 0 ].windows[ 0 ]->print( &font, 0, 5, 90, "First plane#!,-=$%^&*()" );
 // screens[ 0 ].windows[ 0 ]->anchoredText( &font, 1, 100, 70, "second plane" );
//  screens[ 0 ].windows[ 0 ]->print( &font, 2, 100, 70, "third plane" );
 // screens[ 0 ].windows[ 0 ]->anchoredText( &font, 2, 100, 70, "     " );
  // SDL_FillRect( screens[ 0 ].windows[ 0 ]->planes[ 2 ], NULL, BGR_TEST_COLOR );
 //screens[ 0 ].windows[ 0 ]->eraseFromPlane( tSeqs.ts->tiles[ 0 ], screens[ 0 ].windows[ 0 ]->planes[ 0 ], 200, 100 );

  //tSeqs.ts->tiles[ 0 ];

  //screens[ 0 ].windows[ 0 ]->scr = mainScreen;
  //Window::scr = mainScreen;
  /*
  screens[ 0 ].windows[ 0 ]->winPosX = 33;
  screens[ 0 ].windows[ 0 ]->winPosY = 44;
  screens[ 0 ].windows[ 0 ]->bgPosX = 0;
  screens[ 0 ].windows[ 0 ]->bgPosY = 0;
  screens[ 0 ].windows[ 0 ]->winWidth = 400;
  screens[ 0 ].windows[ 0 ]->winHeight = 400;
  */
  screens[ 0 ].windows[ 0 ]->winPosX = WINDOW_LEVEL_POSX;
  screens[ 0 ].windows[ 0 ]->winPosY = WINDOW_LEVEL_POSY;
  //screens[ 0 ].windows[ 0 ]->bgPosX = WINDOW_LEVEL_BGPOSX;
  //screens[ 0 ].windows[ 0 ]->bgPosY = WINDOW_LEVEL_BGPOSY;
  screens[ 0 ].windows[ 0 ]->winWidth = WINDOW_LEVEL_WIDTH;
  screens[ 0 ].windows[ 0 ]->winHeight = WINDOW_LEVEL_HEIGHT;

  screens[ 0 ].windows[ 0 ]->marginX = WINDOW_LEVEL_WIDTH / 4;
  screens[ 0 ].windows[ 0 ]->marginY = WINDOW_LEVEL_HEIGHT / 3;

  screens[ 0 ].windows.push_back( new Window );
  screens[ 0 ].windows[ 1 ]->winPosX = WINDOW_INFO_POSX;
  screens[ 0 ].windows[ 1 ]->winPosY = WINDOW_INFO_POSY;
  screens[ 0 ].windows[ 1 ]->winWidth = WINDOW_INFO_WIDTH;
  screens[ 0 ].windows[ 1 ]->winHeight = WINDOW_INFO_HEIGHT;
  screens[ 0 ].windows[ 1 ]->regularPlanesNR = 2;
  screens[ 0 ].windows[ 1 ]->planes.resize( 2 );
 //screens[ 0 ].windows[ 1 ]->planes[ 0 ] = emptyPlane( WINDOW_INFO_WIDTH, WINDOW_INFO_HEIGHT, 0x000000ff );
  screens[ 0 ].windows[ 1 ]->planes[ 0 ] = optimizedSurface( RES_INFO_BACKGROUND, MainScreen->format, WINDOW_INFO_WIDTH, WINDOW_INFO_HEIGHT );
  rectangleOnSurface( 0, 0, screens[ 0 ].windows[ 1 ]->planes[ 0 ], WINDOW_INFO_WIDTH, WINDOW_INFO_HEIGHT, 0, 2, WINDOW_INFO_BORDERCOLOR );

 // screens[ 0 ].windows[ 1 ]->planes[ 0 ] = optimizedSurface( RES_MENU_BACKGROUND, MainScreen->format, WINDOW_INFO_WIDTH, WINDOW_INFO_HEIGHT );

  screens[ 0 ].windows[ 1 ]->planes[ 1 ] = emptyPlane( WINDOW_INFO_WIDTH, WINDOW_INFO_HEIGHT );
    Window *wi = screens[ SCREEN_GAME ].windows[ WINDOW_INFO ];
  //wi->drawOnPlane( R->mainTileset.tiles[ T_TIME ], wi->planes[ 0 ], INFO_TIME_X, INFO_TIME_Y );
  apply_surface( INFO_TIME_X, INFO_TIME_Y, mainTileset.tiles[ T_TIME ], wi->planes[ 0 ] );
  apply_surface( INFO_KEY1_X, INFO_KEY1_Y, mainTileset.tiles[ T_KEY1 ], wi->planes[ 0 ] );
  apply_surface( INFO_KEY2_X, INFO_KEY2_Y, mainTileset.tiles[ T_KEY2 ], wi->planes[ 0 ] );
  apply_surface( INFO_KEY3_X, INFO_KEY3_Y, mainTileset.tiles[ T_KEY3 ], wi->planes[ 0 ] );

  apply_surface( INFO_PU_X, INFO_PU_Y, mainTileset.tiles[ T_PU ], wi->planes[ 0 ] );
  apply_surface( INFO_MSA_X, INFO_MSA_Y, mainTileset.tiles[ T_MSA ], wi->planes[ 0 ] );
  apply_surface( INFO_EA_X, INFO_EA_Y, mainTileset.tiles[ T_EA ], wi->planes[ 0 ] );
  apply_surface( INFO_REPAIR_X, INFO_REPAIR_Y, mainTileset.tiles[ T_REPAIR ], wi->planes[ 0 ] );
  apply_surface( INFO_FUEL_X, INFO_FUEL_Y, mainTileset.tiles[ T_FUEL ], wi->planes[ 0 ] );

  //screens[ 0 ].windows[ 1 ]->print( &font, 0, INFO_KEY3_X, INFO_KEY3_Y, "%d",  );

  screens[ 0 ].windows.push_back( new Window );
  screens[ 0 ].windows[ 2 ]->winPosX = WINDOW_GAMEOVER_POSX;
  screens[ 0 ].windows[ 2 ]->winPosY = WINDOW_GAMEOVER_POSY;
  screens[ 0 ].windows[ 2 ]->winWidth = WINDOW_GAMEOVER_WIDTH;
  screens[ 0 ].windows[ 2 ]->winHeight = WINDOW_GAMEOVER_HEIGHT;
  screens[ 0 ].windows[ 2 ]->regularPlanesNR = 1;
  screens[ 0 ].windows[ 2 ]->planes.resize( 1 );
  screens[ 0 ].windows[ 2 ]->planes[ 0 ] = emptyPlane( WINDOW_GAMEOVER_WIDTH, WINDOW_GAMEOVER_HEIGHT, 0x000000ff );


  screens[ 0 ].windows.push_back( new Window );
  screens[ 0 ].windows[ 3 ]->winPosX = WINDOW_GOALS_POSX;
  screens[ 0 ].windows[ 3 ]->winPosY = WINDOW_GOALS_POSY;
  screens[ 0 ].windows[ 3 ]->winWidth = WINDOW_GOALS_WIDTH;
  screens[ 0 ].windows[ 3 ]->winHeight = WINDOW_GOALS_HEIGHT;
  screens[ 0 ].windows[ 3 ]->bgPosX = 0;
  screens[ 0 ].windows[ 3 ]->bgPosY = 0;
  screens[ 0 ].windows[ 3 ]->regularPlanesNR = 2;
  screens[ 0 ].windows[ 3 ]->planes.resize( 2 );
  //screens[ 0 ].windows[ 3 ]->planes[ 0 ] = emptyPlane( WINDOW_GOALS_WIDTH, WINDOW_GOALS_HEIGHT, 0x000000ff );
  //screens[ 0 ].windows[ 3 ]->planes[ 1 ] = emptyPlane( WINDOW_GOALS_WIDTH, WINDOW_GOALS_HEIGHT );

  screens[ 1 ].windows.push_back( new Window );
  menu.createMenu( screens[ 1 ].windows[ 0 ], &font );

  screens[ 2 ].windows.push_back( new Window );
  screens[ 2 ].windows[ 0 ]->regularPlanesNR = 2;
  screens[ 2 ].windows[ 0 ]->planes.resize( 2 );
  screens[ 2 ].windows[ 0 ]->winPosX = WINDOW_INTRO_POSX;
  screens[ 2 ].windows[ 0 ]->winPosY = WINDOW_INTRO_POSY;
  screens[ 2 ].windows[ 0 ]->winWidth = WINDOW_INTRO_WIDTH;
  screens[ 2 ].windows[ 0 ]->winHeight = WINDOW_INTRO_HEIGHT;


}
void Menu::updateSelection() {
  if( prevMenuEl > -1 )
    w->eraseFromPlane( menuElements[ prevMenuEl ].box, w->planes[ 1 ], menuElements[ prevMenuEl ].x - fW / 2, menuElements[ prevMenuEl ].y - fH / 2 );
  w->drawOnPlane( menuElements[ actualMenuEl ].box, w->planes[ 1 ], menuElements[ actualMenuEl ].x - fW / 2, menuElements[ actualMenuEl ].y - fH / 2 );

}
void Menu::getNeighbourLevelsNames() {
  prevLevelName( levelsList, actualLevel, prevLevel );
  nextLevelName( levelsList, actualLevel, nextLevel );
  //printf( "[%s ; %s; %s] ", prevLevel, actualLevel, nextLevel );
  if( prevLevel[ 0 ] != 0 )
    w->print( font, 2, menuElements[ 0 ].x - fW * 3, menuElements[ 0 ].y, "<<" );
  //else w->print( font, 2, menuElements[ 0 ].x - fW * 3, menuElements[ 0 ].y, "  " );
  if( nextLevel[ 0 ] != 0 )
    w->print( font, 2, menuElements[ 0 ].x + fW * (1 + strlen( menuElements[ 0 ].text )), menuElements[ 0 ].y, ">>" );
  //else w->print( font, 2, menuElements[ 0 ].x - fW * (1 + strlen( menuElements[ 0 ].text )), menuElements[ 0 ].y, "  " );
}
void Menu::toBeContinued() {
  maxEl = 2;
  w->print( font, 2, menuElements[ 2 ].x, menuElements[ 2 ].y, "%s", menuElements[ 2 ].text );
  if( actualMenuEl != 2 ) {
    prevMenuEl = actualMenuEl;
    actualMenuEl = 2;
	updateSelection();
  }

}
void Menu::createMenu( Window *win, tileSet *f ) {
  w = win;
  font = f;
  fW = font->tiles[ 0 ]->w;
  fH = font->tiles[ 0 ]->h;

  w->winPosX = 0;
  w->winPosY = 0;
  w->bgPosX = 0;
  w->bgPosY = 0;
  w->winWidth = scrWidth;
  w->winHeight = scrHeight;
  w->planes.resize( 3 );
  w->regularPlanesNR = 3;
  w->planes[ 0 ] = optimizedSurface( RES_MENU_BACKGROUND, MainScreen->format, scrWidth, scrHeight );
  rectangleOnSurface( TITLE_POSX, TITLE_POSY, w->planes[ 0 ], TITLE_WIDTH, TITLE_HEIGHT, TITLE_BG_COLOR, 2, BORDER_MENU_COLOR );
  
  rectangleOnSurface( MENU_POSX, MENU_POSY, w->planes[ 0 ], MENU_WIDTH, MENU_HEIGHT, MENU_BG_COLOR, 2, BORDER_MENU_COLOR );
  
  w->planes[ 1 ] = emptyPlane( scrWidth, scrHeight );

  w->planes[ 2 ] = emptyPlane( scrWidth, scrHeight );
  w->print( font, 2, TITLE_TEXT_POSX, TITLE_TEXT_POSY, TITLE_TEXT );
  w->print( font, 2, VERSION_TEXT_POSX, VERSION_TEXT_POSY, VERSION_TEXT );
  
  w->print( font, 2, MENU_POSX + fW * 3, MENU_POSY + fH, "Choose level:" );
  menuElements.resize( 3 );
  menuElements[ 0 ].text = new char [ MAX_LINE ];
  strcpy( menuElements[ 0 ].text, actualLevel );
  menuElements[ 0 ].x = MENU_POSX + fW * 3;
  menuElements[ 0 ].y = MENU_POSY + fH * 3;
  menuElements[ 1 ].text = new char [ MAX_LINE ];
  strcpy( menuElements[ 1 ].text, "Exit" );
  menuElements[ 1 ].x = MENU_POSX + fW * 3;
  menuElements[ 1 ].y = MENU_POSY + fH * 6;
  menuElements[ 2 ].text = new char [ MAX_LINE ];
  strcpy( menuElements[ 2 ].text, "Continue" );
  menuElements[ 2 ].x = MENU_POSX + fW * 3;// + fW * (4 + menuElements[ 1 ].text);
  menuElements[ 2 ].y = MENU_POSY + fH * 9;

  w->print( font, 2, menuElements[ 0 ].x, menuElements[ 0 ].y, "%s", menuElements[ 0 ].text );
  w->print( font, 2, menuElements[ 1 ].x, menuElements[ 1 ].y, "%s", menuElements[ 1 ].text );

  prevLevel[ 0 ] = nextLevel[ 0 ] = 0;
  getNeighbourLevelsNames();
  actualMenuEl = 0;
  prevMenuEl = -1;
  maxEl = 1;


  menuElements[ 0 ].box = makeRectangle( (strlen( menuElements[ 0 ].text ) + 1) * fW, fH * 2, MENU_SELECT_COLOR, 2, BORDER_MENU_COLOR );
  menuElements[ 1 ].box = makeRectangle( (strlen( menuElements[ 1 ].text ) + 1) * fW, fH * 2, MENU_SELECT_COLOR, 2, BORDER_MENU_COLOR );
  menuElements[ 2 ].box = makeRectangle( (strlen( menuElements[ 2 ].text ) + 1) * fW, fH * 2, MENU_SELECT_COLOR, 2, BORDER_MENU_COLOR );

  updateSelection();
}

void appResources::toTheGame( bool continuation ) {
  actualActiveWin = screens[ SCREEN_GAME ].windows[ 0 ];
  actualScreen = SCREEN_GAME;
  SDL_FillRect( MainScreen, NULL, 0 );
  
  if( continuation )
    //SDL_UpdateRect( MainScreen, WINDOW_LEVEL_POSX, WINDOW_LEVEL_POSY, WINDOW_LEVEL_WIDTH, WINDOW_LEVEL_HEIGHT );
SDL_UpdateRect( MainScreen, 0, 0, SCREEN_RESOLUTION_W, SCREEN_RESOLUTION_H );
    

    screens[ SCREEN_GAME ].windows[ WINDOW_LEVEL ]->redrawAllPlanes();
    screens[ SCREEN_GAME ].windows[ WINDOW_INFO ]->redrawAllPlanes();
    screens[ SCREEN_GAME ].windows[ WINDOW_GOALS ]->redrawAllPlanes();

}

void appResources::toTheMenu( bool toBeContinued ) {
//  screens[ SCREEN_GAME ].windows[ 1 ]->redrawAllPlanes();
//  SDL_Flip(MainScreen);
  actualActiveWin = screens[ SCREEN_MENU ].windows[ 0 ];
  actualScreen = SCREEN_MENU;

  if( toBeContinued )
    menu.toBeContinued();
  else {
     menu.maxEl = 1;
	 menu.prevMenuEl = menu.actualMenuEl;
     menu.actualMenuEl = 0;
     menu.updateSelection();
     menu.w->eraseFromPlane( strlen( menu.menuElements[ 2 ].text ) * menu.fW, menu.fH, screens[ SCREEN_MENU ].windows[ 0 ]->planes[ 2 ], menu.menuElements[ 2 ].x, menu.menuElements[ 2 ].y );

  }
  screens[ SCREEN_MENU ].windows[ 0 ]->redrawAllPlanes();
}

void appResources::toTheIntro() {
  actualActiveWin = screens[ SCREEN_INTRO ].windows[ 0 ];
  actualScreen = SCREEN_INTRO;
  screens[ SCREEN_INTRO ].windows[ 0 ]->redrawAllPlanes();
}
