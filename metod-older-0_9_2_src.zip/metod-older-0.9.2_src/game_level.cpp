#include"game_level.h"
extern SDL_Surface *MainScreen;
extern int TileWidth;
extern SDL_mutex *plane_mutex;
extern int allThreads;

bool thisIsIt( Level *lvl, int row, int col ) {
  int endRow = row + 3, endCol = col + 3;
  int goalGnB = 0, lvlGnB = 0;
  for( int i = 0 ; i < 3; i++ )
    for( int j = 0 ; j < 3; j++ )
      if( lvl->goals[ 0 ][ i ][ j ] != T_SPACE )
	    goalGnB++;
  for( int i = row, m = 0; i < endRow; i++, m++ ) {

    for( int j = col, n = 0; j < endCol; j++, n++ ) {
	  if( lvl->goals[ 0 ][ m ][ n ] != T_SPACE ) {
	  //  goalGnB++;
	    if( lvl->allSectors[ 1 ][ i ][ j ].look != NULL && lvl->allSectors[ 1 ][ i ][ j ].look->id == lvl->goals[ 0 ][ m ][ n ] ) {
	      lvlGnB++;

	    }
	  }
	}
  }
//printf( "%d %d| %d;%d\n", row, col, lvlGnB, goalGnB );
  if( goalGnB != 0 && lvlGnB == goalGnB ) {
    //printf( "%d %d| %d;%d\n", row, col, lvlGnB, goalGnB );
    return true;
  }
  else return false;
}

void Level::removeGoal( int row, int col ) {
  int endRow = row + 3, endCol = col + 3;
  for( int i = row, m = 0; i < endRow; i++, m++ ) {
    for( int j = col, n = 0; j < endCol; j++, n++ ) {
	  if( goals[ 0 ][ m ][ n ] != T_SPACE && allSectors[ 1 ][ i ][ j ].look != NULL && allSectors[ 1 ][ i ][ j ].look->id == goals[ 0 ][ m ][ n ] )
	    exploded( &player, i, j );
	}
  }

  goals.erase( goals.begin() );
  updateGoalsInfo();
  if( goals.size() == 0 && !gameOver ) {
    complete = true;

	//R->screens[ SCREEN_GAME ]->windows[ WINDOW_GOALS ]->redrawAllPlanes();
	SDL_CreateThread( gameOverThread, this );
  }
}

bool Level::checkGoal() {
  int gs = goals.size();
for( int g = 0; g < gs; g++ )
  for( int i = 0; i < allRows - 2; i++ )
    for( int j = 0; j < allCols - 2; j++ )
	  if( thisIsIt( this, i, j ) ) {
	    removeGoal( i, j );
		g = 0;
		i = j = 0;
	  }
}

void Level::tileLocation( tileSequences *l, int &row, int &col ) {
  bool foundRow = false, foundCol = false;
  int planeHeight = TileWidth * allRows;
  int planeWidth = TileWidth * allCols;

  for( int i = 0, ic = 0; i < planeHeight; i += TileWidth, ic++ ) {
    if( !foundRow && l->y >= i && l->y < i + TileWidth ) {
	  row = ic;
	  foundRow = true;
	}
	if( foundRow && foundCol ) break;
	for( int j = 0, jc = 0; j < planeWidth; j += TileWidth, jc++ ) {
	  if( foundCol ) break;
      if( !foundCol && l->x >= j && l->x < j + TileWidth ) {
	    col = jc;
	    foundCol = true;

	  }
	}

  }
}
/*
void Level::tileLocationAbout( tileSequences *l, int &row, int &col ) {
  bool foundRow = false, foundCol = false;
  int planeHeight = TileWidth * allRows;
  int planeWidth = TileWidth * allCols;

  for( int i = -TileWidth / 2, ic = 0; i < planeHeight; i += TileWidth, ic++ ) {
    if( !foundRow && l->y > i && l->y <= i + TileWidth ) {
	  row = ic;
	  foundRow = true;
	}
	if( foundRow && foundCol ) break;
	for( int j = -TileWidth / 2, jc = 0; j < planeWidth; j += TileWidth, jc++ ) {
	  if( foundCol ) break;
      if( !foundCol && l->x > j && l->x <= j + TileWidth ) {
	    col = jc;
	    foundCol = true;

	  }
	}

  }
}*/

void tileSector( int x, int y, int &row, int &col ) {
  row = y / TileWidth;
  col = x / TileWidth;

}

void Level::adjustTile( tileSequences *l, int &row, int &col ) {

  tileLocation( l, row, col );
  l->adjust();
  l->prev_x = l->x;
  l->x = allSectors[ 0 ][ row ][ col ].x;
  l->prev_y = l->y;
  l->y = allSectors[ 0 ][ row ][ col ].y;
  l->adjust();

//  allSectors[ plv ][ row ][ col ].look = l;
  //printf( "(%d %d) ", row, col );
}
void preparePlayer( Player *p ) {
 // p->look->endThread = true;
 //updateSurroundings( p );
  SDL_Delay( MOV_DELAY * 3 );
 // p->look->adjust();
//  p->look->newThread();

}
bool foundMagnet( Level *lvl, int row, int col ) {
    int s = lvl->magnets.size();
	int mRow, mCol;

  for( int i = 0; i < s; i++ ) {
    if( lvl->magnets[ i ].row >= 0 && row == lvl->magnets[ i ].row )
	{
	  mCol = -lvl->magnets[ i ].col;
	  int j, inc = 1;
	  if( col > mCol ) inc = -1;
	  for( j = col; j != mCol; j += inc )
        if( lvl->allSectors[ 1 ][ row ][ j ].look != NULL && (!(lvl->allSectors[ 1 ][ row ][ j ].look->type & B_PASSABLE) || (lvl->allSectors[ 1 ][ row ][ j ].look->type & B_ITEM)) ) break;
      if( j == mCol && ((inc > 0 && lvl->allSectors[ 1 ][ row ][ j ].look->id == T_MAGNET_LEFT) || (inc < 0 && lvl->allSectors[ 1 ][ row ][ j ].look->id == T_MAGNET_RIGHT)) )
        return true;
	}
	if( lvl->magnets[ i ].col >= 0 && col == lvl->magnets[ i ].col ) {
	  mRow = -lvl->magnets[ i ].row;
	  int j, inc = 1;
	  if( row > mRow ) inc = -1;
	  for( j = row; j != mRow; j += inc )
        if( lvl->allSectors[ 1 ][ j ][ col ].look != NULL && (!(lvl->allSectors[ 1 ][ j ][ col ].look->type & B_PASSABLE) || (lvl->allSectors[ 1 ][ j ][ col ].look->type & B_ITEM)) ) break;
      if( j == mRow && ((inc > 0 && lvl->allSectors[ 1 ][ j ][ col ].look->id == T_MAGNET) || (inc < 0 && lvl->allSectors[ 1 ][ j ][ col ].look->id == T_MAGNET_DOWN)) )
        return true;
	}
  }
  return false;
}

int checkDistanceToShore( Player *p, uchar md, Level *lvl ) {
  int rowOff = 0, colOff = 0, m = 0;
  if( md == P_UP ) {
    rowOff = -1;
    m = p->sector->row;
  }
  if( md == P_DOWN ) {
    rowOff = 1;
    m = p->lvl->allRows - p->sector->row - 1;
  }
  if( md == P_LEFT ) {
    colOff = -1;
    m = p->sector->col;
  }
  if( md == P_RIGHT ) {
    colOff = 1;
    m = p->lvl->allCols - p->sector->col - 1;
  }
  //printf( "!%d! ", m );
  bool fmag;
  for( int i = 1; i <= m; i++ ) {
  //  printf( "^ " );
    if( p->lvl->allSectors[ 0 ][ p->sector->row + rowOff * i ][ p->sector->col + colOff * i ].look != NULL ||  (fmag = foundMagnet( lvl, p->sector->row + rowOff * i, p->sector->col + colOff * i )) ) {
      if( fmag )
        return i + 1;
	  else return i;
    }
  }

  return m + 1;
}
int checkDistance( Player *p, uchar md ) {
  int rowOff = 0, colOff = 0, m = 0;
  if( md == P_UP ) {
    rowOff = -1;
    m = p->sector->row;
  }
  if( md == P_DOWN ) {
    rowOff = 1;
    m = p->lvl->allRows - p->sector->row - 1;
  }
  if( md == P_LEFT ) {
    colOff = -1;
    m = p->sector->col;
  }
  if( md == P_RIGHT ) {
    colOff = 1;
    m = p->lvl->allCols - p->sector->col - 1;
  }
  //printf( "!%d! ", m );
  for( int i = 0; i < m; i++ ) {
  //  printf( "^ " );
    if( p->lvl->allSectors[ 1 ][ p->sector->row + rowOff * i ][ p->sector->col + colOff * i ].look != NULL && (!(p->lvl->allSectors[ 1 ][ p->sector->row + rowOff * i ][ p->sector->col + colOff * i ].look->type & B_PASSABLE) || (p->lvl->allSectors[ 1 ][ p->sector->row + rowOff * i ][ p->sector->col + colOff * i ].look->type & B_ITEM)) ) {

      return i;
    }
  }
/*  int m = p->lvl->allCols;
  if( m < p->lvl->allRows ) m = p->lvl->allRows;
  for( int i = 0; i < m; i++ ) {
    if( !(p->lvl->allSectors[ 0 ][ p->sector->row + rowOff * i ][ p->sector->col + colOff * i ].look->type & B_PASSABLE) || (p->lvl->allSectors[ 0 ][ p->sector->row + rowOff * i ][ p->sector->col + colOff * i ].look->type & B_ITEM) )
      return i;
  }
  */
  return m;
}
tileSequences* newTileSequence( int id, SDL_Surface *tile, int x, int y ) {
  tileSequences *l = new tileSequences;
  l->ts = new tileSet;
  l->ts->tiles.resize( 1 );
  l->ts->tiles[ 0 ] = tile;
  l->createSeq();
  l->prev_x = l->x = x;
  l->prev_y = l->y = y;
  l->collisionCheck = false;
  l->id = id;
  l->stop = true;
  return l;
}
void makeMov( bool &changedDirection, bool &m, Player *p, uchar md ) {
//if( p->lvl->magnetizePlayer || p->lvl->gameOver ) return;
 int colOff = 0, rowOff = 0;
 int mcountX = TileWidth / MOV_DELTA, mcountY = TileWidth / MOV_DELTA, mdeltaX = MOV_DELTA, mdeltaY = MOV_DELTA;
 if( md == P_RIGHT ) {
   colOff = 1;
   mdeltaY = 0;
   mcountY = 0;
 }
 if( md == P_LEFT ) {
   colOff = -1;
   mdeltaY = 0;
   mcountY = 0;
   mdeltaX = -mdeltaX;
 }
 if( md == P_UP ) {

   rowOff = -1;
   mdeltaX = 0;
   mcountX = 0;
   mdeltaY = -mdeltaY;
 }
 if( md == P_DOWN ) {
   rowOff = 1;
   mdeltaX = 0;
   mcountX = 0;
 }

 uchar mdS = md;
 if( p->state & B_USING_EA ) mdS += 4;
 if( p->state & B_USING_PU ) mdS += 8;

 if( p->look->actualSeq != mdS && p->lassoDirection == P_STAND ) {
        p->look->actualSeq = mdS;
	    p->look->newThread();
		//if( p->lvl->allSectors[ 0 ][ p->sector->row ][ p->sector->col ].look->id == T_PLATFORM_MULTIDIRECT )
    //    if( p->sector != NULL && p->sector->look != NULL && (p->sector->look->id == T_PLATFORM_HORIZONTAL || p->sector->look->id == T_PLATFORM_VERTICAL || p->sector->look->id == T_PLATFORM_RIGHT || p->sector->look->id == T_PLATFORM_LEFT || p->sector->look->id == T_PLATFORM_UP || p->sector->look->id == T_PLATFORM_DOWN) )
	//	  p->look->adjust();

	//	if( p->sector->look->id == T_PLATFORM_HORIZONTAL || p->sector->look->id == T_PLATFORM_VERTICAL || p->sector->look->id == T_PLATFORM_RIGHT || p->sector->look->id == T_PLATFORM_LEFT || p->sector->look->id == T_PLATFORM_UP || p->sector->look->id == T_PLATFORM_DOWN || p->sector->look->id == T_PLATFORM_MULTIDIRECT  )

		changedDirection = true;
	  }
      else if( ((md == P_RIGHT) && (p->sector->col < p->lvl->allCols - 1)) || ((md == P_LEFT) && (p->sector->col > 0)) || ((md == P_UP) && (p->sector->row > 0)) || ((md == P_DOWN) && (p->sector->row < p->lvl->allRows - 1)) ){
//printf("rowOff:%d; colOff:%d; passable:%d\n", rowOff, colOff, p->lvl->allSectors[ 0 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look->type & B_PASSABLE );
 //  if( p->lvl->allSectors[ 0 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look != NULL && !(p->lvl->allSectors[ 0 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look->id == T_CRUMBLE && p->lvl->allSectors[ 0 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look->stop == false) ) {
	  if( p->lvl->allSectors[ 0 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look != NULL ) {
//printf("rowOff:%d; colOff:%d; passable:%d\n", rowOff, colOff, p->lvl->allSectors[ 0 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look->type & B_PASSABLE );

		 if( (p->lvl->allSectors[ 0 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look->type & B_PASSABLE) ) {
//printf("rowOff:%d; colOff:%d; passable:%d\n", rowOff, colOff, p->lvl->allSectors[ 0 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look->type & B_PASSABLE );
          m = false;
		  bool movIt = false;
		  if( p->lassoDirection != P_STAND && p->sector->look->id != T_CRUMBLE ) {
		   // p->lvl->checkMagnets();
		    SDL_Delay( 100 );
		    if( md == P_UP && p->lassoDirection == P_DOWN ) m = true;
			if( md == P_DOWN && p->lassoDirection == P_UP ) m = true;
			if( md == P_LEFT && p->lassoDirection == P_RIGHT ) m = true;
			if( md == P_RIGHT && p->lassoDirection == P_LEFT ) m = true;
			if( m ) {
			int row, col;
			p->lvl->tileLocation( p->lvl->R->lasso, row, col );
			if( p->lvl->allSectors[ 1 ][ row ][ col ].look != NULL )
			  movIt = checkPass( p->lvl->allSectors[ 1 ][ row ][ col ].look->id, p->sector->look->id, rowOff, colOff, p->lvl->allSectors[ 1 ][ row ][ col ].look->type );
		    if( p->lvl->allSectors[ 1 ][ row ][ col ].look == NULL || (p->lvl->allSectors[ 1 ][ row ][ col ].look != NULL && !(p->lvl->allSectors[ 1 ][ row ][ col ].look->type & B_MOVABLE)) ) movIt = false;
		    //if( p->movSectorCount > 1 ) movIt = false;
		    if( p->items.pu <= 0 ) movIt = false;
			if( movIt ) {
			  Sector *af = &p->lvl->allSectors[ 1 ][ row + rowOff ][ col + colOff ];
			  Sector *f = &p->lvl->allSectors[ 0 ][ row + rowOff ][ col + colOff ];
			  Sector *c = &p->lvl->allSectors[ 1 ][ row ][ col ];
			  Sector *cf = &p->lvl->allSectors[ 0 ][ row ][ col ];

			  af->look = c->look;
	          c->look = NULL;
              cf->look->type |= B_PASSABLE;
			  if( af->look->type & B_ITEM ) { cf->look->type ^= B_ITEM; f->look->type |= B_ITEM; if( af->look->id == T_DYNAMITE ) f->look->type ^= B_PASSABLE; }
			  else { f->look->type ^= B_PASSABLE; }

		      af->look->movDX = mdeltaX;
	          af->look->movDY = mdeltaY;
	          af->look->useCounter = true;
	          af->look->movCounterX = mcountX;
	          af->look->movCounterY = mcountY;
		  //af->look->timing = MOV_DELAY;

            if( (af->look->id >= T_BALL1 && af->look->id <= T_BALL6) || af->look->id == T_BALL7 )
              af->look->timing = MOV_DELAY;
		    af->look->newThread();
			p->items.pu--;
			p->lvl->updateInfo();
			}
		  }
		    //p->lvl->checkMagnets();
		  }
		  if( p->lassoDirection == P_STAND || (m && movIt) ) {
			p->look->movCounterX = mcountX; //TileWidth / MOV_DELTA;
	        p->look->movDX = mdeltaX; //MOV_DELTA;
			p->look->movCounterY = mcountY; //TileWidth / MOV_DELTA;
	        p->look->movDY = mdeltaY; //MOV_DELTA;



		/*    if( p->lvl->allSectors[ 0 ][ p->sector->row + rowOff ][ p->sector->col + collOff ].look->type & B_ITEM )
              p->look->collisionCheck = true;
            else p->look->collisionCheck = false;*/
           
            p->prevSector = p->sector;
		    p->sector = &p->lvl->allSectors[ 0 ][ p->sector->row + rowOff ][ p->sector->col + colOff ];
		   
		    p->look->newThread();


			if( p->lassoDirection != P_STAND ) {
			  p->lvl->R->lasso->movCounterX = mcountX;
			  p->lvl->R->lasso->movDX = mdeltaX;
			  p->lvl->R->lasso->movCounterY = mcountY;
			  p->lvl->R->lasso->movDY = mdeltaY;
			  p->lvl->R->lasso->adjust();
			  p->lvl->R->lasso->newThread();

			}

			m = true;

		  }

		  } else if( p->lvl->allSectors[ 1 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look != NULL ) {
		    //printf( "%d ", p->lvl->allSectors[ 0 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look->id );
		    bool openDoor = false;
			if( p->lvl->allSectors[ 1 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look->id == T_DOOR1 && p->items.key1 > 0 ) {p->items.key1--; openDoor = true; }
            if( p->lvl->allSectors[ 1 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look->id == T_DOOR2 && p->items.key2 > 0 ) {p->items.key2--; openDoor = true;  }
            if( p->lvl->allSectors[ 1 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look->id == T_DOOR3 && p->items.key3 > 0 ) {p->items.key3--; openDoor = true;  }
		    if( openDoor ) {
			   p->lvl->scrap( p->lvl->allSectors[ 1 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look );
			   p->lvl->allSectors[ 0 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look->type |= B_PASSABLE;
			   p->lvl->allSectors[ 1 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look = NULL;
			   p->lvl->updateInfo();
			}
		  }

		  }else// if( p->sector->look != NULL ) {
		  if( p->lassoDirection == P_STAND && p->sector != NULL && p->sector->look != NULL && ((md == P_RIGHT && (p->sector->look->id == T_PLATFORM_HORIZONTAL || p->sector->look->id == T_PLATFORM_RIGHT || p->sector->look->id == T_PLATFORM_MULTIDIRECT)) || (md == P_LEFT && (p->sector->look->id == T_PLATFORM_HORIZONTAL || p->sector->look->id == T_PLATFORM_LEFT || p->sector->look->id == T_PLATFORM_MULTIDIRECT)) || (md == P_UP && (p->sector->look->id == T_PLATFORM_VERTICAL || p->sector->look->id == T_PLATFORM_UP || p->sector->look->id == T_PLATFORM_MULTIDIRECT)) || (md == P_DOWN && (p->sector->look->id == T_PLATFORM_VERTICAL || p->sector->look->id == T_PLATFORM_DOWN || p->sector->look->id == T_PLATFORM_MULTIDIRECT))) ) {
            preparePlayer( p );
			int distCount = (checkDistanceToShore( p, md, p->lvl ) - 1) * TileWidth / MOV_DELTA;
			//printf( "%d ", distCount );
			p->sector->look->movDX = mdeltaX;//MOV_DELTA;
			p->sector->look->movDY = mdeltaY;//MOV_DELTA;
            p->sector->look->movCounterX = p->sector->look->movCounterY = distCount;
			//p->sector->look->refreshRender = false;
			p->sector->look->useCounter = true;
			p->sector->look->newThread();
			p->sector->look = NULL;

			p->look->useCounter = true;
		    //p->look->mimicMov = p->sector->look;
            p->look->movCounterX = p->look->movCounterY = distCount;
		    p->look->movDX = mdeltaX;//MOV_DELTA;
			p->look->movDY = mdeltaY;//MOV_DELTA;


           /* p->look->usePointerToXY = true;
            p->look->p_x = &(p->sector->look->x);
            p->look->p_y = &(p->sector->look->y);
			*/
			m = true;
			//p->lvl->transportPlayer = true;
			p->look->newThread();

		  }

	//	}

    }
}

int timerThread( void *data ) {
  Player *p = (Player *)data;
  while( p->lvl->runTimer ) {
    SDL_Delay( 1000 );
	if( !p->lvl->gameOver && !p->lvl->magnetizePlayer && !p->lvl->complete ) {
	  p->items.time--;
	  p->lvl->updateTime();
	}
	if( p->items.time < 1 && !p->lvl->complete ) {
	  p->lvl->runTimer = false;
	  p->lvl->gameOver = true;
	  strcpy( p->lvl->gameOverText, " Out of time" );
	  SDL_CreateThread( gameOverThread, p->lvl );
	}
  }


}

int gameOverThread( void *data ) {
  Level *lvl = (Level *)data;
  lvl->runTimer = false;
  lvl->updateInfo();
  while( allThreads > 0 ) SDL_Delay( GAMEOVER_DELAY );
  SDL_Delay( GAMEOVER_DELAY );
  Uint32 wColor = WINDOW_GAMEOVER_BGCOLOR, bColor = WINDOW_GAMEOVER_BORDERCOLOR;
  if( lvl->complete ) { wColor = WINDOW_GAMEOVER_BGCOLOR_SUCCESS; bColor = WINDOW_GOALS_ACTUAL_COLOR; }
  //SDL_FillRect( MainScreen, NULL, 0 );
 // rectangleOnSurface( 0, 0, MainScreen, 200, 200, 0x00ff00ff, 0, 0 );
 // clear_surface( 0, 0, WINDOW_GAMEOVER_WIDTH, WINDOW_GAMEOVER_HEIGHT, lvl->R->screens[ SCREEN_GAME ].windows[ WINDOW_GAMEOVER ]->planes[ 0 ], wColor );
  rectangleOnSurface( 0, 0, lvl->R->screens[ SCREEN_GAME ].windows[ WINDOW_GAMEOVER ]->planes[ 0 ], WINDOW_GAMEOVER_WIDTH, WINDOW_GAMEOVER_HEIGHT, wColor, 2, bColor );
  if( lvl->complete ) {
    strcpy( lvl->gameOverText, "   Complete!" );
    lvl->R->screens[ SCREEN_GAME ].windows[ WINDOW_GAMEOVER ]->print( &lvl->R->font, 0, 10, lvl->R->menu.fH + 5, "    Mission" );
    lvl->R->screens[ SCREEN_GAME ].windows[ WINDOW_GAMEOVER ]->print( &lvl->R->font, 0, 10, lvl->R->menu.fH * 3 + 5, lvl->gameOverText );
  }
  else {
    lvl->R->screens[ SCREEN_GAME ].windows[ WINDOW_GAMEOVER ]->print( &lvl->R->font, 0, 10, lvl->R->menu.fH + 5, "Mission Failed:" );
    lvl->R->screens[ SCREEN_GAME ].windows[ WINDOW_GAMEOVER ]->print( &lvl->R->font, 0, 10, lvl->R->menu.fH * 3 + 5, lvl->gameOverText );
  }
  lvl->R->actualActiveWin = lvl->R->screens[ SCREEN_GAME ].windows[ WINDOW_GAMEOVER ];
  if( lvl->R->actualScreen != SCREEN_MENU )
    lvl->R->screens[ SCREEN_GAME ].windows[ WINDOW_GAMEOVER ]->redrawAllPlanes();
 // windowPushEvent( lvl->R->screens[ SCREEN_GAME ].windows[ WINDOW_GAMEOVER ], EVENT_UPDATE_INFO );

  //lvl->R->screens[ SCREEN_GAME ].windows[ WINDOW_LEVEL ]->print( &lvl->R->font, lvl->R->screens[ SCREEN_GAME ].windows[ WINDOW_LEVEL ]->regularPlanesNR - 1, 0, 0, "Game Over" );
}

char pressedDirKeys( Uint8 *keys ) {
  char s = 0;
  if( keys[ SDLK_UP ] ) s++;
  if( keys[ SDLK_LEFT ] ) s++;
  if( keys[ SDLK_RIGHT ] ) s++;
  if( keys[ SDLK_DOWN ] ) s++;

  return s;
}
int playerMoveThread( void *data ) {
  Player *p = (Player *)data;
  if( p->dontMove() ) { return 0; }
  while( p->state & B_MOVING ) SDL_Delay( MOV_DELAY );//return 0;
 // if( p->lvl->d_explosion > 2 ) SDL_Delay( MOV_DELAY );
 // if( p->look->endThread )
 //   p->look->newThread();
  p->state |= B_MOVING;
  Uint8 *keystate;
  bool changedDirection;
  bool m;
  p->movSectorCount = 0;
  while( true ) {
    m = false;
    changedDirection = false;
	if( p->lvl->magnetizePlayer || p->lvl->gameOver || p->lvl->complete ) break;
	if( p->look->movDX == 0 && p->look->movDY == 0 ) {
	SDL_Delay( 10 );
	  //p->lvl->checkMagnets();
	//if( p->lassoDirection == P_STAND ){
      if( p->prevSector->look != NULL && p->prevSector->look->id == T_CRUMBLE )
	  {
	    //p->prevSector->look->stop = false;
	    p->prevSector->look->newThread();
		//p->lvl->trash.push_back( p->prevSector->look );
        //p->lvl->scrap( p->prevSector->look );
		//p->prevSector->look = NULL;
		p->prevSector->look->type = 0;
		//SDL_Delay( MOV_DELAY );
		//break;
      }
	if( p->sector->look != NULL && (p->sector->look->type & B_ITEM) ) {
      //SDL_LockMutex( plane_mutex );
	  //if( p->lvl->checkMagnets() ) p->lvl->magnetizePlayer;
	  tileSequences *item = p->lvl->allSectors[ 1 ][ p->sector->row ][ p->sector->col ].look;
	  if( item != NULL ) {
	  //p->lvl->checkMagnets();
	  if( item->id == T_KEY1 )
	    p->items.key1++;
	  if( item->id == T_KEY2 )
	    p->items.key2++;
      if( item->id == T_KEY3 )
	    p->items.key3++;
  	  if( item->id == T_EA )
	    p->items.ea += ADD_AMMO;
	  if( item->id == T_MSA )
	    p->items.msa += ADD_AMMO;
      if( item->id == T_PU )
	    p->items.pu += ADD_AMMO;
      if( item->id == T_FUEL )
	    p->items.fuel += ADD_FUEL;
	  if( item->id == T_REPAIR ) {
	    p->hitPoints += ADD_REPAIR;
	    if( p->hitPoints > MAX_HITPOINTS ) p->hitPoints = MAX_HITPOINTS;
	  }
      if( item->id == T_TIME )
	    p->items.time += ADD_TIME;


	  //item->win->eraseFromPlane( item->ts->tiles[ 0 ], item->win->planes[ item->planeNR ], item->x, item->y );
       // item->erase();
		//p->lvl->trash.push_back( item );
        p->lvl->scrap( item );
		//p->lvl->allSectors[ 1 ][ p->sector->row ][ p->sector->col ].look = NULL;
		p->lvl->allSectors[ 1 ][ p->sector->row ][ p->sector->col ].look->type ^= B_ITEM;
		p->lvl->allSectors[ 1 ][ p->sector->row ][ p->sector->col ].look->type |= B_PASSABLE;
		p->lvl->allSectors[ 0 ][ p->sector->row ][ p->sector->col ].look->type |= B_PASSABLE;

		p->lvl->allSectors[ 0 ][ p->sector->row ][ p->sector->col ].look->type ^= B_ITEM;
        p->look->adjust();
		//delete p->lvl->allSectors[ 1 ][ p->sector->row ][ p->sector->col ].look;
		p->lvl->allSectors[ 1 ][ p->sector->row ][ p->sector->col ].look = NULL;
		p->lvl->updateInfo();
		p->lvl->checkMagnets();
		//SDL_UnlockMutex( plane_mutex );
     }
	}
	keystate = SDL_GetKeyState( NULL );
	if( pressedDirKeys( keystate ) < 2 ) {
	if( keystate[ SDLK_RIGHT ] ) {
      makeMov( changedDirection, m, p, P_RIGHT );

    }
	if( keystate[ SDLK_LEFT ] ) {
	  makeMov( changedDirection, m, p, P_LEFT );
    }
	if( keystate[ SDLK_UP ] ) {
	  makeMov( changedDirection, m, p, P_UP );
	}
    if( keystate[ SDLK_DOWN ] ) {
	  makeMov( changedDirection, m, p, P_DOWN );
    }
	if( !m && !changedDirection ) { break; }
/* } else {
     if( p->sector->look->id != T_CRUMBLE ) {
	 }
   }*/
    }
  }
   if( changedDirection ) {
	/*  int ii = 0;
	  while( true ){
	    Uint8 *keystateTMP = SDL_GetKeyState( NULL );
		if( *keystateTMP != *keystate ) break;
		SDL_Delay( MOV_DELAY );
		ii++;
		if( ii == 10 ) break;
	  }*/
	  SDL_Delay( PLAYER_START_MOV_DELAY );
	  changedDirection = false;

	}else { SDL_Delay( MOV_DELAY ); p->movSectorCount++; };





  }
  //p->look->movDX = p->look->movDY = 0;
  //printf( "$ " );
  //p->look->endThread = true;
  p->look->newThread();
  SDL_Delay( MOV_DELAY );

  p->state ^= B_MOVING;

  return 0;
}

/*
void movFunctionShot( tileSequences *ts ) {
  //Player *p = (Player *)data;
}*/

/*
void correctPlayerDirection( Player *p, uchar md ) {
  if( p->state & B_USING_MSA ) {
    if( md == P_UP & !(p->look->actualSeq == 0) ) { p->look->actualSeq = 0; p->look->win->drawTileSeq( p->look ); tileSequencesPushEvent( p->look, EVENT_FLIP_SCREEN ); }
    if( md == P_LEFT & !(p->look->actualSeq == 1) ) { p->look->actualSeq = 1; p->look->win->drawTileSeq( p->look ); tileSequencesPushEvent( p->look, EVENT_FLIP_SCREEN ); }
    if( md == P_RIGHT & !(p->look->actualSeq == 2) ) { p->look->actualSeq = 2; p->look->win->drawTileSeq( p->look ); tileSequencesPushEvent( p->look, EVENT_FLIP_SCREEN ); }
    if( md == P_DOWN & !(p->look->actualSeq == 3) ) { p->look->actualSeq = 3; p->look->win->drawTileSeq( p->look ); tileSequencesPushEvent( p->look, EVENT_FLIP_SCREEN ); }

  }
  if( p->state & B_USING_EA ) {
    if( md == P_UP & !(p->look->actualSeq == 4) ) { p->look->actualSeq = 4; p->look->win->drawTileSeq( p->look ); tileSequencesPushEvent( p->look, EVENT_FLIP_SCREEN ); }
    if( md == P_LEFT & !(p->look->actualSeq == 5) ) { p->look->actualSeq = 5; p->look->win->drawTileSeq( p->look ); tileSequencesPushEvent( p->look, EVENT_FLIP_SCREEN ); }
    if( md == P_RIGHT & !(p->look->actualSeq == 6) ) { p->look->actualSeq = 6; p->look->win->drawTileSeq( p->look ); tileSequencesPushEvent( p->look, EVENT_FLIP_SCREEN ); }
    if( md == P_DOWN & !(p->look->actualSeq == 7) ) { p->look->actualSeq = 7; p->look->win->drawTileSeq( p->look ); tileSequencesPushEvent( p->look, EVENT_FLIP_SCREEN ); }

  }
}
*/
void makeShot( Player *p, tileSequences *sl, uchar md ) {
 if( p->dontShoot() ) return;
 sl->collisionX = sl->collisionY = -1;
 int colOff = 0, rowOff = 0, xOff, yOff;
 xOff = yOff = TileWidth - TileWidth / 4;
 int mdeltaX = MOV_DELTA, mdeltaY = MOV_DELTA;
// int distCount = (checkDistance( p, md ) - 1) * TileWidth / MOV_DELTA;
 //printf( "%d ", checkDistance( p, md ) );
// int mcountX = distCount, mcountY = distCount;
 if( md == P_UP ) {
   rowOff = -1;
   mdeltaX = 0;
   mdeltaY = -mdeltaY;
   xOff = 0;
   yOff = -yOff;
//   mcountX = 0;
 }
 if( md == P_RIGHT ) {
   colOff = 1;
   mdeltaY = 0;
   yOff = 0;
//   mcountY = 0;
 }
 if( md == P_LEFT ) {
   colOff = -1;
   mdeltaY = 0;
   mdeltaX = -mdeltaX;
   yOff = 0;
   xOff = -xOff;
//   mcountY = 0;
 }

 if( md == P_DOWN ) {
   rowOff = 1;
   mdeltaX = 0;
   xOff = 0;
 //  mcountX = 0;
 }
     sl->x = p->lvl->allSectors[ 1 ][ p->sector->row ][ p->sector->col ].x + xOff;// + TileWidth / 3;
	 sl->y = p->lvl->allSectors[ 1 ][ p->sector->row ][ p->sector->col ].y + yOff; //
     sl->movDX = mdeltaX;
     sl->movDY = mdeltaY;
 //    sl->useCounter = true;
 //    sl->movCounterX = mcountX;
 //    sl->movCounterY = mcountY;
     sl->actualSeq = 1;
	 sl->timing = MOV_SHOT_DELAY;
	 //sl->loopedAnimation = true;
	 sl->collisionCheck = true;
	 sl->fullCollisionCheck = true;
	 sl->stop = true;
	 sl->sv[ 0 ]->currentFrame = 0;
	 //p->state |= B_SHOOTING;
	 //correctPlayerDirection( p, md );
   if( p->lvl->allSectors[ 1 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look == NULL ) // || (p->lvl->allSectors[ 1 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look != NULL && (p->lvl->allSectors[ 1 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look->type & B_PASSABLE)) )
   {
     //sl->sv[ 0 ]->currentFrame = 0;
	 p->state |= B_SHOOTING;
	 sl->newThread();
	 if( sl->id == ID_ANIMATION_EXPLODE_EA ) { p->items.ea--; p->lvl->updateInfo(); }
	 if( sl->id == ID_ANIMATION_EXPLODE_MSA ) { p->items.msa--; p->lvl->updateInfo(); }
     //p->lvl->updateInfo();
   } else if( (sl->id == ID_ANIMATION_EXPLODE_EA && p->lvl->EA_damage_mod < 9) || (sl->id == ID_ANIMATION_EXPLODE_MSA && p->lvl->MSA_damage_mod < 9) ){
    // sl->sv[ 0 ]->currentFrame = 0;
	 p->state |= B_SHOOTING;
     sl->x = p->look->x;
     sl->y = p->look->y;

     sl->prev_movDX = mdeltaX;
     sl->prev_movDY = mdeltaY;
     sl->collisionX = p->lvl->allSectors[ 0 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].x;
     sl->collisionY = p->lvl->allSectors[ 0 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].y;

	 if( sl->id == ID_ANIMATION_EXPLODE_EA ) {
	   p->hitPoints -= p->lvl->EA_damage_mod;
	   p->items.ea--;
	   p->lvl->updateInfo();
	 }
	 if( sl->id == ID_ANIMATION_EXPLODE_MSA ) {
	   p->hitPoints -= p->lvl->MSA_damage_mod;
	   p->items.msa--;
	   p->lvl->updateInfo();
	 }
	 if( p->hitPoints < 1 && !p->lvl->complete ) {
	   makeExplosion( p->sector->row, p->sector->col, p->lvl->R, p->lvl, 0 );
	   p->lvl->gameOver = true;
	   strcpy( p->lvl->gameOverText, " Full damage" );
	   p->look->erase();
	   //p->lvl->scrap( p->look );
	 } else endingShot( p, sl->id, p->lvl->R );
     //tileSequencesPushEvent( sl, EVENT_TILESET_COLLIDED );


   }

}

void makeNR( int id_nr, int row, int col, appResources *Res, Level *lvl ) {
  tileSequences *l = newTileSequence( id_nr, Res->mainTileset.tiles[ id_nr ], lvl->allSectors[ 1 ][ row ][ col ].x, lvl->allSectors[ 1 ][ row ][ col ].y );
  lvl->allSectors[ 1 ][ row ][ col ].look = l;
  l->type |= B_MOVABLE;
  lvl->win->associate( lvl->floorPlane + 1, lvl->allSectors[ 1 ][ row ][ col ].look, 0, lvl->allSectors[ 1 ][ row ][ col ].x, lvl->allSectors[ 1 ][ row ][ col ].y, MOV_DELAY );
  lvl->win->drawOnPlane( Res->mainTileset.tiles[ id_nr ], lvl->win->planes[ lvl->floorPlane + 1 ], lvl->allSectors[ 1 ][ row ][ col ].x, lvl->allSectors[ 1 ][ row ][ col ].y );

}

void makeSplash( int row, int col, appResources *Res, Level *lvl ) {
  tileSequences *splash = newTileSequencesFrom( &Res->animations[ ID_ANIMATION_SPLASH ], ID_ANIMATION_SPLASH );
  splash->x = lvl->allSectors[ 0 ][ row ][ col ].x;
  splash->y = lvl->allSectors[ 0 ][ row ][ col ].y;
  lvl->win->associate( lvl->floorPlane, splash, 0, splash->x, splash->y, EXPLODE_SHOT_DELAY);
  splash->collisionCheck = false;
  splash->stop = false;
  splash->newThread();
}
void makeExplosion( int row, int col, appResources *Res, Level *lvl, int explosion_ext_id ) {
  SDL_LockMutex( plane_mutex );

  tileSequences *explosion = newTileSequencesFrom( &Res->animations[ ID_ANIMATION_EXPLODE ], ID_ANIMATION_EXPLODE );
  if( explosion_ext_id == T_DYNAMITE ) {
   // lvl->d_explosion = true;
	explosion->memMovX = T_DYNAMITE;
  }
  explosion->x = lvl->allSectors[ 0 ][ row ][ col ].x;
  explosion->y = lvl->allSectors[ 0 ][ row ][ col ].y;
  lvl->win->associate( lvl->floorPlane + 2, explosion, 0, explosion->x, explosion->y, EXPLODE_SHOT_DELAY);
  explosion->collisionCheck = false;
  explosion->stop = false;
  explosion->newThread();
  SDL_UnlockMutex( plane_mutex );
}

bool magnetAtPlayer( row_col magnet, Level *lvl ) {
  if( lvl->player.look->movDX == 0 && lvl->player.look->movDY == 0 ) {
  bool mag = false;
  if( magnet.row < 0 ) magnet.row = -magnet.row;
  if( magnet.col < 0 ) magnet.col = -magnet.col;
  if( lvl->allSectors[ 1 ][ magnet.row ][ magnet.col ].look != NULL && lvl->allSectors[ 1 ][ magnet.row ][ magnet.col ].look->id == T_MAGNET && magnet.col == lvl->player.sector->col && lvl->player.sector->row < magnet.row ) {
    for( int i = lvl->player.sector->row; i < magnet.row; i++ )
      if( lvl->allSectors[ 0 ][ i ][ magnet.col ].look != NULL && (!(lvl->allSectors[ 0 ][ i ][ magnet.col ].look->type & B_PASSABLE) || (lvl->allSectors[ 0 ][ i ][ magnet.col ].look->type & B_ITEM)) ) return false;
      mag = true;
	  if( lvl->player.sector->row == magnet.row - 1 && !lvl->complete ) {
	    makeExplosion( lvl->player.sector->row, lvl->player.sector->col, lvl->R, lvl, 0 );
		lvl->gameOver = true;
		lvl->player.look->erase();
		//lvl->scrap( lvl->player.look );
	  } else {

		  lvl->player.look->movDX = 0;
		  lvl->player.look->movDY = MOV_DELTA;
		  lvl->magnetizePlayer = true;
		  lvl->player.look->movCounterX = lvl->player.look->movCounterY = TileWidth / MOV_DELTA;
		  lvl->player.prevSector = lvl->player.sector;
		  lvl->player.sector = &lvl->allSectors[ 0 ][ lvl->player.sector->row + 1 ][ magnet.col ];
		  lvl->player.look->newThread();
	  }

  }

    if( lvl->allSectors[ 1 ][ magnet.row ][ magnet.col ].look != NULL && lvl->allSectors[ 1 ][ magnet.row ][ magnet.col ].look->id == T_MAGNET_DOWN && magnet.col == lvl->player.sector->col && lvl->player.sector->row > magnet.row ) {
    for( int i = lvl->player.sector->row; i > magnet.row; i-- )
      if( lvl->allSectors[ 0 ][ i ][ magnet.col ].look != NULL && (!(lvl->allSectors[ 0 ][ i ][ magnet.col ].look->type & B_PASSABLE) || (lvl->allSectors[ 0 ][ i ][ magnet.col ].look->type & B_ITEM)) ) return false;
      mag = true;
	  if( lvl->player.sector->row == magnet.row + 1 && !lvl->complete ) {
	    makeExplosion( lvl->player.sector->row, lvl->player.sector->col, lvl->R, lvl, 0 );
		lvl->gameOver = true;
		lvl->player.look->erase();
		//lvl->scrap( lvl->player.look );
	  } else {

		  lvl->player.look->movDX = 0;
		  lvl->player.look->movDY = -MOV_DELTA;
		  lvl->magnetizePlayer = true;
		  lvl->player.look->movCounterX = lvl->player.look->movCounterY = TileWidth / MOV_DELTA;
		  lvl->player.prevSector = lvl->player.sector;
		  lvl->player.sector = &lvl->allSectors[ 0 ][ lvl->player.sector->row - 1 ][ magnet.col ];
		  lvl->player.look->newThread();
	  }

  }

    if( lvl->allSectors[ 1 ][ magnet.row ][ magnet.col ].look != NULL && lvl->allSectors[ 1 ][ magnet.row ][ magnet.col ].look->id == T_MAGNET_LEFT && magnet.row == lvl->player.sector->row && lvl->player.sector->col < magnet.col ) {
    for( int i = lvl->player.sector->col; i < magnet.col; i++ )
      if( lvl->allSectors[ 0 ][ magnet.row ][ i ].look != NULL && (!(lvl->allSectors[ 0 ][ magnet.row ][ i ].look->type & B_PASSABLE) || (lvl->allSectors[ 0 ][ magnet.row ][ i ].look->type & B_ITEM)) ) return false;
      mag = true;
	  if( lvl->player.sector->col == magnet.col - 1 && !lvl->complete ) {
	    makeExplosion( lvl->player.sector->row, lvl->player.sector->col, lvl->R, lvl, 0 );
		lvl->gameOver = true;
		lvl->player.look->erase();
		//lvl->scrap( lvl->player.look );
	  } else {

		  lvl->player.look->movDX = MOV_DELTA;
		  lvl->player.look->movDY = 0;
		  lvl->magnetizePlayer = true;
		  lvl->player.look->movCounterX = TileWidth / MOV_DELTA;
		  lvl->player.look->movCounterY = 0;
		  lvl->player.prevSector = lvl->player.sector;
		  lvl->player.sector = &lvl->allSectors[ 0 ][ magnet.row ][ lvl->player.sector->col + 1 ];
		  lvl->player.look->newThread();
	  }

  }

      if( lvl->allSectors[ 1 ][ magnet.row ][ magnet.col ].look != NULL && lvl->allSectors[ 1 ][ magnet.row ][ magnet.col ].look->id == T_MAGNET_RIGHT && magnet.row == lvl->player.sector->row && lvl->player.sector->col > magnet.col ) {
    for( int i = lvl->player.sector->col; i > magnet.col; i-- )
      if( lvl->allSectors[ 0 ][ magnet.row ][ i ].look != NULL && (!(lvl->allSectors[ 0 ][ magnet.row ][ i ].look->type & B_PASSABLE) || (lvl->allSectors[ 0 ][ magnet.row ][ i ].look->type & B_ITEM)) ) return false;
      mag = true;
	  if( lvl->player.sector->col == magnet.col + 1 && !lvl->complete ) {
	    makeExplosion( lvl->player.sector->row, lvl->player.sector->col, lvl->R, lvl, 0 );
		lvl->gameOver = true;
		lvl->player.look->erase();
		//lvl->scrap( lvl->player.look );
	  } else {

		  lvl->player.look->movDX = -MOV_DELTA;
		  lvl->player.look->movDY = 0;
		  lvl->magnetizePlayer = true;
		  lvl->player.look->movCounterX = TileWidth / MOV_DELTA;
		  lvl->player.look->movCounterY = 0;
		  lvl->player.prevSector = lvl->player.sector;
		  lvl->player.sector = &lvl->allSectors[ 0 ][ magnet.row ][ lvl->player.sector->col - 1 ];
		  lvl->player.look->newThread();
	  }

  }
  if( mag && lvl->magnets.size() > 1 ) {
    row_col tmp;
	tmp.row = magnet.row;
	tmp.col = magnet.col;
	lvl->magnets.clear();
	lvl->magnets.push_back( tmp );
  }
  if( lvl->gameOver && !lvl->complete ) {
    strcpy( lvl->gameOverText, "  Magnetized" );
  }
  if( mag ) return true;
  else return false;
  //printf( "%d ", lvl->allSectors[ 1 ][ magnet.row ][ magnet.col ].look->id );
  
  } else return false;
}



bool Level::checkMagnets() {

  int s = magnets.size();
  for( int i = 0; i < s; i++ )
    if( (magnets[ i ].row >= 0 && player.sector->row == magnets[ i ].row) || (magnets[ i ].col >= 0 && player.sector->col == magnets[ i ].col) ) {
	  if( magnetAtPlayer( magnets[ i ], this ) ) return true;
	}
  return false;
}

void quartersColors( int qs, int &q1, int &q2, int &q3, int &q4 ) {
  q1 = qs & 3;
  qs >>= 2;
  q2 = qs & 3;
  qs >>= 2;
  q3 = qs & 3;
  qs >>= 2;
  q4 = qs & 3;

}
void quartersColorSum( int q1, int q2, int q3, int q4, int &c1s, int &c2s, int &c3s ) {
  if( q1 == 1 ) c1s++;
  if( q2 == 1 ) c1s++;
  if( q3 == 1 ) c1s++;
  if( q4 == 1 ) c1s++;
  if( q1 == 2 ) c2s++;
  if( q2 == 2 ) c2s++;
  if( q3 == 2 ) c2s++;
  if( q4 == 2 ) c2s++;
  if( q1 == 3 ) c3s++;
  if( q2 == 3 ) c3s++;
  if( q3 == 3 ) c3s++;
  if( q4 == 3 ) c3s++;


}
int fullHole( int qs ) {
  int q1, q2, q3, q4, c1s = 0, c2s = 0, c3s = 0;
  quartersColors( qs, q1, q2, q3, q4 );
  quartersColorSum( q1, q2, q3, q4, c1s, c2s, c3s );
 // printf( "q1=%d; q2=%d; q3=%d; q4=%d \n", q1, q2, q3, q4 );
  if( c1s == 2 && c2s == 2 ) return T_BALL2;
  if( c1s == 2 && c3s == 2 ) return T_BALL6;
  if( c2s == 2 && c3s == 2 ) return T_BALL4;

  return -1;
}

void makePlatform( int p_id, Level *lvl, int row, int col ) {
  tileSequences *l = newTileSequence( p_id, lvl->R->mainTileset.tiles[ p_id ], lvl->allSectors[ 0 ][ row ][ col ].x, lvl->allSectors[ 0 ][ row ][ col ].y );
  lvl->allSectors[ 0 ][ row ][ col ].look = l;
 // lvl->win->associate( lvl->floorPlane, lvl->allSectors[ 0 ][ row ][ col ].look, 0, lvl->allSectors[ 0 ][ row ][ col ].x, lvl->allSectors[ 0 ][ row ][ col ].y, MOV_DELAY );
  
  lvl->win->drawOnPlane( lvl->R->mainTileset.tiles[ p_id ], lvl->win->planes[ lvl->floorPlane ], lvl->allSectors[ 0 ][ row ][ col ].x, lvl->allSectors[ 0 ][ row ][ col ].y );
  lvl->allSectors[ 1 ][ row ][ col ].look->type = 0;
  lvl->allSectors[ 0 ][ row ][ col ].look->type = 0;
  lvl->allSectors[ 1 ][ row ][ col ].look->type |= B_PASSABLE;
  lvl->allSectors[ 0 ][ row ][ col ].look->type |= B_PASSABLE;
  lvl->allSectors[ 1 ][ row ][ col ].look = NULL;
  
  
  tileSequencesPushEvent( lvl->allSectors[ 0 ][ row ][ col ].look, EVENT_TILESET_ANIMATION );
}

void createBall( int ballID, Level *lvl, int row, int col ) {
  tileSequences *l = newTileSequence( ballID, lvl->R->mainTileset.tiles[ ballID ], lvl->allSectors[ 1 ][ row ][ col ].x, lvl->allSectors[ 1 ][ row ][ col ].y );
  lvl->allSectors[ 1 ][ row ][ col ].look = l;
  l->type |= B_MOVABLE;
  lvl->win->associate( lvl->floorPlane + 1, lvl->allSectors[ 1 ][ row ][ col ].look, 0, lvl->allSectors[ 1 ][ row ][ col ].x, lvl->allSectors[ 1 ][ row ][ col ].y, BALL_MOV_DELAY );
  lvl->win->drawOnPlane( lvl->R->mainTileset.tiles[ ballID ], lvl->win->planes[ lvl->floorPlane + 1 ], lvl->allSectors[ 1 ][ row ][ col ].x, lvl->allSectors[ 1 ][ row ][ col ].y );
  lvl->allSectors[ 0 ][ row ][ col ].look->type = 0;
//  lvl->allSectors[ 0 ][ row ][ col ].look->type ^= B_PASSABLE;
  lvl->allSectors[ 1 ][ row ][ col ].look->type |= B_MOVABLE;
  tileSequencesPushEvent( lvl->allSectors[ 1 ][ row ][ col ].look, EVENT_TILESET_ANIMATION );
}

bool fullHoleForColor( int b, int q1, int q2, int q3, int q4 ) {
  char sum = 0;
  bool diversity = false;
  if( (q1 != 0 && q2 != 0 && q1 != q2) || (q1 != 0 && q3 != 0 && q1 != q3) )
    diversity = true;
  if( b == q1 ) sum++;
  if( b == q2 ) sum++;
  if( b == q3 ) sum++;
  if( b == q4 ) sum++;
  if( sum > 1 ) return true;
  if( sum == 0 && diversity ) return true;
  return false;
}

int checkQuarters( Uint32 ball, int &quarters ) {
  if( ball != T_BALL1 && ball != T_BALL3 && ball != T_BALL5 )
    return -1;

  int b;
  if( ball == T_BALL1 ) b = 1;
  if( ball == T_BALL3 ) b = 2;
  if( ball == T_BALL5 ) b = 3;

 // int qs = quarters;
  int q1, q2, q3, q4;
  quartersColors( quarters, q1, q2, q3, q4 );
  //printf( "q1=%d; q2=%d; q3=%d; q4=%d \n", q1, q2, q3, q4 );
  if( fullHoleForColor( b, q1, q2, q3, q4 ) ) return -1;

  if( q1 == 0 ) {
    quarters |= b;
	if( b == 1 ) return T_QUARTER1_UP;
	if( b == 2 ) return T_QUARTER2_UP;
	if( b == 3 ) return T_QUARTER3_UP;
  }

  if( q2 == 0 ) {
    b <<= 2;
    quarters |= b;
	if( b == 1 << 2 ) return T_QUARTER1_DOWN;
	if( b == 2 << 2 ) return T_QUARTER2_DOWN;
	if( b == 3 << 2 ) return T_QUARTER3_DOWN;
  }
  if( q3 == 0 ) {
    b <<= 4;
    quarters |= b;
	if( b == 1 << 4 ) return T_QUARTER1_LEFT;
	if( b == 2 << 4 ) return T_QUARTER2_LEFT;
	if( b == 3 << 4 ) return T_QUARTER3_LEFT;
  }
  if( q4 == 0 ) {
    b <<= 6;
    quarters |= b;
	if( b == 1 << 6 ) return T_QUARTER1_RIGHT;
	if( b == 2 << 6 ) return T_QUARTER2_RIGHT;
	if( b == 3 << 6 ) return T_QUARTER3_RIGHT;
  }
 return -1;
}

bool checkPass( int b, int p, int rowOff, int colOff, uchar type ) {
  bool pass = false;

  if( (p >= T_PASS1 && p <= T_PASS6) || (p >= T_PASS1_H && p <= T_PASS6_H) || (p >= T_PASS1_LEFT && p <= T_PASS6_DOWN) )
    pass = true;
  if( pass && ((type & B_ITEM) || b == T_BOX) ) return false;
  if( pass && ((b >= T_DN0 && b <= T_DN9) || (b >= T_N0 && b <= T_N9)) ) return false;
  if( pass && b == T_BALL7 ) return false;
  if( pass && (b == T_BALL1 || b == T_GEM1) )
    if( !(p == T_PASS1 || p == T_PASS1_H) && !(p == T_PASS1_UP && rowOff < 0) && !(p == T_PASS1_DOWN && rowOff > 0) && !(p == T_PASS1_RIGHT && colOff > 0) && !(p == T_PASS1_LEFT && colOff < 0) )
  	  return false;
  if( pass && (b == T_BALL2 || b == T_GEM2) )
    if( !(p == T_PASS2 || p == T_PASS2_H) && !(p == T_PASS2_UP && rowOff < 0) && !(p == T_PASS2_DOWN && rowOff > 0) && !(p == T_PASS2_RIGHT && colOff > 0) && !(p == T_PASS2_LEFT && colOff < 0) )
  	  return false;
  if( pass && (b == T_BALL3 || b == T_GEM3) )
    if( !(p == T_PASS3 || p == T_PASS3_H) && !(p == T_PASS3_UP && rowOff < 0) && !(p == T_PASS3_DOWN && rowOff > 0) && !(p == T_PASS3_RIGHT && colOff > 0) && !(p == T_PASS3_LEFT && colOff < 0) )
  	  return false;
  if( pass && (b == T_BALL4 || b == T_GEM4) )
    if( !(p == T_PASS4 || p == T_PASS4_H) && !(p == T_PASS4_UP && rowOff < 0) && !(p == T_PASS4_DOWN && rowOff > 0) && !(p == T_PASS4_RIGHT && colOff > 0) && !(p == T_PASS4_LEFT && colOff < 0) )
  	  return false;
  if( pass && (b == T_BALL5 || b == T_GEM5) )
    if( !(p == T_PASS5 || p == T_PASS5_H) && !(p == T_PASS5_UP && rowOff < 0) && !(p == T_PASS5_DOWN && rowOff > 0) && !(p == T_PASS5_RIGHT && colOff > 0) && !(p == T_PASS5_LEFT && colOff < 0) )
  	  return false;
  if( pass && (b == T_BALL6 || b == T_GEM6) )
    if( !(p == T_PASS6 || p == T_PASS6_H) && !(p == T_PASS6_UP && rowOff < 0) && !(p == T_PASS6_DOWN && rowOff > 0) && !(p == T_PASS6_RIGHT && colOff > 0) && !(p == T_PASS6_LEFT && colOff < 0) )
  	  return false;
  return true;
}
void Level::removeMagnet( int row, int col ) {
  int mID = allSectors[ 1 ][ row ][ col ].look->id;
  if( mID == T_MAGNET || mID == T_MAGNET_DOWN ) row = -row;
  if( mID == T_MAGNET_LEFT || mID == T_MAGNET_RIGHT ) col = -col;
  SDL_LockMutex( plane_mutex );
  int s = magnets.size();
  for( int i = 0; i < s; i++ )
    if( magnets[ i ].row == row && magnets[ i ].col == col ) {
	  magnets.erase( magnets.begin() + i );
	}
  SDL_UnlockMutex( plane_mutex );
}

void exploded( Player *p, int row, int col ) {
SDL_LockMutex( plane_mutex );
  Sector *c = &p->lvl->allSectors[ 1 ][ row ][ col ];
  Sector *cf = &p->lvl->allSectors[ 0 ][ row ][ col ];

 // if( c->look != NULL && (p->state & B_USING_EA) && ((c->look->type & B_ITEM) || c->look->id == T_OBSTACLE) ) {
  if( c->look != NULL ) {
	if( c->look->id == T_DYNAMITE ) {
	  int hCol = col - 1, hRow = row - 1;
	  for( int i = 0; i < 3; i++ ) {
	    for( int j = 0; j < 3; j++ ) {
		  if( hCol + j > -1 && hCol + j < p->lvl->allCols && hRow + i > -1 && hRow + i < p->lvl->allRows ) {
		    Sector *obj = &p->lvl->allSectors[ 1 ][ hRow + i ][ hCol + j ];
			Sector *obj_f = &p->lvl->allSectors[ 0 ][ hRow + i ][ hCol + j ];
			int exp_ext_id = 0;
            if( obj->look != NULL && obj->look->id == T_DYNAMITE ) exp_ext_id = T_DYNAMITE;
            makeExplosion( hRow + i, hCol + j, p->lvl->R, p->lvl, exp_ext_id );
            //printf( "Exploded at: %d %d ; player at: %d %d\n", hRow + i, hCol + j, p->sector->row, p->sector->col );
				  if( !p->lvl->complete && p->sector->row == hRow + i && p->sector->col == hCol + j ) {
				    p->hitPoints -= 9;
					strcpy( p->lvl->gameOverText, "  Full damage" );
					p->lvl->magnetizePlayer = false;
					p->lvl->gameOver = true;
					p->look->erase();
				    p->lvl->updateInfo();
				  }

			if( obj->look != NULL && !(obj->look->id == T_WALL) && !(obj->look->id >= T_GEM1 && obj->look->id <= T_GEM6) && !(obj->look->id >= T_BALL1 && obj->look->id <= T_BALL6 || obj->look->id == T_BALL7) && !(obj->look->id == T_GEM_DARK) ) {
			  //obj->look->type = 0;
	          obj_f->look->type = 0;
	          obj_f->look->type |= B_PASSABLE;
	          //obj->type |= B_PASSABLE;
			  if( !p->lvl->magnetizePlayer && ((obj->look->id >= T_MAGNET_LEFT && obj->look->id <= T_MAGNET_DOWN) || obj->look->id == T_MAGNET) )
			    p->lvl->removeMagnet( hRow + i, hCol + j );
			  if( obj->look->id == T_DYNAMITE && !(hRow + i == row && hCol + j == col) ) {//!(i == 1 && j == 1) ) {
                row_col dRowCol;
				dRowCol.row = hRow + i;
				dRowCol.col = hCol + j;
				SDL_LockMutex( plane_mutex );
				obj->look->type ^= B_MOVABLE;
				allThreads++;
			    p->lvl->otherDynamites.push_back( dRowCol );
                SDL_UnlockMutex( plane_mutex );
              }	else {
			    bool emptySector = true;

				//if( obj->look->id != T_DYNAMITE )
			      p->lvl->scrap( obj->look );
				//else   obj->look->type |= B_EXPLODED;
			    if( (obj->look->id >= T_N1 && obj->look->id <= T_N9) ) {
				 // p->lvl->scrap( obj->look );
				  makeNR( obj->look->id - 1, hRow + i, hCol + j, p->lvl->R, p->lvl );
				  p->lvl->allSectors[ 0 ][ hRow + i ][ hCol + j ].look->type = 0;
				  p->lvl->allSectors[ 0 ][ hRow + i ][ hCol + j ].look->type |= B_MOVABLE;

                  emptySector = false;
			    }
				if( obj->look->id == T_DN0 ) {
				  makeNR( T_GEM_DARK, hRow + i, hCol + j, p->lvl->R, p->lvl );
				  p->lvl->allSectors[ 0 ][ hRow + i ][ hCol + j ].look->type = 0;
				  p->lvl->allSectors[ 1 ][ hRow + i ][ hCol + j ].look->type = 0;

				  emptySector = false;
				}
				if( (obj->look->id >= T_DN1 && obj->look->id <= T_DN9) ) {
				 // p->lvl->scrap( obj->look );
				  makeNR( obj->look->id - 1, hRow + i, hCol + j, p->lvl->R, p->lvl );
				  p->lvl->allSectors[ 0 ][ hRow + i ][ hCol + j ].look->type = 0;
				  p->lvl->allSectors[ 0 ][ hRow + i ][ hCol + j ].look->type |= B_MOVABLE;

                  emptySector = false;
			    }
				//p->lvl->scrap( obj->look );
				if( emptySector )// && obj->look->id != T_DYNAMITE )
	              obj->look = NULL;
			  }
			}
		  }
		}
	  }
	/*  int s = otherDynamites.size();
	  for( int i = 0; i < s; i++ )
	    exploded( p, otherDynamites[ i ].row, otherDynamites[ i ].col );
	    */
	} else {
	   makeExplosion( row, col, p->lvl->R, p->lvl, 0 );
       c->look->type = 0;
	   cf->look->type = 0;
	   cf->look->type |= B_PASSABLE;
	   c->look->type |= B_PASSABLE;
	   p->lvl->scrap( c->look );
	   c->look = NULL;
	}

 }
  //}
SDL_UnlockMutex( plane_mutex );
 }


void endingShot( Player *p, int ID, appResources *Res ) {
  tileSequences *s;
  if( ID == ID_ANIMATION_EXPLODE_EA ) s = Res->shotEA;
  if( ID == ID_ANIMATION_EXPLODE_MSA ) s = Res->shotMSA;

//  s->useCounter = false;
  s->actualSeq = 0;
  s->movDX = s->movDY = 0;
 // s->loopedAnimation = false;
  s->collisionCheck = false;
  s->stop = false;
  s->timing = EXPLODE_SHOT_DELAY;

  int row = 0, col = 0;
  tileSector( s->collisionX, s->collisionY, row, col );
  Sector *c = &p->lvl->allSectors[ 1 ][ row ][ col ];
  Sector *cf = &p->lvl->allSectors[ 0 ][ row ][ col ];
  int rowOff = 0, colOff = 0;
  if( s->prev_movDX < 0 && (col - 1 >= 0) ) colOff = -1;
  if( s->prev_movDX > 0 && (col + 1 < p->lvl->allCols ) ) colOff = 1;
  if( s->prev_movDY > 0 && (row + 1 < p->lvl->allRows ) ) rowOff = 1;
  if( s->prev_movDY < 0 && (row - 1 >= 0) ) rowOff = -1;
  Sector *f = &p->lvl->allSectors[ 0 ][ row + rowOff ][ col + colOff ];
  Sector *af = &p->lvl->allSectors[ 1 ][ row + rowOff ][ col + colOff ];
  s->newThread();
  if( c->look != NULL ) {
  bool launchedDynamite = false;
  if( c->look->id == T_DYNAMITE && !(c->look->type & B_MOVABLE) ) launchedDynamite = true;

  if( (p->state & B_USING_EA) && ((c->look->type & B_ITEM) || c->look->id == T_OBSTACLE) && !launchedDynamite ) {
    exploded( p, row, col );
 /*   makeExplosion( row, col, Res, p->lvl );
	if( c->look->type & B_ITEM ) {
	  cf->look->type ^= B_ITEM;
	  c->look->type ^= B_ITEM;

    }
	  cf->look->type |= B_PASSABLE;
	  c->look->type |= B_PASSABLE;

    //c->look->erase();
    //SDL_CreateThread( deleteTileSeq, c->look );
    p->lvl->scrap( c->look );


	//p->lvl->trash.push_back( c->look );


	c->look = NULL;
*/
	return;
  }

    if( (p->state & B_USING_MSA) && ((c->look->type & B_MOVABLE) || (c->look->type & B_ITEM)) || ((p->state & B_USING_EA) && (c->look->type & B_MOVABLE) && !(c->look->type & B_ITEM)) && !launchedDynamite )
	{

	  bool movIt = true;
	  if( (c->look->id >= T_BALL1 && c->look->id <= T_BALL6) || c->look->id == T_BALL7 ) {
        c->look->timing = BALL_MOV_DELAY;
        if( f->look != NULL )
		  movIt = checkPass( c->look->id, f->look->id, rowOff, colOff, c->look->type );

	  } else {
    //  if( c->look->id >= T_GEM1 && c->look->id <= T_GEM6 ) {
        if( f->look != NULL )
		  movIt = checkPass( c->look->id, f->look->id, rowOff, colOff, c->look->type );
	    
	  }
	 // if( c->look->type & B_ITEM ) movIt = false;
      if( movIt ) {
	    if( f != NULL && f->look != NULL && (f->look->type & B_PASSABLE) && af->look == NULL || (f->look == NULL && af->look == NULL && (c->look->id >= T_GEM1 && c->look->id <= T_BALL6 || c->look->id == T_BALL7 || c->look->id == T_PLATFORM_M)) || (f->look == NULL && af->look == NULL && (p->state & B_USING_MSA) && (c->look->type & B_ITEM)) ) {
		  af->look = c->look;
	      c->look = NULL;

		  if( cf->look != NULL )cf->look->type |= B_PASSABLE;
		  if( cf->look->type & B_ITEM ) { cf->look->type ^= B_ITEM; if( f->look != NULL ) f->look->type |= B_ITEM; if( af->look != NULL ) af->look->type |= B_ITEM; if( af->look->id == T_DYNAMITE ) f->look->type ^= B_PASSABLE;}
		  else if( f->look != NULL ) f->look->type ^= B_PASSABLE;


		  af->look->movDX = s->prev_movDX;
	      af->look->movDY = s->prev_movDY;
		  //if( (af->look->id >= T_BALL1 && af->look->id <= T_BALL6) || af->look->id == T_BALL7 )
		    //allThreads++;
	      af->look->useCounter = true;
	      af->look->movCounterX = af->look->movCounterY = TileWidth / MOV_DELTA;
		  //af->look->timing = MOV_DELAY;


		    af->look->newThread();
		    if( cf->look != NULL && cf->look->id == T_CRUMBLE ) {
		      cf->look->newThread();
		    //p->lvl->trash.push_back( cf->look );
            //p->lvl->scrap( cf->look );
              //cf->look = NULL;
			  cf->look->type = 0;
		    }
          }
	    }
		//if( (f->look == NULL && af->look == NULL && (c->look->id >= T_GEM1 && c->look->id <= T_BALL6)) ) {
		//}

	/*  if( movIt ) {

	  }*/
	 // s->newThread();
	}
  }
  //printf( "(%d, %d) {%d %d}\n", row, col, s->prev_movDX, s->prev_movDY );
}

int playerShotThread( void *data ) {
  Player *p = (Player *)data;
  if( (p->state & B_SHOOTING) && p->shotQueue ) return 0;
  if( (p->state & B_SHOOTING) && !p->shotQueue ) { p->shotQueue = true; SDL_Delay( MOV_DELAY ); }

  while( true ) {
    bool s = false;
    Uint8 *keystate = SDL_GetKeyState( NULL );

	if( (keystate[ SDLK_LCTRL ] || keystate[ SDLK_RCTRL ]) && !keystate[ SDLK_RALT ] ) {

	  if( !(p->state & B_SHOOTING) ) {

	    if( (p->look->actualSeq == P_UP || p->look->actualSeq == P_UP + 4 || p->look->actualSeq == P_UP + 8)  && p->sector->row > 0 ) {
		   /*if( p->lvl->allSectors[ 1 ][ p->sector->row - 1 ][ p->sector->col ].look == NULL || (p->lvl->allSectors[ 1 ][ p->sector->row - 1 ][ p->sector->col ].look != NULL && (p->lvl->allSectors[ 1 ][ p->sector->row - 1 ][ p->sector->col ].look->type & B_PASSABLE)) )
		   {
		     p->lvl->R->shotMSA->x = p->lvl->allSectors[ 1 ][ p->sector->row ][ p->sector->col ].x;// + TileWidth / 3;
			 p->lvl->R->shotMSA->y = p->lvl->allSectors[ 1 ][ p->sector->row ][ p->sector->col ].y - TileWidth + TileWidth / 4;
             p->lvl->R->shotMSA->movDX = 0;
             p->lvl->R->shotMSA->movDY = -MOV_DELTA;
             p->lvl->R->shotMSA->actualSeq = 1;
			 p->lvl->R->shotMSA->timing = MOV_SHOT_DELAY;
			 //p->lvl->R->shotMSA->loopedAnimation = true;
			 p->lvl->R->shotMSA->stop = true;
			 p->lvl->R->shotMSA->collisionCheck = true;
			 p->lvl->R->shotMSA->sv[ 0 ]->currentFrame = 0;
			 p->state |= B_SHOOTING;
			 p->lvl->R->shotMSA->newThread();
		   }*/
		  if( p->state & B_USING_MSA )
		    makeShot( p, p->lvl->R->shotMSA, P_UP );
		  if( p->state & B_USING_EA )
		    makeShot( p, p->lvl->R->shotEA, P_UP );
	    }
	    if( (p->look->actualSeq == P_LEFT || p->look->actualSeq == P_LEFT + 4 || p->look->actualSeq == P_LEFT + 8)  && p->sector->col > 0 ) {
		  if( p->state & B_USING_MSA )
		    makeShot( p, p->lvl->R->shotMSA, P_LEFT );
		  if( p->state & B_USING_EA )
		    makeShot( p, p->lvl->R->shotEA, P_LEFT );
		}
		if( (p->look->actualSeq == P_RIGHT || p->look->actualSeq == P_RIGHT + 4 || p->look->actualSeq == P_RIGHT + 8)  && p->sector->col < p->lvl->allCols - 1 ) {
		  if( p->state & B_USING_MSA )
		    makeShot( p, p->lvl->R->shotMSA, P_RIGHT );
		  if( p->state & B_USING_EA )
		    makeShot( p, p->lvl->R->shotEA, P_RIGHT );
		}
		if( (p->look->actualSeq == P_DOWN || p->look->actualSeq == P_DOWN + 4 || p->look->actualSeq == P_DOWN + 8)  && p->sector->row < p->lvl->allRows - 1 ) {
		  if( p->state & B_USING_MSA )
		    makeShot( p, p->lvl->R->shotMSA, P_DOWN );
		  if( p->state & B_USING_EA )
		    makeShot( p, p->lvl->R->shotEA, P_DOWN );
		}


      }
	} else break;
	SDL_Delay( MOV_DELAY );
  }

  //if( p->state & B_SHOOTING ) p->state ^= B_SHOOTING;
  p->shotQueue = false;
  return 0;
}


int playerLassoThread( void *data ) {
  Player *p = (Player *)data;
  while( true ) {
 //   bool s = false;
    Uint8 *keystate = SDL_GetKeyState( NULL );

	if( keystate[ SDLK_LCTRL ] ) {
	  if( p->lassoDirection == P_STAND ) {
    //  if( p->look->actualSeq == P_UP ) {
	   int rowOff = 0, colOff = 0;
	   if( p->look->actualSeq == P_UP + 8 ) {
	     rowOff = -1;
	   }
	   if( p->look->actualSeq == P_LEFT + 8 ) {
	     colOff = -1;
	   }
	   if( p->look->actualSeq == P_RIGHT + 8 ) {
	     colOff = 1;
	   }
	   if( p->look->actualSeq == P_DOWN + 8 ) {
	     rowOff = 1;
	   }
	  //  printf( "$ ");
	   if( p->sector->row + rowOff < 0 || p->sector->row + rowOff > p->lvl->allRows - 1 || p->sector->col + colOff < 0 || p->sector->col + colOff > p->lvl->allCols - 1 ) break;
	   if( p->lvl->allSectors[ 1 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look != NULL && (p->lvl->allSectors[ 1 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look->type & B_MOVABLE) )
       {
	     p->lassoDirection = p->look->actualSeq - 8;
		 p->lvl->R->lasso->x = p->lvl->allSectors[ 1 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look->x;
		 p->lvl->R->lasso->y = p->lvl->allSectors[ 1 ][ p->sector->row + rowOff ][ p->sector->col + colOff ].look->y;
		 //p->lvl->R->lasso->adjust();
		 p->lvl->win->drawOnPlane( p->lvl->R->lasso->ts->tiles[ 0 ], p->lvl->win->planes[ p->lvl->R->lasso->planeNR ], p->lvl->R->lasso->x, p->lvl->R->lasso->y );
         tileSequencesPushEvent( p->lvl->R->lasso, EVENT_TILESET_ANIMATION );

	   }
	  }
	} else break;

	SDL_Delay( MOV_DELAY );
  }
  // printf( "$ ");

  //p->lvl->win->eraseFromPlane( p->lvl->R->lasso->ts->tiles[ 0 ], p->lvl->win->planes[ p->lvl->R->lasso->planeNR ], p->lvl->R->lasso->x, p->lvl->R->lasso->y );
  //tileSequencesPushEvent( p->lvl->R->lasso, EVENT_TILESET_ANIMATION );
  //p->lvl->R->lasso->endThread = true;

  while( p->state & B_MOVING ) SDL_Delay( MOV_DELAY );
  SDL_Delay( MOV_DELAY );
  p->lassoDirection = P_STAND;
  //p->lvl->R->lasso->adjust();
  p->lvl->R->lasso->erase();

}

Player::Player() {
  state = 0;
  shotQueue = false;
  items.key1 = items.key2 = items.key3 = 0;
  items.ea = items.msa = items.pu = 0;
  items.fuel = items.time = 0;
  lassoDirection = P_STAND;
  movSectorCount = 0;
}

Sector::Sector() {
//  movable = false;
//  sequence = false;
  x = 0;
  y = 0;
  row = 0;
  col = 0;
  look = NULL;
//  type = 0;
//  id = T_SPACE;
 //printf( "!$");
}


void Level::buildLevelWindow( char *file, appResources *res, Window *win ) {
  R = res;
  createTilesNamesMap( file );
  int tileW = res->mainTileset.tiles[ 0 ]->w;
  int tileH = res->mainTileset.tiles[ 0 ]->h;
  allRows = tnMap.size();
  allCols = tnMap[ 0 ].size();
  bool backgroundPlane = false;
  if( allRows > 0 && allCols > 0 ) {
    floorPlane = 0;


    win->planes.resize( 3 );
	win->regularPlanesNR = 3;
	/*allSectors.resize( 2 );
	allSectors[ 0 ].resize( rows );
	allSectors[ 1 ].resize( rows );
	*/
	allSectors = new Sector** [2];
	allSectors[ 0 ] = new Sector* [allRows];
	allSectors[ 1 ] = new Sector* [allRows];

    win->winPosX = WINDOW_LEVEL_POSX;
	win->winPosY = WINDOW_LEVEL_POSY;
	win->planesWidth = tileW * allCols;
	win->planesHeight = tileH * allRows;
	clear_surface( 0, 0, WINDOW_LEVEL_WIDTH, WINDOW_LEVEL_HEIGHT, MainScreen, 0x000000 );
	SDL_UpdateRect( MainScreen, WINDOW_LEVEL_POSX, WINDOW_LEVEL_POSY, WINDOW_LEVEL_WIDTH, WINDOW_LEVEL_HEIGHT );
	win->scrollV = true;
	win->scrollH = true;
	if( win->planesWidth < WINDOW_LEVEL_WIDTH ) {
	  win->winPosX += (WINDOW_LEVEL_WIDTH - win->planesWidth) / 2;
	  win->scrollH = false;
	}
	if( win->planesHeight < WINDOW_LEVEL_HEIGHT ) {
	  win->winPosY += (WINDOW_LEVEL_HEIGHT - win->planesHeight) / 2;
	  win->scrollV = false;
	}
    for( int i = 0; i < allRows; i++ ) {
	  //allSectors[ 0 ][ i ].reserve( cols );
	  //allSectors[ 1 ][ i ].reserve( cols );
	  allSectors[ 0 ][ i ] = new Sector [allCols];
	  allSectors[ 1 ][ i ] = new Sector [allCols];


	  if( backgroundPlane ) continue;
      for( int j = 0; j < allCols; j++ )
	    if( tnMap[ i ][ j ] == T_SPACE || tnMap[ i ][ j ] == T_CRUMBLE ) {
	      backgroundPlane = true;
		  win->regularPlanesNR++;
		  win->planes.resize( win->regularPlanesNR );
		  win->planes[ 0 ] = optimizedSurface( RES_BACKGROUND, MainScreen->format, win->planesWidth, win->planesHeight );
		  floorPlane = 1;
		  break;
		}
	}
    win->planes[ floorPlane ] = emptyPlane( win->planesWidth, win->planesHeight );
    win->planes[ floorPlane + 1 ] = emptyPlane( win->planesWidth, win->planesHeight );
    win->planes[ floorPlane + 2 ] = emptyPlane( win->planesWidth, win->planesHeight );
	//win->drawOnPlane( res->mainTileset.tiles[ T_FLOOR ], win->planes[ floorPlane ], 0, 0 );
    tileSequences *lookOfTheFloor;
	for( int i = 0; i < allRows; i++ )
      for( int j = 0; j < allCols; j++ ) {
	    /*Sector sector;
		allSectors[ 0 ][ i ].push_back( sector );
		allSectors[ 1 ][ i ].push_back( sector );
		*/
	    allSectors[ 0 ][ i ][ j ].x = allSectors[ 1 ][ i ][ j ].x = j * tileW;
		allSectors[ 0 ][ i ][ j ].y = allSectors[ 1 ][ i ][ j ].y = i * tileH;
		allSectors[ 0 ][ i ][ j ].row = allSectors[ 1 ][ i ][ j ].row = i;
		allSectors[ 0 ][ i ][ j ].col = allSectors[ 1 ][ i ][ j ].col = j;


//*** creating tileSequences for each sector ***
        if( tnMap[ i ][ j ] != T_SPACE ) {
		  bool oneTile = true;
		  if( tnMap[ i ][ j ] == T_PLAYER_MSA || tnMap[ i ][ j ] == T_PLAYER ) {
		    oneTile = false;
		    res->playerSeq->prev_x = res->playerSeq->x = allSectors[ 1 ][ i ][ j ].x;
			res->playerSeq->prev_y = res->playerSeq->y = allSectors[ 1 ][ i ][ j ].y;

			//allSectors[ 1 ][ i ][ j ].look = res->playerSeq;
            player.look = res->playerSeq;
			win->associate( floorPlane + 1, player.look, 0, allSectors[ 1 ][ i ][ j ].x, allSectors[ 1 ][ i ][ j ].y, MOV_DELAY );
		    win->drawOnPlane(  player.look->ts->tiles[ 0 ], win->planes[ player.look->planeNR ], allSectors[ 1 ][ i ][ j ].x, allSectors[ 1 ][ i ][ j ].y );
            allSectors[ 0 ][ i ][ j ].look = newTileSequence( T_FLOOR, res->mainTileset.tiles[ T_FLOOR ], allSectors[ 1 ][ i ][ j ].x, allSectors[ 1 ][ i ][ j ].y );
            allSectors[ 0 ][ i ][ j ].look->type |= B_PASSABLE;
  	        win->associate( floorPlane, allSectors[ 0 ][ i ][ j ].look, 0, allSectors[ 0 ][ i ][ j ].x, allSectors[ 0 ][ i ][ j ].y, MOV_DELAY );
            win->drawOnPlane( res->mainTileset.tiles[ T_FLOOR ], win->planes[ floorPlane ], allSectors[ 0 ][ i ][ j ].x, allSectors[ 0 ][ i ][ j ].y );

			player.sector = &allSectors[ 0 ][ i ][ j ];
			player.prevSector = player.sector;
            player.state |= B_USING_MSA;

			player.look->collisionCheck = false;
			player.look->stopAtCollision = false;
			//player.look->stillAtCollision = true;
			player.look->stop = true;

		  }

		  if( tnMap[ i ][ j ] == T_CRUMBLE ) {
			oneTile = false;
			//tileSequences *l = newTileSequence( tnMap[ i ][ j ], res->mainTileset.tiles[ tnMap[ i ][ j ] ], allSectors[ 1 ][ i ][ j ].x, allSectors[ 1 ][ i ][ j ].y );
		   // l->sv.clear();
		   // l->sv.resize( 0 );

            tileSequences *l = new tileSequences;
			l->ts = &res->animations[ ID_ANIMATION_CRUMBLE ];
			l->createSeq();
			l->type |= B_PASSABLE;
            l->prev_x = l->x = allSectors[ 0 ][ i ][ j ].x;
            l->prev_y = l->y = allSectors[ 0 ][ i ][ j ].y;
            l->collisionCheck = false;
            l->id = tnMap[ i ][ j ];
            l->stop = false;
			l->loopedAnimation = false;
			l->eraseAtEndThread = true;
			l->useCounter = false;
            //l->deleteAtEndThread = true;
			//l->actualSeq = 0;
			allSectors[ 0 ][ i ][ j ].look = l;
		    win->associate( floorPlane, allSectors[ 0 ][ i ][ j ].look, 0, allSectors[ 0 ][ i ][ j ].x, allSectors[ 0 ][ i ][ j ].y, MOV_DELAY_CRUMBLE );
		    win->drawOnPlane( res->mainTileset.tiles[ tnMap[ i ][ j ] ], win->planes[ floorPlane ], allSectors[ 0 ][ i ][ j ].x, allSectors[ 0 ][ i ][ j ].y );

		  }
		  if( oneTile ) {

			tileSequences *l = newTileSequence( tnMap[ i ][ j ], res->mainTileset.tiles[ tnMap[ i ][ j ] ], allSectors[ 1 ][ i ][ j ].x, allSectors[ 1 ][ i ][ j ].y );
			if( tnMap[ i ][ j ] == T_FLOOR || tnMap[ i ][ j ] == T_HOLE || tnMap[ i ][ j ] == T_PLATFORM_UP || tnMap[ i ][ j ] == T_PLATFORM || tnMap[ i ][ j ] == T_PLATFORM_VERTICAL || tnMap[ i ][ j ] == T_PLATFORM_MULTIDIRECT || tnMap[ i ][ j ] == T_PLATFORM_DOWN || tnMap[ i ][ j ] == T_PLATFORM_LEFT || tnMap[ i ][ j ] == T_PLATFORM_RIGHT || tnMap[ i ][ j ] == T_PLATFORM_HORIZONTAL || (tnMap[ i ][ j ] >= T_PASS1 && tnMap[ i ][ j ] <= T_PASS6) || (tnMap[ i ][ j ] >= T_PASS1_LEFT && tnMap[ i ][ j ] <= T_PASS6_DOWN) || (tnMap[ i ][ j ] >= T_PASS1_H && tnMap[ i ][ j ] <= T_PASS6_H) ) {
			  /*if( tnMap[ i ][ j ] == T_PLATFORM_UP || tnMap[ i ][ j ] == T_PLATFORM_VERTICAL || tnMap[ i ][ j ] == T_PLATFORM_MULTIDIRECT || tnMap[ i ][ j ] == T_PLATFORM_DOWN || tnMap[ i ][ j ] == T_PLATFORM_LEFT || tnMap[ i ][ j ] == T_PLATFORM_RIGHT || tnMap[ i ][ j ] == T_PLATFORM_HORIZONTAL ) {
                l->refreshRender = false;
                l->usePointerToXY = true;
                l->p_x = &player.look->x;
                l->p_y = &player.look->y;
              }*/
			  l->type |= B_PASSABLE;
			  if( tnMap[ i ][ j ] == T_HOLE ) l->collisionX = 0;
			//  if( tnMap[ i ][ j ] != T_FLOOR  && tnMap[ i ][ j ] != T_HOLE ) l->collisionCheck = true;
			  allSectors[ 0 ][ i ][ j ].look = l;
		      win->associate( floorPlane, allSectors[ 0 ][ i ][ j ].look, 0, allSectors[ 0 ][ i ][ j ].x, allSectors[ 0 ][ i ][ j ].y, MOV_DELAY );
		      win->drawOnPlane( res->mainTileset.tiles[ tnMap[ i ][ j ] ], win->planes[ floorPlane ], allSectors[ 0 ][ i ][ j ].x, allSectors[ 0 ][ i ][ j ].y );

			} else {
			  if( tnMap[ i ][ j ] == T_KEY1 || tnMap[ i ][ j ] == T_KEY2 || tnMap[ i ][ j ] == T_KEY3 || tnMap[ i ][ j ] == T_PU || tnMap[ i ][ j ] == T_EA || tnMap[ i ][ j ] == T_MSA ||tnMap[ i ][ j ] == T_FUEL || tnMap[ i ][ j ] == T_REPAIR ||tnMap[ i ][ j ] == T_TIME || tnMap[ i ][ j ] == T_DYNAMITE) {

				l->type |= B_ITEM;
			  }

			  allSectors[ 1 ][ i ][ j ].look = l;
			  allSectors[ 0 ][ i ][ j ].look = newTileSequence( T_FLOOR, res->mainTileset.tiles[ T_FLOOR ], allSectors[ 1 ][ i ][ j ].x, allSectors[ 1 ][ i ][ j ].y );
			  if( l->type & B_ITEM ) { if( tnMap[ i ][ j ] != T_DYNAMITE ) allSectors[ 0 ][ i ][ j ].look->type |= B_PASSABLE; allSectors[ 0 ][ i ][ j ].look->type |= B_ITEM; }
			  win->associate( floorPlane + 1, allSectors[ 1 ][ i ][ j ].look, 0, allSectors[ 1 ][ i ][ j ].x, allSectors[ 1 ][ i ][ j ].y, MOV_DELAY );
		      win->associate( floorPlane, allSectors[ 0 ][ i ][ j ].look, 0, allSectors[ 0 ][ i ][ j ].x, allSectors[ 0 ][ i ][ j ].y, MOV_DELAY );

		      win->drawOnPlane( res->mainTileset.tiles[ T_FLOOR ], win->planes[ floorPlane ], allSectors[ 0 ][ i ][ j ].x, allSectors[ 0 ][ i ][ j ].y );
			  win->drawOnPlane( res->mainTileset.tiles[ tnMap[ i ][ j ] ], win->planes[ floorPlane + 1 ], allSectors[ 1 ][ i ][ j ].x, allSectors[ 1 ][ i ][ j ].y );

			//  if( (tnMap[ i ][ j ] >= T_PASS1 && tnMap[ i ][ j ] <= T_PASS6) || (tnMap[ i ][ j ] >= T_PASS1_LEFT && tnMap[ i ][ j ] <= T_PASS6_DOWN) )
			//    allSectors[ 1 ][ i ][ j ].look->type |= B_PASSABLE;
			}
			 tileSequences *s = allSectors[ 1 ][ i ][ j ].look;
             if( s != NULL && !(s->type & B_PASSABLE) && s->id != T_WALL && s->id != T_DOOR1 && s->id != T_DOOR2 && s->id != T_DOOR3 && s->id != T_OBSTACLE && s->id != T_GEM_DARK && s->id != T_MAGNET && !(s->id >= T_MAGNET_LEFT && s->id <= T_MAGNET_DOWN) ) {
			   s->type |= B_MOVABLE;
			 }
		  }
          if( tnMap[ i ][ j ] == T_MAGNET || tnMap[ i ][ j ] == T_MAGNET_RIGHT || tnMap[ i ][ j ] == T_MAGNET_LEFT || tnMap[ i ][ j ] == T_MAGNET_DOWN ) {
		    row_col magnet;
		    if( tnMap[ i ][ j ] == T_MAGNET || tnMap[ i ][ j ] == T_MAGNET_DOWN ) { magnet.row = -i; magnet.col = j; }
		    if( tnMap[ i ][ j ] == T_MAGNET_LEFT || tnMap[ i ][ j ] == T_MAGNET_RIGHT ) { magnet.row = i; magnet.col = -j; }
		    magnets.push_back( magnet );
		  }
		}

	 }
  res->shotMSA->planeCollisionOffset = res->shotEA->planeCollisionOffset = -1;
  //res->shotMSA->movFunction = res->shotEA->movFunction = &movFunctionShot;
  win->associate( floorPlane + 2, res->shotMSA, 0, 0, 0, MOV_SHOT_DELAY );
  win->associate( floorPlane + 2, res->shotEA, 0, 0, 0, MOV_SHOT_DELAY );

  res->lasso = newTileSequence( T_LASSO, res->mainTileset.tiles[ T_LASSO ], 0, 0 );
  win->associate( floorPlane + 2, res->lasso, 0, 0, 0, MOV_DELAY );
  res->lasso->eraseAtEndThread = false;
  res->lasso->useCounter = true;
  }

  //win->regularPlanesNR--;
  player.lvl = this;
  this->win = win;
  gameOver = false;
  complete = false;
  magnetizePlayer = false;
  transportPlayer = false;
  player.state = 0;
  player.state |= B_USING_MSA;
  d_explosion = 0;
  gameOverText[ 0 ] = 0;

  if( player.items.time > 0 ) timer = true;
  else timer = false;
  runTimer = true;
  this->win->bgPosX = 0;
  this->win->bgPosY = 0;

  //this->win->checkWindowBgPos( player.look->x, player.look->y, 1, 1 );
  this->win->centerWindowBg( player.look->x, player.look->y );
  
  
  
  updateInfo();//this->R->screens[ SCREEN_GAME ].windows[ WINDOW_INFO ]
  makeGoalsInfo();
  updateTime();
  if( R->introFile[ 0 ] != 0 )
    makeIntroScreen();
}

int longestLine( char *buf ) {
  int max = 0, cnt = 0;
  for( int i = 0; buf[ i ] != 0; i++ ) {
    if( buf[ i ] == '\n' ) {
	  if( cnt > max ) max = cnt;
	  cnt = 0;
	} else cnt++;
  }
  //printf( "%d ", max );
  return max;
}
/*
int lastLineLength( char *buf ) {
  int p = 0;
  while( buf[ p ] != 0 ) p++;
  int lineL = p;
  while( p >= 0 && buf[ p ] != '\n' ) p--;
  if( p == -1 ) p = 0;
  //printf( "%d ", lineL - p );
  return lineL - p;
}
*/
int linesNumber( char *buf ) {
  int sum = 0;
  for( int i = 0; buf[ i ] != 0; i++ )
    if( buf[ i ] == '\n' ) sum++;
  //printf( "%d ", sum );
  return sum;
}

bool getTileID( char *tileChars, int &id ) {
  bool found = false;
	  for( int k = 0; TRN[ k ] != 0; k++ ) {
	    if( !strcmp( tileChars, TRN[ k ] ) ) {
		  found = true;
		  id = k;
		}

       }
  return found;
}
bool processIntroText( char *text, int &pos, int &tile_id, bool &enter ) {
  if( *text == 0 ) { tile_id = 0; return false; }
  char tileT[ 5 ] = {0};
  bool foundT = false;
  pos = 0;
  for( ; text[ pos ] != '\n' && text[ pos ] != 0; pos++ ) {
    //if( text[ pos ] == '\n' ) break;
    if( text[ pos ] == '`' ) {
	  text[ pos ] = 0;
	  pos += 1;
	  int i = 0;
	  while( text[ pos ] != '`' && text[ pos ] != 0 ) {
	    tileT[ i++ ] = text[ pos++ ];

	  }
	  if( text[ pos ] == '`' ) pos++;
	  foundT = true;
	  break;
	}
  }
  enter = false;
  if( text[ pos ] == '\n' ) { text[ pos++ ] = 0; enter = true; }
  tile_id = 0;
  if( foundT ) {
    getTileID( tileT, tile_id );
  }

 // printf( "[%d;  %s] ", pos, tileT );
  return true;
}


void Level::makeIntroScreen() {
  long fSize;
  char *buf;
  char introFullPath[ MAX_LINE ];
  sprintf( introFullPath, "data\\levels\\%s\0", R->introFile );
  readFile( introFullPath, &buf, fSize );
  Window *w = R->screens[ SCREEN_INTRO ].windows[ 0 ];
  w->bgPosX = 0;
  w->bgPosY = 0;

  if( w->planes[ 0 ] != NULL ) SDL_FreeSurface( w->planes[ 0 ] );
  if( w->planes[ 1 ] != NULL ) SDL_FreeSurface( w->planes[ 1 ] );

  int iWidth = longestLine( buf ) * R->menu.fW;
  int iHeight = linesNumber( buf ) * TileWidth;

  if( iWidth < w->winWidth ) iWidth = w->winWidth;
  if( iHeight < w->winHeight ) iHeight = w->winHeight;
  w->planes[ 0 ] = emptyPlane( iWidth, iHeight, 0x000000ff );
  w->planes[ 1 ] = emptyPlane( iWidth, iHeight, 0x000000ff );
  int pos, tile_id;
  int s_tX = 3, s_tY = TileWidth / 2;
  int tX = s_tX, tY = s_tY;
  char *text = buf;
  bool enter;
  while( processIntroText( text, pos, tile_id, enter ) ) {
    int textL = w->print( &R->font, 1, tX, tY, "%s", text );
    tX += textL * R->menu.fW;
	if( tile_id > 0 ) {
	  w->drawOnPlane( R->mainTileset.tiles[ tile_id ], w->planes[ 1 ], tX, tY - R->mainTileset.tiles[ tile_id ]->h / 4 );
      //apply_pixels( tX, tY, R->mainTileset.tiles[ tile_id ], w->planes[ 1 ] );
	  tX += R->mainTileset.tiles[ tile_id ]->w;
	}
	if( enter ) {
      tX = s_tX;
      tY += TileWidth;
    }
    text += pos;
  }

  delete[] buf;
  //rectangleOnSurface( WINDOW_INTRO_POSX, WINDOW_INTRO_POSY, w->planes[ 1 ], iWidth, iHeight, 0, 2, WINDOW_INTRO_BORDERCOLOR );

}

void Level::updateGoalsInfo() {
  //if( R->actualScreen != SCREEN_GAME ) return;
  Window *wg = R->screens[ SCREEN_GAME ].windows[ WINDOW_GOALS ];
  int gs = goals.size();
  int gridCellW = TileWidth + 2;
  wg->bgPosY += 3 * gridCellW + 3;
  if( gs > 0 ) {

	makeGrid( WINDOW_GOAL_GRID_X, wg->bgPosY, wg->planes[ 1 ], gridCellW, gridCellW, 3, 3, 2, WINDOW_GOALS_ACTUAL_COLOR );
  }
	wg->redrawAllPlanes();

}
void Level::makeGoalsInfo() {
  Window *wg = R->screens[ SCREEN_GAME ].windows[ WINDOW_GOALS ];
  wg->bgPosX = 0;
  wg->bgPosY = 0;

  int gs = goals.size();
  int wgW = WINDOW_GOALS_WIDTH, wgH = WINDOW_GOALS_HEIGHT;
  int gridCellW = TileWidth + 2, goalH = 3 * gridCellW + 3;
  if( gs > 2 ) {
    wgH = goalH * gs;
  }
  wgH += goalH * 3;


  //wg->planes[ 0 ] = emptyPlane( wgW, wgH, 0x000000ff );
  wg->planes[ 0 ] = optimizedSurface( RES_GOALS_BACKGROUND, MainScreen->format, wgW, wgH );
  wg->planes[ 1 ] = emptyPlane( wgW, wgH );
  if( gs > 0 ) {
  Uint32 gridColor = WINDOW_GOALS_ACTUAL_COLOR;
  int x = WINDOW_GOAL_GRID_X, y = WINDOW_GOAL_GRID_Y;
  for( int i = 0; i < gs; i++, y += goalH ) {
    if( i > 0 )
      gridColor = WINDOW_GOALS_NEXT_COLOR;
    makeGrid( x, y, wg->planes[ 1 ], gridCellW, gridCellW, 3, 3, 2, gridColor );
    int yg = y;
	for( int r = 0; r < 3; r++, yg += gridCellW + 1 ) {
	  int xg = x;
	  for( int c = 0; c < 3; c++, xg += gridCellW + 1 ) {
        if( goals[ i ][ r ][ c ] >= T_GEM1 && goals[ i ][ r ][ c ] <= T_BALL6 )
	      wg->drawOnPlane( R->mainTileset.tiles[ goals[ i ][ r ][ c ] ], wg->planes[ 1 ], xg, yg );
        //apply_surface( xg, yg, R->mainTileset.tiles[ goals[ i ][ r ][ c ] ], wg->planes[ 1 ] );

	  }
	}
  }

 }
	//makeGrid
}
/*
void Level::makeInfo() {
  Window *wi = R->screens[ SCREEN_GAME ].windows[ WINDOW_INFO ];
  //wi->drawOnPlane( R->mainTileset.tiles[ T_TIME ], wi->planes[ 0 ], INFO_TIME_X, INFO_TIME_Y );
  apply_surface( INFO_TIME_X, INFO_TIME_Y, R->mainTileset.tiles[ T_TIME ], wi->planes[ 0 ] );
  apply_surface( INFO_KEY1_X, INFO_KEY1_Y, R->mainTileset.tiles[ T_KEY1 ], wi->planes[ 0 ] );
  apply_surface( INFO_KEY2_X, INFO_KEY2_Y, R->mainTileset.tiles[ T_KEY2 ], wi->planes[ 0 ] );
  apply_surface( INFO_KEY3_X, INFO_KEY3_Y, R->mainTileset.tiles[ T_KEY3 ], wi->planes[ 0 ] );

  apply_surface( INFO_PU_X, INFO_PU_Y, R->mainTileset.tiles[ T_PU ], wi->planes[ 0 ] );
  apply_surface( INFO_MSA_X, INFO_MSA_Y, R->mainTileset.tiles[ T_MSA ], wi->planes[ 0 ] );
  apply_surface( INFO_EA_X, INFO_EA_Y, R->mainTileset.tiles[ T_EA ], wi->planes[ 0 ] );
  apply_surface( INFO_REPAIR_X, INFO_REPAIR_Y, R->mainTileset.tiles[ T_REPAIR ], wi->planes[ 0 ] );
  apply_surface( INFO_FUEL_X, INFO_FUEL_Y, R->mainTileset.tiles[ T_FUEL ], wi->planes[ 0 ] );

 // wi->print( &R->font, 1, INFO_TIME_X + INFO_TILE_SPACE_H, INFO_TEXT_SPACE_H, "%03d", player.items.time );

}*/

void Level::updateTime() {

  Window *wi = R->screens[ SCREEN_GAME ].windows[ WINDOW_INFO ];
  clear_surface( 0, 0, WINDOW_INFO_WIDTH, INFO_TILE_SPACE_H, wi->planes[ 1 ], 0 );
  wi->print( &R->font, 1, INFO_TIME_X + INFO_TILE_SPACE_H, INFO_TIME_Y + INFO_TEXT_SPACE_H, "%03d", player.items.time );

  wi->redrawPlane( wi->planes[ 0 ], 0, 0, WINDOW_INFO_WIDTH, INFO_TILE_SPACE_H );
  wi->redrawPlane( wi->planes[ 1 ], 0, 0, WINDOW_INFO_WIDTH, INFO_TILE_SPACE_H );
  if( R->actualScreen != SCREEN_MENU )
    SDL_UpdateRect( MainScreen, WINDOW_INFO_POSX, WINDOW_INFO_POSY, WINDOW_INFO_WIDTH, INFO_TILE_SPACE_H );


}
void Level::updateFuel() {
  //if( R->actualScreen != SCREEN_GAME ) return;
  Window *wi = R->screens[ SCREEN_GAME ].windows[ WINDOW_INFO ];
  clear_surface( 0, INFO_TILE_SPACE_H * 5, WINDOW_INFO_WIDTH, INFO_TILE_SPACE_H, wi->planes[ 1 ], 0 );
  wi->print( &R->font, 1, INFO_FUEL_X + INFO_TILE_SPACE_H, INFO_FUEL_Y + INFO_TEXT_SPACE_H, "%03d", player.items.fuel );

  wi->redrawPlane( wi->planes[ 0 ], 0, INFO_TILE_SPACE_H * 5, WINDOW_INFO_WIDTH, INFO_TILE_SPACE_H );
  wi->redrawPlane( wi->planes[ 1 ], 0, INFO_TILE_SPACE_H * 5, WINDOW_INFO_WIDTH, INFO_TILE_SPACE_H );

  SDL_UpdateRect( MainScreen, WINDOW_INFO_POSX, WINDOW_INFO_POSY + INFO_TILE_SPACE_H * 5, WINDOW_INFO_WIDTH, INFO_TILE_SPACE_H );

  //windowPushEvent( wi, EVENT_UPDATE_INFO );
}

void Level::updateInfo() {
  //if( R->actualScreen != SCREEN_GAME ) return;
  Window *wi = R->screens[ SCREEN_GAME ].windows[ WINDOW_INFO ];
  //wi->eraseFromPlane( WINDOW_INFO_WIDTH, WINDOW_INFO_HEIGHT, wi->planes[ 1 ], 0, 0 );
  clear_surface( 0, INFO_TILE_SPACE_H, WINDOW_INFO_WIDTH, WINDOW_INFO_HEIGHT - INFO_TILE_SPACE_H, wi->planes[ 1 ], 0 );

  wi->print( &R->font, 1, INFO_KEY1_X + INFO_TILE_SPACE_H, INFO_KEY1_Y + INFO_TEXT_SPACE_H, "%d", player.items.key1 );
  wi->print( &R->font, 1, INFO_KEY2_X + INFO_TILE_SPACE_H, INFO_KEY2_Y + INFO_TEXT_SPACE_H, "%d", player.items.key2 );
  wi->print( &R->font, 1, INFO_KEY3_X + INFO_TILE_SPACE_H, INFO_KEY3_Y + INFO_TEXT_SPACE_H, "%d", player.items.key3 );

  wi->print( &R->font, 1, INFO_PU_X + INFO_TILE_SPACE_H, INFO_PU_Y + INFO_TEXT_SPACE_H, "%d", player.items.pu );
  wi->print( &R->font, 1, INFO_MSA_X + INFO_TILE_SPACE_H, INFO_MSA_Y + INFO_TEXT_SPACE_H, "%d", player.items.msa );
  wi->print( &R->font, 1, INFO_EA_X + INFO_TILE_SPACE_H, INFO_EA_Y + INFO_TEXT_SPACE_H, "%d", player.items.ea );
  wi->print( &R->font, 1, INFO_REPAIR_X + INFO_TILE_SPACE_H, INFO_REPAIR_Y + INFO_TEXT_SPACE_H, "%d (%d;%d)", player.hitPoints, player.lvl->EA_damage_mod, player.lvl->MSA_damage_mod );
  wi->print( &R->font, 1, INFO_FUEL_X + INFO_TILE_SPACE_H, INFO_FUEL_Y + INFO_TEXT_SPACE_H, "%03d", player.items.fuel );

  wi->redrawAllPlanes();
 // wi->redrawPlane( wi->planes[ 0 ], WINDOW_INFO_POSX, WINDOW_INFO_POSY + INFO_TILE_SPACE_H, WINDOW_INFO_WIDTH, WINDOW_INFO_HEIGHT - INFO_TILE_SPACE_H );
 // wi->redrawPlane( wi->planes[ 1 ], WINDOW_INFO_POSX, WINDOW_INFO_POSY + INFO_TILE_SPACE_H, WINDOW_INFO_WIDTH, WINDOW_INFO_HEIGHT - INFO_TILE_SPACE_H );

 // SDL_UpdateRect( MainScreen, WINDOW_INFO_POSX, WINDOW_INFO_POSY + INFO_TILE_SPACE_H, WINDOW_INFO_WIDTH, WINDOW_INFO_HEIGHT - INFO_TILE_SPACE_H );

  //wi->redrawPlane( wi->planes[ 0 ], 0, INFO_TILE_SPACE_H, WINDOW_INFO_WIDTH, WINDOW_INFO_HEIGHT - INFO_TILE_SPACE_H );
  //wi->redrawPlane( wi->planes[ 1 ], 0, INFO_TILE_SPACE_H, WINDOW_INFO_WIDTH, WINDOW_INFO_HEIGHT - INFO_TILE_SPACE_H );

 // SDL_Flip(MainScreen);
  //windowPushEvent( wi, EVENT_UPDATE_INFO );
}

void nextLine( char *buf, int &i, const long &fSize ) {
  while( i < fSize && (buf[ i ] == '\n' || buf[ i ] == '\r') ) i++;
}

bool createGoal( char **buf, vector<int**> &goals ) {
  int **g = new int* [3];
  (*buf)++;
  for( int i = 0; i < 3; i++ ) {
    while( **buf == '\n' || **buf == '\r' ) (*buf)++;
    g[ i ] = new int [3];
    for( int j = 0; j < 3; j++ ) {
      if( **buf != 'b' && **buf != 'g' ) {
	    g[ i ][ j ] = T_SPACE;

	  }
	  else {
	    char tileChars[ 3 ] = {0};
        tileChars[ 0 ] = **buf;
		tileChars[ 1 ] = (*buf)[ 1 ];

	    for( int k = 0; TRN[ k ] != 0; k++ )
	      if( !strcmp( tileChars, TRN[ k ] ) ) {
	        g[ i ][ j ] = k;
//		    printf( "%2d", k );
		  }
	  }
	  (*buf) += 2;

    }

  }

  while( **buf == '\n' || **buf == '\r' ) (*buf)++;
  goals.push_back( g );
  if( (*buf)[ 0 ]  == '.' && ((*buf)[ 1 ] == '\n' || (*buf)[ 1 ] == '\r') )
    return true;
  else return false;
}

void Level::specialLevel( char *buf ) {
  srand( (unsigned)time( NULL ) );
  int first, r, max = 12;
  getTileID( "g1", first );
  char *p;
  while( (p = strstr( buf, "b#" )) || (p = strstr( buf, ".." )) ) {
    r = rand() % max;
	p[ 0 ] = TRN[ first + r ][ 0 ];
	p[ 1 ] = TRN[ first + r ][ 1 ];
	
	buf = p;
  }
  player.items.key1 = 99;
  player.items.key2 = 99;
  player.items.key3 = 99;
  
}
void Level::createTilesNamesMap( char *file ) {
  char *buf;
  long fSize;
  readFile( file, &buf, fSize );

  int i = 0;
  char cfgLine[ MAX_LINE + 1 ] = {0};
  while( i < fSize && buf[ i ] != '\n' && buf[ i ] != '\r' ) {
    cfgLine[ i ] = buf[ i ];
    i++;
  }

  nextLine( buf, i, fSize );
  R->introFile[ 0 ] = 0;
  sscanf( cfgLine, "%d %d %d %d %d %d %d %d %s", &player.items.time, &player.items.fuel, &player.hitPoints, &player.items.ea, &player.items.msa, &player.items.pu, &EA_damage_mod, &MSA_damage_mod, R->introFile );
  player.items.key1 = player.items.key2 = player.items.key3 = 0;
  if( !strcmp( R->introFile, "gameinfo" ) )
   specialLevel( buf );
  //printf( "%s | %d %d %d %d %d %d %d %d", cfgLine, player.items.time, player.items.fuel, player.damage, player.items.ea, player.items.msa, player.items.pu, EA_damage_mod, MSA_damage_mod );
  // if( introFile[ 0 ] != 0 )
  //  printf( "%s", introFile );
  int firstLineSize;
  for( int line = 0; i < fSize; line++ ) {
    tnMap.resize( 1 + line );
    int lCount = 0;
    while( i + lCount < fSize && buf[ i + lCount ] != '\n' && buf[ i + lCount ] != '\r' ) {
	  lCount++;
	}
	if( line == 0 ) firstLineSize = lCount;
	else if( lCount != firstLineSize ) {
	  printf( "Error: Wrong size of line %d in %s", line + 1, file );
      exit( EXIT_FAILURE );
	}
   // printf( "(%i: %d) ", i, lCount );
	if( lCount % 2 ) {
	  printf( "Error: Wrong length of data line: %d for %s", line + 1, file );
      exit( EXIT_FAILURE );
	}

	for( int j = 0; j < lCount; j += 2 ) {
	  char tileChars[ 5 ] = { 0 };
	  strncpy( tileChars, buf + i + j, 2 );
	  int tID;
	  bool found = getTileID( tileChars, tID );
      if( found )
        tnMap[ line ].push_back( (MainTiles)tID );
	  else {
	    printf( "Error: Unknown tile representation at %d (\"%s\") in %s line: %d", i + j, tileChars, file, line + 1 );
        exit( EXIT_FAILURE );
  	  }

	}
//printf("\n" );
    i += lCount;
	while( i < fSize && (buf[ i ] == '\n' || buf[ i ] == '\r') ) i++;
    if( buf[ i ]  == '.' && (buf[ i + 1 ]  == '\n' || buf[ i + 1 ]  == '\r') )
	  break;
  }
  buf += i;
  while( createGoal( &buf, goals ) );

/*
  for( int i = 0; i < goals.size(); i++ ) {
    for( int j = 0; j < 3 ; j++ ) {
	  for( int k = 0; k < 3 ; k++ ) {
	    printf( "%2d ", goals[ i ][ j ][ k ] );

	  }
	  printf( "\n" );
    }
	printf( "\n\n" );
  }*/
  /*
  for( int i = 0; i < tnMap.size(); i++ ) {
    for( int j = 0; j < tnMap[ i ].size() ; j++ ) {
	  printf( "%02d ", tnMap[ i ][ j ] );
	}
	printf("\n" );
  }*/
  delete[] buf;
}
/*
void updateSurroundings( Player *p, uchar md, bool all ) {
  int col = p->sector->col;
  int row = p->sector->row;
  if( all || md == P_RIGHT )
    if( col < p->lvl->allCols - 1 )
      if( p->lvl->allSectors[ 1 ][ row ][ col + 1 ].look != NULL )
	    p->lvl->allSectors[ 1 ][ row ][ col + 1 ].look->win->drawOnPlane( p->lvl->allSectors[ 1 ][ row ][ col + 1 ].look->ts->tiles[ 0 ], p->lvl->allSectors[ 1 ][ row ][ col + 1 ].look->win->planes[ p->lvl->allSectors[ 1 ][ row ][ col + 1 ].look->planeNR ], p->lvl->allSectors[ 1 ][ row ][ col + 1 ].x, p->lvl->allSectors[ 1 ][ row ][ col + 1 ].y );
  if( all || md == P_LEFT )
    if( col > 0 )
      if( p->lvl->allSectors[ 1 ][ row ][ col - 1 ].look != NULL )
	    p->lvl->allSectors[ 1 ][ row ][ col - 1 ].look->win->drawOnPlane( p->lvl->allSectors[ 1 ][ row ][ col - 1 ].look->ts->tiles[ 0 ], p->lvl->allSectors[ 1 ][ row ][ col - 1 ].look->win->planes[ p->lvl->allSectors[ 1 ][ row ][ col - 1 ].look->planeNR ], p->lvl->allSectors[ 1 ][ row ][ col - 1 ].x, p->lvl->allSectors[ 1 ][ row ][ col - 1 ].y );
  if( all || md == P_DOWN )
    if( row < p->lvl->allRows - 1 )
      if( p->lvl->allSectors[ 1 ][ row + 1 ][ col ].look != NULL )
	    p->lvl->allSectors[ 1 ][ row + 1 ][ col ].look->win->drawOnPlane( p->lvl->allSectors[ 1 ][ row + 1 ][ col ].look->ts->tiles[ 0 ], p->lvl->allSectors[ 1 ][ row + 1 ][ col ].look->win->planes[ p->lvl->allSectors[ 1 ][ row + 1 ][ col ].look->planeNR ], p->lvl->allSectors[ 1 ][ row + 1 ][ col ].x, p->lvl->allSectors[ 1 ][ row + 1 ][ col ].y );
  if( all || md == P_UP )
    if( row > 0 )
      if( p->lvl->allSectors[ 1 ][ row - 1 ][ col ].look != NULL )
	    p->lvl->allSectors[ 1 ][ row - 1 ][ col ].look->win->drawOnPlane( p->lvl->allSectors[ 1 ][ row - 1 ][ col ].look->ts->tiles[ 0 ], p->lvl->allSectors[ 1 ][ row - 1 ][ col ].look->win->planes[ p->lvl->allSectors[ 1 ][ row - 1 ][ col ].look->planeNR ], p->lvl->allSectors[ 1 ][ row - 1 ][ col ].x, p->lvl->allSectors[ 1 ][ row - 1 ][ col ].y );

}*/
bool Player::dontShoot() {
  if( sector == NULL || sector->look == NULL || lvl->magnetizePlayer || lvl->transportPlayer || lvl->gameOver || lvl->complete  ) return true; //|| lvl->d_explosion > 0
  if( (state & B_MOVING) && (sector->look->id == T_PLATFORM_UP || sector->look->id == T_PLATFORM_DOWN || sector->look->id == T_PLATFORM_LEFT || sector->look->id == T_PLATFORM_RIGHT || sector->look->id == T_PLATFORM_VERTICAL || sector->look->id == T_PLATFORM_HORIZONTAL || sector->look->id == T_PLATFORM_MULTIDIRECT) ) return true;
  if( ((state & B_USING_EA) && items.ea <= 0) || ((state & B_USING_MSA) && items.msa <= 0) ) return true;
  return false;
}

bool Player::dontMove() {
  if( lvl->magnetizePlayer || lvl->gameOver || lvl->complete || lvl->transportPlayer ) return true;
  return false;
}

void Level::scrap( tileSequences *ts ) {
  ts->erase();
  //trash.push_back( ts );
  SDL_CreateThread( deleteTileSeq, ts );
}
/*
bool Level::emptyTrash() {
  int s = trash.size();
  for( int i = 0; i < s; i++ )
    if( trash[ i ] != NULL ) {
	  trash[ i ]->endThread = true;
	  SDL_Delay( 100 );
	  return false;
	}
  return true;
}
*/
void Level::clearLevel() {
  int s_tnMap = tnMap.size();
  if( s_tnMap > 0 ) {
    int s_cols = tnMap[ 0 ].size();
  for( int j = 0; j < 2; j++ )
	for( int i = 0; i < s_tnMap; i++ )
      delete[] allSectors[ j ][ i ];
	delete[] allSectors[ 0 ];
	delete[] allSectors[ 1 ];
	delete[] allSectors;
	
    for( int i = 0; i < s_tnMap; i++ )
	  tnMap[ i ].clear();
	tnMap.clear();
  }
  if( magnets.size() > 0 )
    magnets.clear();
  if( otherDynamites.size() > 0 )
    otherDynamites.clear();
  if( goals.size() > 0 )
    goals.clear();
  SDL_FreeSurface( R->screens[ SCREEN_GAME ].windows[ WINDOW_GOALS ]->planes[ 0 ] );
  SDL_FreeSurface( R->screens[ SCREEN_GAME ].windows[ WINDOW_GOALS ]->planes[ 1 ] );
  
  int pS = R->screens[ SCREEN_GAME ].windows[ WINDOW_LEVEL ]->planes.size();
  for( int i = 0; i < pS; i++ )
    SDL_FreeSurface( R->screens[ SCREEN_GAME ].windows[ WINDOW_LEVEL ]->planes[ i ] );
  R->screens[ SCREEN_GAME ].windows[ WINDOW_LEVEL ]->planes.clear();	
}

bool isPlatform( int id ) {
  if( id == T_PLATFORM_UP || id == T_PLATFORM_VERTICAL || id == T_PLATFORM_MULTIDIRECT || id == T_PLATFORM_DOWN || id == T_PLATFORM_LEFT || id == T_PLATFORM_RIGHT || id == T_PLATFORM_HORIZONTAL )
    return true;
  return false;
}
