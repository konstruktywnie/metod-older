#include"game_level.h"

void eventsMenu( SDL_Event *event );
void eventsGame( SDL_Event *event );
void eventsIntro( SDL_Event *event );
