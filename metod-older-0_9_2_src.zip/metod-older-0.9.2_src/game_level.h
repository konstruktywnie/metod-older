#include"app_resources.h"
int playerMoveThread( void *data );
int playerShotThread( void *data );
int playerLassoThread( void *data );
int gameOverThread( void *data );
int timerThread( void *data );

struct Sector {
 // int id;
  tileSequences *look;
  //Image *image;
 // bool movable, sequence;
  int x, y, row, col;
 // uchar type;

  Sector();
};
struct Inventory {
  char key1, key2, key3;
  int ea, msa, pu;
  int time, fuel;
};
struct Level;
struct Player {
  Sector *sector, *prevSector;
  tileSequences *look;
  uchar state;
  int movSectorCount;
  bool shotQueue;
  Inventory items;
  int hitPoints, lassoDirection;
  Level *lvl;
  void move();
  Player();
  bool dontShoot();
  bool dontMove();
  
};
void endingShot( Player *p, int ID, appResources *Res );

//typedef vector< vector< Sector > > Sectors;
typedef vector< vector< MainTiles >  > TilesNamesMap;
struct row_col { int row; int col; };
struct Level {
  TilesNamesMap tnMap;
  Sector ***allSectors;
  //vector<tileSequences*> trash;
  vector<row_col> magnets, otherDynamites;
  vector<int**> goals;
  int allCols, allRows, floorPlane;
  Player player;
  int EA_damage_mod, MSA_damage_mod;
  bool gameOver, complete, scrollV, scrollH, timer, runTimer, magnetizePlayer, transportPlayer;
  char gameOverText[ MAX_LINE ];
  int d_explosion;
  appResources *R;
  Window *win;

  void createTilesNamesMap( char *file );
  void buildLevelWindow( char *file, appResources *res, Window *win );
  void specialLevel( char *buf );
  void adjustTile( tileSequences *l, int &row, int &col );
  void tileLocation( tileSequences *l, int &row, int &col );
  bool checkGoal();
  void removeGoal( int row, int col );
  bool checkMagnets();
  void removeMagnet( int row, int col );
  void scrap( tileSequences *ts );
  //bool emptyTrash();
  void clearLevel();
  void updateTime();
  void updateFuel();
  void updateInfo();
  void makeGoalsInfo();
  void updateGoalsInfo();
  void makeIntroScreen();
  
 // void tileSector( tileSequences *l, int &row, int &col );

  //void getTileLocation( Look *l, int &row, int &col );
};
void makeSplash( int row, int col, appResources *Res, Level *lvl );
void makeExplosion( int row, int col, appResources *Res, Level *lvl, int explosion_ext_id );
void makeNR( int id_nr, int row, int col, appResources *Res, Level *lvl );
void makePlatform( int p_id, Level *lvl, int row, int col );
bool checkPass( int obj, int pass, int rowOff, int colOff, uchar type );
int checkQuarters( Uint32 ball, int &quarters );
int fullHole( int quarters );
void createBall( int ballID, Level *level, int row, int col );
void exploded( Player *p, int row, int col );
bool isPlatform( int id );