#include<SDL/SDL.h>
#include<SDL/SDL_image.h>
#include<SDL/SDL_thread.h>
#include<SDL/SDL_events.h>
#include<vector>
//#include<math.h>
#include<cstring>
#include<stdio.h>
#include<stdlib.h>
#include"config.h"
#include<ctime>

using namespace std;

void apply_surface( int x, int y, SDL_Surface* source, SDL_Surface* destination );
void clear_surface( int x, int y, int w, int h, SDL_Surface* s, Uint32 color );
void apply_pixels( int x, int y, SDL_Surface* source, SDL_Surface* destination );
SDL_Surface* apply_pixelsRev( int x, int y, SDL_Surface* source, SDL_Surface* destination );
SDL_Surface* optimizedSurface( char* f, SDL_PixelFormat *format, int w, int h );
SDL_Surface* emptyPlane( int width, int height );
SDL_Surface* emptyPlane( int width, int height, Uint32 colorFill );
void rectangleOnSurface( int x, int y, SDL_Surface *destination, int width, int height, Uint32 color, unsigned char border, Uint32 borderColor );
SDL_Surface* makeRectangle( int width, int height, Uint32 color, unsigned char border, Uint32 borderColor );
void makeGrid( int x, int y, SDL_Surface *ds, int width, int height, int rows, int cols, int border, Uint32 borderColor );

int scrollWindowThread( void *data );

typedef unsigned char uchar;

struct tileSet;
struct tileSequences;

//typedef tileSequences Look;
//typedef SDL_Surface Image;
typedef SDL_Surface* Plane;
struct sequence;
struct Window {
  static SDL_Surface *scr;
  vector<SDL_Surface*> planes;
  Uint32 winWidth, winHeight, planesWidth, planesHeight;
  int winPosX, winPosY, bgPosX, bgPosY, marginX, marginY;
  int regularPlanesNR;
  bool actualScroll, scrollH, scrollV;
  //bool active, framed, visible;
  //Uint32 frameColor;

  Window();
  void associate( uchar planeNR, tileSequences *t, int seqNR, Uint32 sx, Uint32 sy, int timing );
  //void associateLevel( Level lvl );
  //void drawBackground();
  //void createPlaneFromTileset( tileSet *t, vector< vector< Uint32 > > tm);
  int print( tileSet *font, uchar planeNR, Uint32 x, Uint32 y, const char *fmt, ... );
  int print( tileSet *font, uchar planeNR, Uint32 x, Uint32 y, int spaceH, int spaceV, const char *fmt, ... );

  void redrawPlane( SDL_Surface *plane, Uint32 x, Uint32 y, int width, int height );
  void redrawPlane( SDL_Surface *plane, Uint32 x, Uint32 y, int width, int height, int &inWinX, int &inWinY, int &in_winW, int &in_winH );
  void drawOnPlane( SDL_Surface *source, SDL_Surface *plane, int x, int y );
  void eraseFromPlane( SDL_Surface *source, SDL_Surface *plane, int x, int y );
  void eraseFromPlane( bool all, SDL_Surface *source, SDL_Surface *plane, int x, int y );
  void eraseFromPlane( int w, int h, SDL_Surface *plane, int x, int y );
  //void redrawPlanes( Uint32 x, Uint32 y, int width, int height );
  void redrawAllPlanes();
  void setWindowBgPos( int x, int y );
  void checkWindowBgPos( int xpos, int ypos, int movX, int movY );
  void centerWindowBg( int x, int y );
  //void scroll();
};


struct tileSet {
  vector <SDL_Surface*> tiles;
  int loadFromFile( char *f, int tileWidth, int tileHeight );
  void changeColor( Uint32 search, Uint32 changeTo, Uint32 id );
  void changeColor( Uint32 search, Uint32 changeTo );
  void changeColorAtAlpha( Uint32 changeTo );
  void translucentToTransparent();
  void opaqueToTranslucent( Uint32 andThis );
  void mirror();
  //int print( SDL_Surface *surface, Uint32 x, Uint32 y, const char *fmt, ... );
  int merge( tileSet &ts );
  void copyTile( int index );
  void simpleRotation( int index, int degree );
};

struct sequence{
  int begin, end, currentFrame;//, prevFrame;
  //sequence() : currentFrame(0), prevFrame(-1) {}
};
struct tileSequences {
  tileSet *ts;
  Uint32 id;
  uchar type;
  int timing;
  int actualSeq, prevSeq, prevFrame;
  bool refreshRender, loopedAnimation, useCounter, stop, endThread, collisionCheck, fullCollisionCheck, collided, eraseAtEndThread, endThreadAtCollision, stopAtCollision;
  //bool useIdleCheck;
  int x, y, prev_x, prev_y, prev_movDX, prev_movDY, prev_timing, planeCollisionOffset;
  int movDX, movDY, movCounterX, movCounterY, collisionPercentage, collisionX, collisionY, memMovX, memMovY;//, idleCounter, idleCountActual;
  //void (*movFunction)( tileSequences *ts );
  vector<sequence*> sv;
  Window *win; //associated window
  unsigned char planeNR; //associated plane number in window

  tileSequences();
  void redraw();
  void createSeq();
  void createSeq( int begin, int end );
  //void changeToSeq( int id );
  void newThread();
  bool onView();
  bool borderTouch();
  bool overlap();
  bool overlapFull();
  void adjust();
  void erase();
};
void tileSequencesPushEvent( tileSequences *t, int event_code );
void windowPushEvent( Window *w, int event_code );
int deleteTileSeq( void *data );
