#include"game_events.h"

SDL_Surface *MainScreen;
int scrWidth = SCREEN_RESOLUTION_W;
int scrHeight = SCREEN_RESOLUTION_H;
SDL_mutex *plane_mutex;

int TileWidth;
int allThreads;

Level level;

/*
Uint32 testTimerCallBack(Uint32 interval, void *param)
{
    SDL_Event event;
    SDL_UserEvent userevent;

    userevent.type = SDL_USEREVENT;
    userevent.code = TEST_TIMER;
    userevent.data1 = param;
    userevent.data2 = NULL;

    event.type = SDL_USEREVENT;
    event.user = userevent;

    SDL_PushEvent(&event);
	return interval;
}
*/
int main( int argc, char **argv )
{

// *** screen size in pixels ***

// *** SDL initialization ***
  
  SDL_putenv( "SDL_VIDEO_CENTERED=center" ); //"SDL_VIDEO_WINDOW_POS=2,22" );
  SDL_Init( SDL_INIT_VIDEO );
  plane_mutex = SDL_CreateMutex();
  //SDL_WM_SetCaption("fff", "fff");

  //SDL_Surface *bgrSurface = SDL_CreateRGBSurface(SURFACE_TYPE,scrWidth,scrHeight,32,0xff000000,0x00ff0000,0x0000ff00,0x000000ff);
  //SDL_FillRect( bgrSurface, NULL, BGR_COLOR );
  //SDL_Surface *screen = SDL_CreateWindow( "fff", 0, 0, scrWidth, scrHeight, 0 );
  //SDL_Window *window = SDL_CreateWindow( TITLE_TEXT, 0, 0, scrWidth, scrHeight, 0 );
  SDL_WM_SetCaption( TITLE_TEXT, NULL );
  //SDL_SetWindowTitle( window, TITLE_TEXT );   
  MainScreen = SDL_SetVideoMode(scrWidth, scrHeight, 32, SURFACE_TYPE);//SDL_HWSURFACE );
  SDL_ShowCursor( SDL_DISABLE );

  SDL_Event event;

  for ( int i = 0; i<SDL_NUMEVENTS; i++ )
         if ( i != SDL_USEREVENT && i != SDL_KEYDOWN &&  i != SDL_MOUSEBUTTONDOWN && i != SDL_MOUSEBUTTONUP &&  i != SDL_QUIT )
             SDL_EventState( i, SDL_IGNORE );

  appResources Resources;
  level.R = &Resources;
  TileWidth = Resources.mainTileset.tiles[ 0 ]->w;
  allThreads = 0;
 // level.buildLevelWindow( "data/levels/test", &Resources, Resources.screens[ 0 ].windows[ 1 ] );
  //Resources.playerSeq->newThread();
//  printf( "%d ", level.allSectors[0][0][0].look->id );
  //exit( 0 );
  //Resources.tSeqs.newThread();
  //Resources.tSeqs2.newThread();
  //Resources.tSeqs3.newThread();


 //Resources.playerSeq->actualSeq = 1;
// level.playerSector->look->newThread();
// level.playerSector->look->actualSeq = 2;
 //level.playerSector->look->actualSeq = 1;
 //level.playerSector->look->prevSeq = 0;
 //printf( "%d ", level.allSectors[1][11][13].look );
 //exit(0);
 //level.allSectors[1][12][15].look = Resources.shotEA;
 //Resources.shotEA->actualSeq = 1;
 //level.allSectors[1][12][15].look->newThread();
 //level.allSectors[1][11][15].look->stop = false;

//printf( "{%d %d}\n", level.playerSector->look->sv[3]->end, Resources.playerSeq->sv[3]->end );
//printf( "[%d %d]\n", level.playerSector->look->actualSeq, Resources.playerSeq->actualSeq  );
//printf( "%d ", Resources.playerSeq->actualSeq);
//printf( "(%d)", level.allSectors[0][11][14].look->sv[0]->end);
//level.allSectors[0][8][14].look->newThread();
//level.allSectors[0][8][14].look->movDX = -MOV_DELTA;
//level.allSectors[0][8][14].look->stop = false;
//level.player.look->actualSeq = 11;
//printf( "%d ", level.player.look->sv[ 11 ]->currentFrame );
//apply_surface( 750, 0, level.player.look->ts->tiles[ level.player.look->sv[ level.player.look->actualSeq ]->currentFrame ], MainScreen );
//level.player.look->actualSeq = 0;
/* level.R->lasso->movDX = 1;
 level.R->lasso->newThread();
 level.win->drawOnPlane( level.R->lasso->ts->tiles[ 0 ], level.win->planes[ level.R->lasso->planeNR ], 0, 0 );
 */

 Resources.screens[ SCREEN_GAME ].eventsFun = eventsGame;
 Resources.screens[ SCREEN_INTRO ].eventsFun = eventsIntro;
 //Resources.toTheMenu( false );
 Resources.screens[ SCREEN_MENU ].eventsFun = eventsMenu;
 Resources.screens[ SCREEN_MENU ].windows[ 0 ]->redrawAllPlanes();
 Resources.actualActiveWin = Resources.screens[ SCREEN_MENU ].windows[ 0 ];
 Resources.actualScreen = SCREEN_MENU;

// SDL_AddTimer( 1000, testTimerCallBack, (void*)"$ " );
 // exit(0);
// *** main loop ***
  bool run = true;
  while( Resources.run ) {
    

    if (SDL_WaitEvent(&event))
        {
		  Resources.screens[ Resources.actualScreen ].eventsFun( &event );

        }
	//Resources.tSeqs.draw( screen );
	//Resources.tSeqs2.draw( screen );
	//Resources.font.print( screen, 0, 0, "%s", "Test 7123789!i@#$%^&*?()[]{}<>,." );


  }

/*Resources.tSeqs.endThread = true;
Resources.tSeqs2.endThread = true;
Resources.tSeqs3.endThread = true;
SDL_Delay(1000);
*/
//while( !level.emptyTrash() );
Resources.saveLevelsList();
SDL_DestroyMutex(plane_mutex);

SDL_Quit();
return 0;
}
