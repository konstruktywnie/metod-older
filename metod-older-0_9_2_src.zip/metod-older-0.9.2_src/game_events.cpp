#include"game_events.h"

extern Level level;
//extern appResources Resources;
extern int TileWidth;
extern SDL_Surface *MainScreen;
extern int allThreads;
extern SDL_mutex *plane_mutex;

SDL_Thread *timerTh;

void eventsGame( SDL_Event *event ) {
  switch (event->type)
            {
			    case SDL_USEREVENT:
				/*
                  if( event->user.code == TEST_TIMER ) {
				     char *t = (char*) event->user.data1;
					 printf( "%s ", t );
				   }
				  */
				   if( event->user.code == EVENT_TILESET_ANIMATION ) {
				     tileSequences *tseq = (tileSequences *)event->user.data1;
					/* if( level.gameOver && tseq->id == ID_ANIMATION_EXPLODE ) {
					   if( tseq->sv[ 0 ]->currentFrame == tseq->ts->tiles.size() - 1 )
					      level.gameOverInfo();
				     } else tseq->win->drawTileSeq( tseq );*/
					 tseq->redraw();
					 return;
				   }
				   if( event->user.code == EVENT_TILESET_COLLIDED ) {
				//   	     printf("EVENT_TILESET_COLLIDED \n ");
				     tileSequences *tseq = (tileSequences *)event->user.data1;
					/* tseq->actualSeq = 0;
					 tseq->movDY = -tseq->movDY;
					 tseq->movDX = -tseq->movDX;
					 */
                     if( tseq->id == ID_ANIMATION_EXPLODE_MSA ) {
					  //level.player.state ^= B_SHOOTING;
				/*	  level.R->shotMSA->actualSeq = 0;
					  level.R->shotMSA->movDX = level.R->shotMSA->movDY = 0;
					  level.R->shotMSA->loopedAnimation = false;
					  level.R->shotMSA->collisionCheck = false;
					  level.R->shotMSA->stop = false;
					  level.R->shotMSA->timing = 70;
					  level.R->shotMSA->newThread();*/
					  endingShot( &level.player, ID_ANIMATION_EXPLODE_MSA, level.R );
					  //printf("### ");
					  //level.player.look->win->regularPlanesNR--;
                   /*    tseq->actualSeq = 0;
                       tseq->loopedAnimation = false;
                       tseq->planeNR = 3;
                       tseq->movDX = tseq->movDY = 0;
                       level.player.state ^= B_SHOOTING;
                       tseq->newThread();*/
					   return;
                     }
					 if( tseq->id == ID_ANIMATION_EXPLODE_EA ) {
					   endingShot( &level.player, ID_ANIMATION_EXPLODE_EA, level.R );
					   return;
					 }
                     return;
				   }
				   if( event->user.code == EVENT_WINDOW_SCROLL ) {
				     Window *sWin = (Window *)event->user.data1;

					   sWin->redrawAllPlanes();
                     return;
				   }
				 /*  if( event->user.code == EVENT_WINDOW_END_SCROLL ) {
				     Window *sWin = (Window *)event->user.data1;
					 sWin->checkWindowBgPos(  level.player.look->x, level.player.look->y, level.player.look->memMovX, level.player.look->memMovY  );
				   }*/
				   if( event->user.code == EVENT_TILESET_ANIMATION_ENDED_LOOP ) {
				     tileSequences *tseq = (tileSequences *)event->user.data1;
					 if( tseq->id == ID_ANIMATION_EXPLODE_MSA || tseq->id == ID_ANIMATION_EXPLODE_EA ) {
					   if( level.player.state & B_SHOOTING )
					     level.player.state ^= B_SHOOTING;
                       tseq->endThread = true;
					   if( level.player.look->movDX == 0 && level.player.look->movDY == 0 )
                         level.checkMagnets();
					   return;
					 }
					 if( tseq->id == T_CRUMBLE ) {
					   int row, col;
					   level.tileLocation( tseq, row, col );
					   level.allSectors[ 0 ][ row ][ col ].look = NULL;
					   /*if( level.allSectors[ 0 ][ row ][ col ].look != NULL )
					     if( isPlatform( level.allSectors[ 0 ][ row ][ col ].look->id ) ) {
						   level.allSectors[ 0 ][ row ][ col ].look->win->eraseFromPlane( level.allSectors[ 0 ][ row ][ col ].look->ts->tiles[ 0 ], level.allSectors[ 0 ][ row ][ col ].look->win->planes[ level.allSectors[ 0 ][ row ][ col ].look->planeNR ], level.allSectors[ 0 ][ row ][ col ].look->x, level.allSectors[ 0 ][ row ][ col ].look->y );
						   level.allSectors[ 0 ][ row ][ col ].look->win->drawOnPlane( level.allSectors[ 0 ][ row ][ col ].look->ts->tiles[ 0 ], level.allSectors[ 0 ][ row ][ col ].look->win->planes[ level.allSectors[ 0 ][ row ][ col ].look->planeNR ],  level.allSectors[ 0 ][ row ][ col ].look->x,  level.allSectors[ 0 ][ row ][ col ].look->y );

						   //apply_surface( level.allSectors[ 0 ][ row ][ col ].look->x, level.allSectors[ 0 ][ row ][ col ].look->y, level.allSectors[ 0 ][ row ][ col ].look->ts->tiles[ 0 ], level.allSectors[ 0 ][ row ][ col ].look->win->planes[ level.allSectors[ 0 ][ row ][ col ].look->planeNR ] );
					     }
						 */
					   level.scrap( tseq );
					   return;
					 }
				   if( tseq->id == ID_ANIMATION_SPLASH ) {
                     int row, col;
                     level.tileLocation( tseq, row, col );
				     level.scrap( tseq );
					 return;
					}
                    /* int ods = level.otherDynamites.size();
                     for( int i = 0; i < ods; i++ )
                       exploded( &level.player, level.otherDynamites[ i ].row, level.otherDynamites[ i ].col );
                     */
					 //if( tseq->id == ID_ANIMATION_EXPLODE && level.allSectors[ 1 ][ row ][ col ].look == NULL )
                     if( tseq->id == ID_ANIMATION_EXPLODE ) {
					   level.d_explosion = level.otherDynamites.size();
					   if( level.d_explosion == 0 && level.gameOver && !level.complete ) {

						 SDL_CreateThread( gameOverThread, &level );
					   }
					     //level.R->screens[ SCREEN_GAME ].windows[ WINDOW_INFO ]->eraseFromPlane( WINDOW_LEVEL_WIDTH, WINDOW_LEVEL_HEIGHT, ->planes[ 1 ], 0, 0 );

					   //level.explosion = false;
					   //int row, col;
                       //level.tileLocation( tseq, row, col );


                   /*    if( level.allSectors[ 1 ][ row ][ col ].look->type & B_EXPLODED ) {
					     level.scrap( level.allSectors[ 1 ][ row ][ col ].look );
					     level.allSectors[ 1 ][ row ][ col ].look = NULL;
					     level.allSectors[ 0 ][ row ][ col ].look->type = 0;
					     level.allSectors[ 0 ][ row ][ col ].look->type |= B_PASSABLE;
					   }*/

					   if( level.d_explosion > 0 ) {
					   //if( level.otherDynamites.size() == 1 )
					   // level.R->screens[ 0 ].windows[ 1 ]->redrawAllPlanes();
					   row_col odRowCol;
					   /*
                       odRowCol.row = level.otherDynamites[ level.otherDynamites.size() - 1 ].row;
                       odRowCol.col = level.otherDynamites[ level.otherDynamites.size() - 1 ].col;

                       level.otherDynamites.erase( level.otherDynamites.begin() + level.otherDynamites.size() - 1 );
                       */
					   odRowCol.row = level.otherDynamites[ 0 ].row;
                       odRowCol.col = level.otherDynamites[ 0 ].col;
					  // SDL_LockMutex( plane_mutex );
                       SDL_LockMutex( plane_mutex );
                       level.otherDynamites.erase( level.otherDynamites.begin() );
					   allThreads--;
					   if( level.otherDynamites.size() == 0 )
					     level.d_explosion = 0;
                       SDL_UnlockMutex( plane_mutex );
					   exploded( &level.player, odRowCol.row, odRowCol.col );

					   //SDL_Delay( 200 );
					   //level.allSectors[ 1 ][ row ][ col ].look = NULL;
					   //level.allSectors[ 0 ][ row ][ col ].look->type = 0;
					   //level.allSectors[ 0 ][ row ][ col ].look->type |= B_PASSABLE;
					  // printf( "(%d %d) ", odRowCol.row, odRowCol.col );

					  // SDL_UnlockMutex( plane_mutex );

                     } else if( tseq->memMovX == T_DYNAMITE )
                  		   level.R->screens[ SCREEN_GAME ].windows[ WINDOW_LEVEL ]->redrawAllPlanes();
					       //tseq->redraw();
					   level.scrap( tseq );
				   /*  tseq->erase();
                     level.trash.push_back( tseq );
				     SDL_CreateThread( deleteTileSeq, tseq );*/
				     return;
				   }
				   }
				   if( event->user.code == EVENT_GAME_FULL_HOLE )
				   {
				     tileSequences *tseq = (tileSequences *)event->user.data1;
					 int row, col;
					 level.tileLocation( tseq, row, col );
				     SDL_Delay( 300 );
				 //    level.allSectors[ 0 ][ row ][ col ].look->id = T_FLOOR;
					 level.allSectors[ 0 ][ row ][ col ].look->win->drawOnPlane( level.R->mainTileset.tiles[ T_FLOOR ], level.allSectors[ 0 ][ row ][ col ].look->win->planes[ level.allSectors[ 0 ][ row ][ col ].look->planeNR ], level.allSectors[ 0 ][ row ][ col ].x, level.allSectors[ 0 ][ row ][ col ].y );

					// printf( "%d ", tseq->collisionY );
					 createBall( tseq->collisionY, &level, row, col );
					 level.R->screens[ SCREEN_GAME ].windows[ WINDOW_LEVEL ]->redrawAllPlanes();
					 return;
				   }
				   if( event->user.code == EVENT_TILESET_ENDED_MOVCOUNTER ) {
	                 tileSequences *tseq = (tileSequences *)event->user.data1;
					 int row, col;
					 level.tileLocation( tseq, row, col );

					 if( tseq->id == T_PLAYER ) {// || tseq->id == T_PLAYER_EA || tseq->id == T_PLAYER_MSA || tseq->id == T_PLAYER_PU || (tseq->id >= T_PLAYER_EA_DOWN && tseq->id <= T_PLAYER_PU_RIGHT) ) {
                        // level.player.prevSector = level.player.sector;
		                // level.player.sector = &level.allSectors[ 0 ][ row ][ col ];

						 level.R->screens[ SCREEN_GAME ].windows[ 0 ]->checkWindowBgPos( level.player.look->x, level.player.look->y, level.player.look->memMovX, level.player.look->memMovY );

						 level.checkMagnets();
						 //if( level.d_explosion > 1 )
						  // level.R->screens[ SCREEN_GAME ].windows[ WINDOW_LEVEL ]->redrawAllPlanes();

						 if( !level.magnetizePlayer ) {
 						   level.player.items.fuel--;
						   level.updateFuel();
						 }
						 if( level.player.items.fuel < 1 && !level.complete ) {
						   level.gameOver = true;
						   strcpy( level.gameOverText, " Out of fuel" );
						   SDL_CreateThread( gameOverThread, &level );

						 }
						return;
					 }
                     if( level.player.lassoDirection == P_STAND && (tseq->id >= T_BALL1 && tseq->id <= T_BALL6 || tseq->id == T_BALL7) ) {

					   if( level.allSectors[ 0 ][ row ][ col ].look == NULL ) {
                         level.scrap( tseq );
                         makeSplash( row, col, level.R, &level );
						 level.allSectors[ 1 ][ row ][ col ].look = NULL;
                       } else {
					   int quarterID = -1;
                       if( level.allSectors[ 0 ][ row ][ col ].look->id == T_HOLE ) {

                         if( (quarterID = checkQuarters( level.allSectors[ 1 ][ row ][ col ].look->id, level.allSectors[ 0 ][ row ][ col ].look->collisionX )) != -1 ) {
                           level.scrap( tseq );
						   level.allSectors[ 1 ][ row ][ col ].look = NULL;
						   level.allSectors[ 0 ][ row ][ col ].look->type |= B_PASSABLE;
						   level.allSectors[ 0 ][ row ][ col ].look->win->drawOnPlane( level.R->mainTileset.tiles[ quarterID ], level.allSectors[ 0 ][ row ][ col ].look->win->planes[ level.allSectors[ 0 ][ row ][ col ].look->planeNR ], level.allSectors[ 0 ][ row ][ col ].x, level.allSectors[ 0 ][ row ][ col ].y );
						   tileSequencesPushEvent( tseq, EVENT_TILESET_ANIMATION );


						   if( (level.allSectors[ 0 ][ row ][ col ].look->collisionY = fullHole( level.allSectors[ 0 ][ row ][ col ].look->collisionX )) != -1 ) {

							// printf( "$$%d ", level.allSectors[ 0 ][ row ][ col ].look->collisionY );
							 tileSequencesPushEvent( level.allSectors[ 0 ][ row ][ col ].look, EVENT_GAME_FULL_HOLE );
						   }
						 }
					   }
					   if( quarterID == -1 ) {
					   int rowOff = 0, colOff = 0;
                       if( tseq->memMovX < 0 && (col - 1 >= 0) ) colOff = -1;
                       if( tseq->memMovX > 0 && (col + 1 < level.allCols ) ) colOff = 1;
                       if( tseq->memMovY > 0 && (row + 1 < level.allRows ) ) rowOff = 1;
                       if( tseq->memMovY < 0 && (row - 1 >= 0) ) rowOff = -1;
                       if( rowOff != 0 || colOff != 0 ) {
					   Sector *f = &level.allSectors[ 0 ][ row + rowOff ][ col + colOff ];
                       Sector *af = &level.allSectors[ 1 ][ row + rowOff ][ col + colOff ];
					   Sector *cf = &level.allSectors[ 0 ][ row ][ col ];
					   Sector *c = &level.allSectors[ 1 ][ row ][ col ];

					   if( (f->look != NULL && (f->look->type & B_PASSABLE) && !(f->look->type & B_ITEM)) || f->look == NULL ) {
					   //  if( (c->look->id == T_BALL1 && f->look->id == T_PASS1) ) {
					     bool passIt = true;
						 if( c->look != NULL && f->look != NULL ) passIt = checkPass( c->look->id, f->look->id, rowOff, colOff, c->look->type );
						/* if( f->look != NULL && ((f->look->id >= T_PASS1 && f->look->id <= T_PASS6) || (f->look->id >= T_PASS1_H && f->look->id <= T_PASS6_H) || (f->look->id >= T_PASS1_LEFT && f->look->id <= T_PASS6_DOWN)) )
						   pass = true;
						 if( pass && (c->look->id == T_BALL1) )
						   if( !(f->look->id == T_PASS1 || f->look->id == T_PASS1_H) && !(f->look->id == T_PASS1_UP && rowOff < 0) && !(f->look->id == T_PASS1_DOWN && rowOff > 0) && !(f->look->id == T_PASS1_RIGHT && colOff > 0) && !(f->look->id == T_PASS1_LEFT && colOff < 0) )
  						     passBall = false;*/

						 if( passIt ) {
						 cf->look->type |= B_PASSABLE;
						 if( f->look != NULL ) f->look->type ^= B_PASSABLE;
						 af->look = c->look;
						 c->look = NULL;
						 //af->look->type |= B_MOVABLE;

					     tseq->movDX = tseq->memMovX;
					     tseq->movDY = tseq->memMovY;
					     tseq->movCounterX = tseq->movCounterY = TileWidth / MOV_DELTA;
	                 //  tseq->useCounter = true;

					     tseq->newThread();

						 if( cf->look != NULL && cf->look->id == T_CRUMBLE ) {
		                 cf->look->newThread();
		    //p->lvl->trash.push_back( cf->look );
            //p->lvl->scrap( cf->look );
                         cf->look = NULL;
		                 }
					  // printf( "(%d %d) ", tseq->movDX, tseq->movDY );
					   }// else {
					     //printf( "{%d}", level.goals.size() );

					   //}
					   }

					   }
					   }
					   if( tseq->movDX == 0 && tseq->movDY == 0 ) {
					     //if( (tseq->id >= T_BALL1 && tseq->id <= T_BALL6) || tseq->id == T_BALL7 )
						  // allThreads--;
						 level.checkGoal();
					   }
					  }
					 }

					 if( level.player.lassoDirection != P_STAND &&  (tseq->id >= T_BALL1 && tseq->id <= T_BALL6 || tseq->id == T_BALL7) ) {
                       //tseq->adjust();
					   //if( !level.magnetizePlayer )
					  // level.checkMagnets();
					   if( level.allSectors[ 0 ][ row ][ col ].look->id == T_HOLE ) {
                         int quarterID;
                         if( (quarterID = checkQuarters( level.allSectors[ 1 ][ row ][ col ].look->id, level.allSectors[ 0 ][ row ][ col ].look->collisionX )) != -1 ) {
                           level.scrap( tseq );
						   level.allSectors[ 1 ][ row ][ col ].look = NULL;
						   level.allSectors[ 0 ][ row ][ col ].look->type |= B_PASSABLE;
						   level.allSectors[ 0 ][ row ][ col ].look->win->drawOnPlane( level.R->mainTileset.tiles[ quarterID ], level.allSectors[ 0 ][ row ][ col ].look->win->planes[ level.allSectors[ 0 ][ row ][ col ].look->planeNR ], level.allSectors[ 0 ][ row ][ col ].x, level.allSectors[ 0 ][ row ][ col ].y );
						   tileSequencesPushEvent( tseq, EVENT_TILESET_ANIMATION );
						   if( (level.allSectors[ 0 ][ row ][ col ].look->collisionY = fullHole( level.allSectors[ 0 ][ row ][ col ].look->collisionX )) != -1 ) {
						     //SDL_Delay( 300 );
							 tileSequencesPushEvent( level.allSectors[ 0 ][ row ][ col ].look, EVENT_GAME_FULL_HOLE );
							 //level.player.lassoDirection = P_STAND;
						   }
						 }
					   } else {
					     level.checkGoal();
					   }
                        return;
					 }
					 if( tseq->id == T_PLATFORM_M ) {
					   if( level.allSectors[ 0 ][ row ][ col ].look == NULL ) {
                         level.scrap( tseq );
					     makePlatform( T_PLATFORM, &level, row, col );

						 level.checkMagnets();
					   }
					 }
					 if( (tseq->type & B_ITEM) || (tseq->id >= T_GEM1 && tseq->id <= T_GEM6) ) {
					 //  level.checkMagnets();
					   if( level.allSectors[ 0 ][ row ][ col ].look == NULL ) {
                         level.scrap( tseq );
                         makeSplash( row, col, level.R, &level );
						 level.allSectors[ 1 ][ row ][ col ].look = NULL;
                       }
                        level.checkGoal();
						return;
					 }
					 if( (tseq->id >= T_N0 && tseq->id <= T_N9) ) {
					  //level.checkMagnets();
					   if( tseq->id == T_N0 ) {
					     level.scrap( tseq );
						 makeExplosion( row, col, level.R, &level, 0 );
						 level.allSectors[ 0 ][ row ][ col ].look->type |= B_PASSABLE;
						 level.allSectors[ 1 ][ row ][ col ].look = NULL;
					   } else {
					     level.scrap( tseq );
						 makeNR( tseq->id - 1, row, col, level.R, &level );

					   }
					   return;
					 }
					 if( (tseq->id >= T_DN0 && tseq->id <= T_DN9) ) {
					   //level.checkMagnets();
					   if( tseq->id == T_DN0 ) {
					     level.scrap( tseq );
						 makeNR( T_GEM_DARK, row, col, level.R, &level );
						 level.allSectors[ 0 ][ row ][ col ].look->type = 0;
						 level.allSectors[ 1 ][ row ][ col ].look->type = 0;



					   } else {
					     level.scrap( tseq );
						 makeNR( tseq->id - 1, row, col, level.R, &level );

					   }
					   return;
					 }

                    //if( tseq->id == T_PLATFORM_LEFT || tseq->id == T_PLATFORM_RIGHT || tseq->id == T_PLATFORM_UP || tseq->id == T_PLATFORM_DOWN || tseq->id == T_PLATFORM_HORIZONTAL || tseq->id == T_PLATFORM_VERTICAL || tseq->id == T_PLATFORM_MULTIDIRECT ) {
    				  if( isPlatform( tseq->id ) ) {
					//level.checkMagnets();
					   level.allSectors[ 0 ][ row ][ col ].look = tseq;

                       level.player.prevSector = level.player.sector;
					   level.player.sector = &level.allSectors[ 0 ][ row ][ col ];
                       //printf( "%d ", level.allSectors[ 0 ][ row ][ col ].look->id );
					//   updateSurroundings( &level.player, md, false );
					//   SDL_UnlockMutex( plane_mutex );
                      // if(level.allSectors[1][row][col+1].look !=NULL){level.allSectors[1][row][col+1].look->win->drawOnPlane( ts->tiles[ sv[ actualSeq ]->currentFrame ] ); }
                       //level.player.look->usePointerToXY = false;
					//   SDL_Delay( MOV_DELAY + 1 );
					   //tseq->win->drawTileSeq( level.player.sector->look );
					  // level.player.state ^= B_MOVING;
					// printf( "$ " );
					 return;
					 }

				   }

				 	break;
                case SDL_QUIT:
				    SDL_Delay( 1100 );
                    level.R->run = false;
					/*if( allThreads == 0 ) {
                      level.R->toTheMenu();

					}*/
					break;
				//case SDL_KEYUP:

				//  break;
				case SDL_KEYDOWN:
				    if( (event->key.keysym.sym == SDLK_LALT || event->key.keysym.sym == SDLK_RALT) && !level.player.shotQueue && !level.magnetizePlayer && !level.gameOver && !level.complete ) {// && !(level.player.state & B_MOVING) ) {
					  uchar shotType;
					  uchar bitMask = B_USING_MSA + B_USING_EA + B_USING_PU;
					  shotType = level.player.state & bitMask;
					  uchar shotTypePrev = shotType;
					  if( shotType == B_USING_PU ) { shotType = B_USING_MSA; level.player.look->actualSeq -= 8; }
					  else { shotType <<= 1; level.player.look->actualSeq += 4; }
					  level.player.state ^= shotTypePrev;
					  level.player.state |= shotType;
				//	  printf( "%d %d| ", shotType, level.player.look->actualSeq  );
					  level.player.look->newThread();
					  //level.player.look->win->drawTileSeq( level.player.look );
					}
				    if( (event->key.keysym.sym == SDLK_LCTRL || event->key.keysym.sym == SDLK_RCTRL) && !(event->key.keysym.sym == SDLK_RALT) ) { //&& !level.player.shotQueue ) {// && !(level.player.state & B_MOVING) ) {
			      // if( event->key.keysym.mod & KMOD_LCTRL ) {
			/*	      if( level.player.look->actualSeq == 0  && level.player.sector->row > 0 )
					    if( level.allSectors[ 1 ][ level.player.sector->row - 1 ][ level.player.sector->col ].look == NULL || (level.allSectors[ 1 ][ level.player.sector->row - 1 ][ level.player.sector->col ].look != NULL && (level.allSectors[ 1 ][ level.player.sector->row - 1 ][ level.player.sector->col ].look->type & B_PASSABLE)) )
					    {
						  level.R->shotMSA->x = level.allSectors[ 1 ][ level.player.sector->row ][ level.player.sector->col ].x;// + TileWidth / 3;
						  level.R->shotMSA->y = level.allSectors[ 1 ][ level.player.sector->row ][ level.player.sector->col ].y - TileWidth / 2;
                          level.R->shotMSA->movDX = 0;
                          level.R->shotMSA->movDY = -MOV_DELTA;
                          level.R->shotMSA->actualSeq = 1;
						  level.R->shotMSA->timing = MOV_SHOT_DELAY;
						  level.R->shotMSA->loopedAnimation = true;
						  level.R->shotMSA->collisionCheck = true;
						  level.R->shotMSA->sv[ 0 ]->currentFrame = 0;
                          //level.R->shotMSA->planeNR = 2;
                        //  printf( "%d %d (%d %d) ", level.R->shotMSA->planeNR, level.R->shotMSA->win->regularPlanesNR, level.R->shotMSA->x, level.R->shotMSA->y );
						  level.player.state |= B_SHOOTING;
						//  level.player.look->win->regularPlanesNR++;
						  level.R->shotMSA->newThread();
						//  printf( "!!! " );
					    }
*/
                      if( (level.player.state & B_USING_EA) || (level.player.state & B_USING_MSA) )
                        SDL_CreateThread( playerShotThread, &level.player );
					  if( level.player.state & B_USING_PU )
					    SDL_CreateThread( playerLassoThread, &level.player );
					}
				    if( (event->key.keysym.sym == SDLK_RIGHT || event->key.keysym.sym == SDLK_LEFT || event->key.keysym.sym == SDLK_UP || event->key.keysym.sym == SDLK_DOWN) && !(level.R->actualActiveWin->actualScroll) ) {
					  Uint8 *keystate = SDL_GetKeyState( NULL );
					  //if(event->key.keysym.mod & KMOD_CTRL) {
					  if( keystate[ SDLK_SPACE ] ) {
					  //if ( keystate[ SDLK_RCTRL ] || keystate[ SDLK_LCTRL ] ) {
					    //level.R->actualActiveWin->scroll();

						  if( level.player.look->movDX == 0 && level.player.look->movDY == 0 && allThreads == 0 ) {//level.otherDynamites.size() == 0 ) {

						    SDL_CreateThread( scrollWindowThread, level.R->actualActiveWin );
						  }
					  } else if( !level.R->actualActiveWin->actualScroll )// && !level.magnetizePlayer ) //if( !(level.player.state & B_MOVING) )// && (level.player.sector->look->endThread == true) )
					           SDL_CreateThread( playerMoveThread, &level.player );


					}

                    if( event->key.keysym.sym == SDLK_ESCAPE && allThreads == 0 ) {
                       if( level.timer ) {
					     level.runTimer = false;
						 SDL_WaitThread( timerTh, 0 );
					   }
					   if( !level.gameOver && !level.complete ) {

                         level.R->toTheMenu( true );
					   }


					// level.R->tSeqs2.stop = !level.R->tSeqs2.stop;
					 //level.R->tSeqs2.movDY = level.R->tSeqs2.movDX = 0;
					 //level.R->tSeqs2.stop = true;
					 }
					 if( (event->key.keysym.sym != SDLK_UP && event->key.keysym.sym != SDLK_DOWN && event->key.keysym.sym != SDLK_LEFT && event->key.keysym.sym != SDLK_RIGHT ) && ((level.gameOver || level.magnetizePlayer || level.complete) && level.R->actualActiveWin == level.R->screens[ SCREEN_GAME ].windows[ WINDOW_GAMEOVER ]) ) {

						 level.R->toTheMenu( false );
                       }

					break;
			/*	case SDL_MOUSEBUTTONDOWN:
				    if( event->button.button == SDL_BUTTON_LEFT ) {
				     // AsciiWindow::input.mouseL = true;
					}

					if( event->button.button == SDL_BUTTON_RIGHT ) {
				     // AsciiWindow::input.mouseR = true;
					}

					//AsciiWindow::input.mouseX = event->button.x / font.maxWidth;
					//AsciiWindow::input.mouseY = event->button.y / font.maxHeight;

					//game.gameInput();
                    break;

                 case  SDL_MOUSEBUTTONUP:
				    if( event->button.button == SDL_BUTTON_LEFT );
				      //AsciiWindow::input.mouseL = false;

					if( event->button.button == SDL_BUTTON_RIGHT );
				      //AsciiWindow::input.mouseR = false;
                    break;*/
            }
}

char levelFullPath[ MAX_LINE ];
void eventsMenu( SDL_Event *event ) {

switch (event->type)
{
 case SDL_KEYDOWN:
  if( event->key.keysym.sym == SDLK_ESCAPE ) {
   // level.R->run = false;
  }
  if( event->key.keysym.sym == SDLK_DOWN && level.R->menu.actualMenuEl < level.R->menu.maxEl ) {
    level.R->menu.prevMenuEl = level.R->menu.actualMenuEl;
	level.R->menu.actualMenuEl++;
	level.R->menu.updateSelection();
    level.R->screens[ SCREEN_MENU ].windows[ 0 ]->redrawAllPlanes();

  }
  if( event->key.keysym.sym == SDLK_UP && level.R->menu.actualMenuEl > 0 ) {
    level.R->menu.prevMenuEl = level.R->menu.actualMenuEl;
	level.R->menu.actualMenuEl--;
	level.R->menu.updateSelection();
    level.R->screens[ SCREEN_MENU ].windows[ 0 ]->redrawAllPlanes();

  }
  if( event->key.keysym.sym == SDLK_RIGHT && level.R->menu.actualMenuEl == 0 && level.R->menu.nextLevel[ 0 ] != 0 ) {

	level.R->menu.w->eraseFromPlane( level.R->menu.menuElements[ 0 ].box, level.R->menu.w->planes[ 1 ], level.R->menu.menuElements[ 0 ].x - level.R->menu.fW / 2, level.R->menu.menuElements[ 0 ].y - level.R->menu.fH / 2 );
	level.R->menu.w->eraseFromPlane( level.R->menu.fW * (6 + strlen( level.R->menu.menuElements[ 0 ].text )), level.R->menu.fH, level.R->menu.w->planes[ 2 ], level.R->menu.menuElements[ 0 ].x - level.R->menu.fW * 3, level.R->menu.menuElements[ 0 ].y );
	strcpy( level.R->menu.actualLevel, level.R->menu.nextLevel );
    strcpy( level.R->menu.menuElements[ 0 ].text, level.R->menu.nextLevel );
	level.R->menu.getNeighbourLevelsNames();
	level.R->menu.prevMenuEl = -1;


	SDL_FreeSurface( level.R->menu.menuElements[ 0 ].box );
	level.R->menu.menuElements[ 0 ].box = makeRectangle( (strlen( level.R->menu.actualLevel ) + 1) * level.R->menu.fW, level.R->menu.fH * 2, MENU_SELECT_COLOR, 2, BORDER_MENU_COLOR );
    level.R->menu.updateSelection();
	level.R->menu.w->print( level.R->menu.font, 2, level.R->menu.menuElements[ 0 ].x, level.R->menu.menuElements[ 0 ].y, "%s", level.R->menu.menuElements[ 0 ].text );

	level.R->screens[ SCREEN_MENU ].windows[ 0 ]->redrawAllPlanes();

  }
  if( event->key.keysym.sym == SDLK_LEFT && level.R->menu.actualMenuEl == 0 && level.R->menu.prevLevel[ 0 ] != 0 ) {

	level.R->menu.w->eraseFromPlane( level.R->menu.menuElements[ 0 ].box, level.R->menu.w->planes[ 1 ], level.R->menu.menuElements[ 0 ].x - level.R->menu.fW / 2, level.R->menu.menuElements[ 0 ].y - level.R->menu.fH / 2 );
	level.R->menu.w->eraseFromPlane( level.R->menu.fW * (6 + strlen( level.R->menu.menuElements[ 0 ].text )), level.R->menu.fH, level.R->menu.w->planes[ 2 ], level.R->menu.menuElements[ 0 ].x - level.R->menu.fW * 3, level.R->menu.menuElements[ 0 ].y );
	strcpy( level.R->menu.actualLevel, level.R->menu.prevLevel );
    strcpy( level.R->menu.menuElements[ 0 ].text, level.R->menu.prevLevel );
	level.R->menu.getNeighbourLevelsNames();
	level.R->menu.prevMenuEl = -1;


	SDL_FreeSurface( level.R->menu.menuElements[ 0 ].box );
	level.R->menu.menuElements[ 0 ].box = makeRectangle( (strlen( level.R->menu.actualLevel ) + 1) * level.R->menu.fW, level.R->menu.fH * 2, MENU_SELECT_COLOR, 2, BORDER_MENU_COLOR );
    level.R->menu.updateSelection();
	level.R->menu.w->print( level.R->menu.font, 2, level.R->menu.menuElements[ 0 ].x, level.R->menu.menuElements[ 0 ].y, "%s", level.R->menu.menuElements[ 0 ].text );

	level.R->screens[ SCREEN_MENU ].windows[ 0 ]->redrawAllPlanes();

  }
  if( event->key.keysym.sym == SDLK_RETURN && level.R->menu.actualMenuEl == 1 ) {
    level.R->run = false;
  }
  if( (event->key.keysym.sym == SDLK_RETURN || event->key.keysym.sym == SDLK_SPACE || event->key.keysym.sym == SDLK_LCTRL || event->key.keysym.sym == SDLK_LALT) && level.R->menu.actualMenuEl == 0 ) {
    level.clearLevel();
    sprintf( levelFullPath, "data\\levels\\%s\0", level.R->menu.actualLevel );
    level.buildLevelWindow( levelFullPath, level.R, level.R->screens[ SCREEN_GAME ].windows[ 0 ] );

	if( level.timer && level.R->introFile[ 0 ] == 0 ) {
	  level.runTimer = true;
	  timerTh = SDL_CreateThread( timerThread, &level.player );
	}

    level.R->toTheGame( false );
	if( level.R->introFile[ 0 ] != 0 ) {
      level.R->introFile[ 0 ] = 0;
      level.R->toTheIntro();
	}
  }
  if( event->key.keysym.sym == SDLK_RETURN && level.R->menu.actualMenuEl == 2 ) {
    if( level.timer ) {
	  level.runTimer = true;
	  timerTh = SDL_CreateThread( timerThread, &level.player );
	}
    level.R->toTheGame( true );
  }

 break;
 case SDL_QUIT:
  level.R->run = false;
}
}

void eventsIntro( SDL_Event *event ) {
  switch (event->type)
  {
    case SDL_KEYDOWN:
	  Window *w = level.R->screens[ SCREEN_INTRO ].windows[ 0 ];
	  if( (w->bgPosY == w->planes[ 1 ]->h - WINDOW_INTRO_HEIGHT && event->key.keysym.sym != SDLK_UP) || (w->bgPosY == 0 && event->key.keysym.sym != SDLK_DOWN) ) {
		  if( level.timer ) {

	        level.runTimer = true;
	        timerTh = SDL_CreateThread( timerThread, &level.player );
	      }
	      level.R->toTheGame( true );
		  break;
	  }
	  if( event->key.keysym.sym == SDLK_DOWN || event->key.keysym.sym == SDLK_SPACE || event->key.keysym.sym == SDLK_RETURN || event->key.keysym.sym == SDLK_LCTRL || event->key.keysym.sym == SDLK_RCTRL || event->key.keysym.sym == SDLK_ESCAPE ) {

	    w->bgPosY += WINDOW_INTRO_HEIGHT;
		if( w->bgPosY > w->planes[ 1 ]->h - WINDOW_INTRO_HEIGHT )
		  w->bgPosY = w->planes[ 1 ]->h - WINDOW_INTRO_HEIGHT;
	    w->redrawAllPlanes();
	  }
	  if( event->key.keysym.sym == SDLK_UP ) {
	/*    if( w->bgPosY == 0 )
		  level.R->toTheGame( true );*/
		w->bgPosY -= WINDOW_INTRO_HEIGHT;
		if( w->bgPosY < 0 )
		  w->bgPosY = 0;
		w->redrawAllPlanes();
	  }

	break;
  }
}
