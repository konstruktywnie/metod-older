#include"app_draw_sdl.h"
#include<cstdarg>
//#include<cstdio>

extern SDL_Surface *MainScreen;
extern SDL_mutex *plane_mutex;
extern int allThreads;

void apply_surface( int x, int y, SDL_Surface* source, SDL_Surface* destination )
{
    SDL_Rect offset;
    offset.x = x;
    offset.y = y;
	SDL_SetAlpha( source, SDL_SRCALPHA, SDL_ALPHA_OPAQUE ); //SDL_SRCALPHA  or 0
    SDL_BlitSurface( source, NULL, destination, &offset );

}
void clear_surface( int x, int y, int w, int h, SDL_Surface* s, Uint32 color ) {
  SDL_Rect clear;
  clear.x = x;
  clear.y = y;
  clear.w = w;
  clear.h = h;
  SDL_FillRect( s, &clear, color );
}
void apply_pixels( int x, int y, SDL_Surface* source, SDL_Surface* destination )
{
  Uint32 *pixels1 = (Uint32 *)source->pixels;
  Uint32 *pixels2 = (Uint32 *)destination->pixels;

  for( int i = 0; i < source->h; i++ ) {
    int dRow = (i + y) * destination->w;
	int sRow = i * source->w;
    for( int j = 0; j < source->w; j++ ) {
	  if( (pixels1[ sRow + j ] & 0xff) != 0 )
	    pixels2[ dRow + j + x ] = pixels1[ sRow + j ];
	}
  }

}

SDL_Surface* emptyPlane( int width, int height ) {
  SDL_Surface *s = SDL_CreateRGBSurface( SURFACE_TYPE, width, height, 32, 0xff000000, 0x00ff0000, 0x0000ff00, 0x000000ff );
  SDL_FillRect( s, NULL, 0 );
  return s;
}
SDL_Surface* emptyPlane( int width, int height, Uint32 fill ) {
  SDL_Surface *s = SDL_CreateRGBSurface( SURFACE_TYPE, width, height, 32, 0xff000000, 0x00ff0000, 0x0000ff00, 0x000000ff );
  SDL_FillRect( s, NULL, fill );
  return s;
}

SDL_Surface* apply_pixelsRev( int x, int y, SDL_Surface* source, SDL_Surface* destination )
{
    SDL_Surface *ns = emptyPlane( source->w,  source->h );
	apply_pixels( 0, 0, source, ns );
    apply_pixels( 0, 0, destination, ns );
    SDL_FreeSurface( destination );
	return ns;
}

SDL_Surface* makeRectangle( int width, int height, Uint32 color, unsigned char border, Uint32 borderColor ) {
  SDL_Surface *s = SDL_CreateRGBSurface( SURFACE_TYPE, width, height, 32, 0xff000000, 0x00ff0000, 0x0000ff00, 0x000000ff );
  SDL_FillRect(s, NULL, color );
  if( border > 0 ) {
    Uint32 *pixels = (Uint32 *)s->pixels;

    for( int i = 0; i < s->h; i++ ) {
	  int sRow = i * s->w;
      for( int j = 0; j < s->w; j++ ) {
	    if( (j > -1 && j < border) || (j > s->w - border - 1 && j < s->w) || (i > -1 && i < border) || (i > s->h - border - 1 && i < s->h) ) {
	      pixels[ sRow + j ] = borderColor;

		}
	}

   }
  }
  return s;
}

void rectangleOnSurface( int x, int y, SDL_Surface *destination, int width, int height, Uint32 color, unsigned char border, Uint32 borderColor ) {
  SDL_Surface *s = makeRectangle( width, height, color, border, borderColor );
  apply_surface( x, y, s, destination );
  SDL_FreeSurface( s );
}

SDL_Surface* optimizedSurface( char* f, SDL_PixelFormat *format, int w, int h ) {
  SDL_Surface *image = IMG_Load( f );
  SDL_Surface *destination;
//  SDL_SetAlpha( image, 0, SDL_SRCALPHA );

  if( (w == image->w && h == image->h) || (w == 0 && h == 0) ) {
    destination = IMG_Load( f );
  } else {
    destination = emptyPlane( w, h, 0x000000ff );
	SDL_Rect s, d;
	s.x = d.x = 0;
	s.y = d.y = 0;
	s.w = d.w = w;
	s.h = d.h = h;

	if( image->w > w && image->h > h ) {
      SDL_BlitSurface( image, &s, destination, &d );
	}
	if( image->w < w || image->h < h ) {
	s.w = image->w;
	s.h = image->h;

	int mw = w / image->w + 1;
	int mh = h / image->h + 1;
	for( int i = 0; i < mh; i++ ) {
	  for( int j = 0; j < mw; j++ ) {
	    SDL_BlitSurface( image, &s, destination, &d );
		d.x += image->w;
	  }

	  d.y += image->h;
	  d.x = 0;
	}

	}

  }

  SDL_Surface *optimized = SDL_ConvertSurface( destination, format, 0 );
  SDL_FreeSurface( destination );
  SDL_FreeSurface( image );

  return optimized;
}

int tileSet::loadFromFile( char *f, int tileWidth, int tileHeight ) {
  SDL_Surface *image;
  image = IMG_Load( f );
  //image = optimizedSurface( f, format, 0, 0 );
  if( !f || image == NULL ) {
    printf( "Error: Can not load image: %s\n", f );
    exit( 1 );
  }
  SDL_SetAlpha( image, 0, SDL_ALPHA_OPAQUE );

  if( tileWidth == 0 && tileHeight == 0 ) {  //working out square tile size in case of elongated mosaic
    if( image->w >= image->h )
	  tileWidth = image->h;
	else tileWidth = image->w;

	tileHeight = tileWidth;
  }


  int tilesRows = image->h / tileHeight;
  int tilesCols = image->w / tileWidth;
  //printf( "%d %d ; %dx%d\n", tilesRows, tilesCols, image->w, image->h );

  SDL_Rect s;
  s.w = tileWidth;
  s.h = tileHeight;
  SDL_Rect d;
  d.w = tileWidth;
  d.h = tileHeight;
  d.x = 0;
  d.y = 0;

  s.x = 0;
  s.y = 0;

  for( int i = 0; i < tilesRows; i++ ) {
    for( int j = 0; j < tilesCols; j++ ) {
	  s.x = j * tileWidth;
      s.y = i * tileHeight;
	  SDL_Surface *tile = SDL_CreateRGBSurface( SURFACE_TYPE, tileWidth, tileHeight, 32, 0xff000000, 0x00ff0000, 0x0000ff00, 0x000000ff );
	  SDL_BlitSurface( image, &s, tile, &d);
	  //SDL_SetColorKey(tile,SDL_SRCCOLORKEY,SDL_MapRGB(tile->format,255,0,255));
	  tiles.push_back( tile );

	}
  }

  SDL_FreeSurface( image );
  return tiles.size();
}

void tileSet::changeColor( Uint32 search, Uint32 changeTo, Uint32 i ) {
  Uint32 *pixels = (Uint32 *)tiles[ i ]->pixels;
    for( int j = 0; j < tiles[ i ]->h; j++ ) {
	  for( int k = 0; k < tiles[ i ]->w; k++ ) {
	   // printf( "0x%08x ", pixels[ ( j * tiles[ i ]->w ) + k ] );
	    if( pixels[ ( j * tiles[ i ]->w ) + k ] == search )
		  pixels[ ( j * tiles[ i ]->w ) + k ] = changeTo;

	  }
	}
}

void tileSet::changeColor( Uint32 search, Uint32 changeTo ) {
  Uint32 ts = tiles.size();
  for( int i = 0; i < ts; i++ ) {
    changeColor( search, changeTo, i );
  }
}

void tileSet::changeColorAtAlpha( Uint32 changeTo ) {
  Uint32 ts = tiles.size();
  for( int i = 0; i < ts; i++ ) {
    Uint32 *pixels = (Uint32 *)tiles[ i ]->pixels;
    for( int j = 0; j < tiles[ i ]->h; j++ ) {
	  for( int k = 0; k < tiles[ i ]->w; k++ ) {
	    if( (pixels[ j * tiles[ i ]->w + k ] & 0xff) != 0 )
		  pixels[ j * tiles[ i ]->w + k ] = changeTo;

	  }
	}
  }
}

void tileSet::translucentToTransparent() {
  Uint32 ts = tiles.size();
  for( int i = 0; i < ts; i++ ) {
    Uint32 *pixels = (Uint32 *)tiles[ i ]->pixels;
    for( int j = 0; j < tiles[ i ]->h; j++ ) {
	  for( int k = 0; k < tiles[ i ]->w; k++ ) {
	    if( (pixels[ j * tiles[ i ]->w + k ] & 0x000000ff) != 0xff ) {
		//printf("%d ", i);
		  pixels[ j * tiles[ i ]->w + k ] &= 0xffffff00;


		  }

	  }
	}
  }
}

void tileSet::opaqueToTranslucent( Uint32 andThis ) {
  Uint32 ts = tiles.size();
  for( int i = 0; i < ts; i++ ) {
    Uint32 *pixels = (Uint32 *)tiles[ i ]->pixels;
    for( int j = 0; j < tiles[ i ]->h; j++ ) {
	  for( int k = 0; k < tiles[ i ]->w; k++ ) {
	    if( (pixels[ j * tiles[ i ]->w + k ] & 0x000000ff) == 0xff ) {
		//printf("%d ", i);
		  pixels[ j * tiles[ i ]->w + k ] &= andThis;


		  }

	  }
	}
  }
}
/*
int tileSet::print( SDL_Surface *surface, Uint32 x, Uint32 y, const char *fmt, ... ) {
  char buffer[ MAX_TILESET_PRINT_LINE ];
  va_list args;
  va_start( args, fmt );
  vsprintf( buffer, fmt, args );
  //perror( buffer );
  va_end( args );

  for( int i = 0; buffer[ i ] != 0; i++ ) {
    apply_surface( x, y, tiles[ buffer[ i ] ], surface );
    x += tiles[ buffer[ i ] ]->w;
  }
  return strlen( buffer );
}
*/
int Window::print( tileSet *font, uchar planeNR, Uint32 x, Uint32 y, const char *fmt, ... ) {
  char buffer[ MAX_LINE ];
  va_list args;
  va_start( args, fmt );
  vsprintf( buffer, fmt, args );
  //perror( buffer );
  va_end( args );
  Uint32 alphaF = 0;
  if( planeNR == 0 ) alphaF = SDL_SRCALPHA;
  SDL_Rect offset;
  offset.x = x;
  offset.y = y;
  for( int i = 0; buffer[ i ] != 0; i++ ) {

	if( buffer[ i ] == '\n' ) {
	  offset.y += font->tiles[ buffer[ i ] ]->h;
      offset.x = x;
      continue;
    }


	SDL_SetAlpha( font->tiles[ buffer[ i ] ], alphaF, SDL_ALPHA_OPAQUE );
    SDL_BlitSurface( font->tiles[ buffer[ i ] ], NULL, planes[ planeNR ], &offset );
    offset.x += font->tiles[ buffer[ i ] ]->w;
  }
  return strlen( buffer );

}

int Window::print( tileSet *font, uchar planeNR, Uint32 x, Uint32 y, int spaceH, int spaceV, const char *fmt, ... )
{
  char buffer[ MAX_LINE ];
  va_list args;
  va_start( args, fmt );
  vsprintf( buffer, fmt, args );
  //perror( buffer );
  va_end( args );
  Uint32 alphaF = 0;
  if( planeNR == 0 ) alphaF = SDL_SRCALPHA;
  SDL_Rect offset;
  offset.x = x;
  offset.y = y;
  for( int i = 0; buffer[ i ] != 0; i++ ) {

	if( buffer[ i ] == '\n' ) {
	  offset.y += spaceV;
      offset.x = x;
      continue;
    }


	SDL_SetAlpha( font->tiles[ buffer[ i ] ], alphaF, SDL_ALPHA_OPAQUE );
    SDL_BlitSurface( font->tiles[ buffer[ i ] ], NULL, planes[ planeNR ], &offset );
    offset.x += spaceH;
  }
  return strlen( buffer );
}

int tileSet::merge( tileSet &ts ) {
  tiles.reserve( tiles.size() + ts.tiles.size() );
  tiles.insert( tiles.end(), ts.tiles.begin(), ts.tiles.end() );
  Uint32 added = ts.tiles.size();
  ts.tiles.clear();
//  delete &ts;
  return added;
}

void tileSet::copyTile( int index ) {
  SDL_Surface *ns = emptyPlane( tiles[ index ]->w, tiles[ index ]->h );
  SDL_SetAlpha( tiles[ index ], 0, SDL_ALPHA_OPAQUE ); //SDL_SRCALPHA
  SDL_BlitSurface( tiles[ index ], NULL, ns, NULL );

  tiles.push_back( ns );
}

void tileSet::simpleRotation( int index, int degree ) {
  if( index < 0 ) index = tiles.size() + index;
  SDL_Surface *r;
  Uint32 *pixels1 = (Uint32 *)tiles[ index ]->pixels;
  Uint32 *pixels2;

  if( degree == 180 ) {
    r = emptyPlane( tiles[ index ]->w, tiles[ index ]->h );
	pixels2 = (Uint32 *)r->pixels;
    for( int j = 0; j < tiles[ index ]->h; j++ ) {
	  int sRow = j * tiles[ index ]->w;
	  int dRow = (tiles[ index ]->h - 1 - j) * tiles[ index ]->w;
	  for( int k = 0; k < tiles[ index ]->w; k++ ) {
	    pixels2[ dRow + tiles[ index ]->w - 1 - k ] = pixels1[ sRow + k ];
	  }
	}
  }
  if( degree == 90 ) {
    r = emptyPlane( tiles[ index ]->h, tiles[ index ]->w );
	pixels2 = (Uint32 *)r->pixels;
    for( int j = 0; j < tiles[ index ]->h; j++ ) {
	  int sRow = j * tiles[ index ]->w;
	  for( int k = 0; k < tiles[ index ]->w; k++ ) {
	    pixels2[ k * r->w + (r->w - 1 - j) ] = pixels1[ sRow + k ];
	  }
	}
  }
  if( degree == -90 || degree == 270 ) {
    r = emptyPlane( tiles[ index ]->h, tiles[ index ]->w );
	pixels2 = (Uint32 *)r->pixels;
    for( int j = 0; j < tiles[ index ]->h; j++ ) {
	  int sRow = j * tiles[ index ]->w;
	  for( int k = 0; k < tiles[ index ]->w; k++ ) {
	    pixels2[ (r->h - 1 - k) * r->w + j ] = pixels1[ sRow + k ];
	  }
	}
  }

  SDL_FreeSurface( tiles[ index ] );
  tiles[ index ] = r;

}

void tileSet::mirror() {
  Uint32 ts = tiles.size();

  for( int i = 0; i < ts; i++ ) {
    Uint32 *pixels = (Uint32 *)tiles[ i ]->pixels;
	int halfW = tiles[ i ]->w / 2;

    for( int j = 0; j < tiles[ i ]->h; j++ ) {
	  for( int k = 0; k < halfW; k++ ) {
	    Uint32 swapTMP = pixels[ ( j * tiles[ i ]->w ) + k ];
		pixels[ ( j * tiles[ i ]->w ) + k ] = pixels[ ( j * tiles[ i ]->w ) + (tiles[ i ]->w - 1 - k) ];
		pixels[ ( j * tiles[ i ]->w ) + (tiles[ i ]->w - 1 - k) ] = swapTMP;

	  }
	}
  }

}

tileSequences::tileSequences() {
  actualSeq = 0;
  prevSeq = 0;
  prevFrame = 0;
  timing = 100;
  stop = false;
  endThread = true;
  x = 0;
  y = 0;
  movDX = prev_movDX = 0;
  movDY = prev_movDY = 0;
  //movAngle = -1;
  collided = false;
  collisionCheck = false;
  fullCollisionCheck = false;
  //touchCollisionCheck = false;
  //touched = false;
  endThreadAtCollision = true;
  stopAtCollision = true;
  eraseAtEndThread = false;
  useCounter = false;
  movCounterX = 0;
  movCounterY = 0;
 // useIdleCheck = false;
 // idleCounter = 0;
  type = 0;
  loopedAnimation = true;
  planeCollisionOffset = 0;
  refreshRender = true;
  collisionPercentage = 100;
  collisionX = collisionY = -1;
  //mimicMov = NULL;
  //useMovFunction = false;
 // movFunction = NULL;
  //usePointerToXY = false;
  //deleteAtEndThread = false;
}
void tileSequences::erase() {
  win->eraseFromPlane( ts->tiles[ sv[ actualSeq ]->currentFrame ], win->planes[ planeNR ], x, y );

  tileSequencesPushEvent( this, EVENT_TILESET_ANIMATION );

}

void tileSequences::createSeq() {
  /*sequence seq;
  seq.begin = 0;
  seq.end = ts->tiles.size() - 1;
  seq.currentFrame = 0;
  sv.push_back( seq );
  */
  sequence *seq = new sequence;
  seq->begin = 0;
  seq->end = ts->tiles.size() - 1;
  seq->currentFrame = 0;
  sv.push_back( seq );

}
void tileSequences::createSeq( int begin, int end ) {
 /* sequence seq;
  seq.begin = begin;
  seq.end = end;
  seq.currentFrame = begin;
  sv.push_back( seq );*/
  sequence *seq = new sequence;
  seq->begin = begin;
  seq->end = end;
  seq->currentFrame = begin;
  sv.push_back( seq );
}

void tileSequencesPushEvent( tileSequences *t, int event_code ) {
    SDL_Event event;
    event.type = SDL_USEREVENT;
    event.user.code = event_code;
    event.user.data1 = (void*)t;
    event.user.data2 = 0;
    SDL_PushEvent( &event );
}

bool tileSequences::onView() {
  int rbX = x + ts->tiles[ sv[ actualSeq ]->currentFrame ]->w;
  int rbY = y + ts->tiles[ sv[ actualSeq ]->currentFrame ]->h;
  if( rbX > win->bgPosX - 1 && x < win->bgPosX + win->winWidth + 1 && rbY > win->bgPosY - 1 && y < win->bgPosY + win->winHeight + 1 )
    return true;
  return false;
}

int *dxTable;
int *dyTable;
int tileSequencesThread( void *data ) {

  tileSequences *t = (tileSequences *)data;
  if( t->endThread == false ) return 0;
 // t->idleCountActual = t->idleCounter;

  t->collided = false;
  t->endThread = false;
  allThreads++;
  while( !t->endThread ) {
  //  if( t->movFunction != NULL ) t->movFunction( t );
    //printf( "[%d] (x:%d, y:%d) seq:%d prevSeq:%d prevFrame:%d\n", t->id, t->x, t->y, t->actualSeq, t->prevSeq, t->prevFrame );

/*	if( t->mimicMov != NULL ) {
	  t->x = t->mimicMov->x;
	  t->y = t->mimicMov->y;
	  t->prev_x = t->mimicMov->prev_x;
	  t->prev_y = t->mimicMov->prev_y;
	  t->movDX = t->mimicMov->movDX;
	  t->movDY = t->mimicMov->movDY;
	  t->prev_movDX = t->mimicMov->prev_movDX;
	  t->prev_movDY = t->mimicMov->prev_movDY;

	}*/
    if( t->x != t->prev_x || t->y != t->prev_y || t->prevSeq != t->actualSeq || t->prevFrame != t->sv[ t->actualSeq ]->currentFrame || (t->prev_movDX != t->movDX && t->movDX != 0) || (t->prev_movDY != t->movDY && t->movDY != 0) ) {

	//printf( "!! " );
	//  if( t->onView() || (!t->onView() && t->win->blitPlanesEvenNotOnView) ) {
	  t->win->eraseFromPlane( t->ts->tiles[ t->prevFrame ], t->win->planes[t->planeNR ], t->prev_x, t->prev_y );
	  //if( t->collided ) printf( "?? (%d %d) (%d %d) (%d %d) (%d %d)\n", t->x, t->prev_x, t->y, t->prev_y, t->prevSeq, t->actualSeq, t->prevFrame, t->sv[ t->actualSeq ]->currentFrame );
	  if( t->collisionCheck ) {
	    if( t->fullCollisionCheck )
	      t->overlapFull();
        else t->overlap();
        if( t->collided && t->stopAtCollision ) {
		    t->stop = true;
//			t->prev_movDX = t->movDX;
//			t->prev_movDY = t->movDY;
		    t->movDX = t->movDY = 0;

			t->x = t->prev_x;
			t->y = t->prev_y;
			t->actualSeq = t->prevSeq;
			t->sv[ t->actualSeq ]->currentFrame = t->prevFrame;

		  }
		  //t->win->drawOnPlane( t->ts->tiles[ t->prevFrame ], t->win->planes[ t->planeNR ], t->prev_x, t->prev_y );
          if( t->collided ) {
            /*if( t->fullCollisionCheck )
              tileSequencesPushEvent( t, EVENT_TILESET_COLLIDED_FULL );
            else tileSequencesPushEvent( t, EVENT_TILESET_COLLIDED );
            if( t->endThreadAtCollision ) { t->endThread = true;  }
          */
		    tileSequencesPushEvent( t, EVENT_TILESET_COLLIDED );
		  }
      }
	  t->win->drawOnPlane( t->ts->tiles[ t->sv[ t->actualSeq ]->currentFrame ], t->win->planes[ t->planeNR ], t->x, t->y );
	  //printf( "%d %d %d %d \n", t->sv[ 1 ].end, t->planeNR, t->x, t->y  );
	//  }
	  if( t->onView() ) { // && t->refreshRender )

		tileSequencesPushEvent( t, EVENT_TILESET_ANIMATION );  //
      }
	t->prev_x = t->x;
	t->prev_y = t->y;
	t->prevFrame = t->sv[ t->actualSeq ]->currentFrame;
	t->prevSeq = t->actualSeq;
//	t->prev_movDX = t->movDX;
//	t->prev_movDY = t->movDY;
//printf( "{%d %d} ", t->movDX,t->movDY );

	if( t->movDX != 0 || t->movDY != 0 ) {
			  if( t->useCounter ) {
	    //t->movCounterX--;
	    //t->movCounterY--;
//	    printf( "%d %d| ", t->movCounterX, t->movCounterY );
	    if( --t->movCounterX < 0 ) { t->movDX = 0; }
		if( --t->movCounterY < 0 ) { t->movDY = 0; }
        if( t->movCounterX < 0 && t->movCounterY < 0 ) {
		  t->memMovX = t->prev_movDX;
		  t->memMovY = t->prev_movDY;
          tileSequencesPushEvent( t, EVENT_TILESET_ENDED_MOVCOUNTER );


        /*  t->endThread = true;
		  t->stop = true;
		  break;*/
		}

	  }
	 // if( t->movDX != 0 )

	  t->prev_movDX = t->movDX;
    //  if( t->movDY != 0 )
	  t->prev_movDY = t->movDY;

	  if( t->x + t->movDX >= 0 && t->x + t->movDX + t->ts->tiles[ t->sv[ t->actualSeq ]->currentFrame ]->w <= t->win->planesWidth )
	    t->x += t->movDX;
	  else {
	    if( t->x + t->movDX < 0 )
	      t->x = 0;
        if( t->x + t->movDX + t->ts->tiles[ t->sv[ t->actualSeq ]->currentFrame ]->w > t->win->planesWidth )
	      t->x = t->win->planesWidth - t->ts->tiles[ t->sv[ t->actualSeq ]->currentFrame ]->w;
	    t->movDX = 0;
	    t->stop = true;
	    tileSequencesPushEvent( t, EVENT_TILESET_COLLIDED );
	    t->endThread = true;
	    break;
      }
	  if( t->y + t->movDY >= 0 && t->y + t->movDY + t->ts->tiles[ t->sv[ t->actualSeq ]->currentFrame ]->h <= t->win->planesHeight )
	    t->y += t->movDY;
	  else {
	    if( t->y + t->movDY < 0 )
	      t->y = 0;
        if( t->y + t->movDY + t->ts->tiles[ t->sv[ t->actualSeq ]->currentFrame ]->h > t->win->planesHeight )
	      t->y = t->win->planesHeight - t->ts->tiles[ t->sv[ t->actualSeq ]->currentFrame ]->h;
	    t->movDY = 0;
	    t->stop = true;
	    tileSequencesPushEvent( t, EVENT_TILESET_COLLIDED );
	    t->endThread = true;
	    break;
      }
	  /*else {
        if( t->y + t->movDY < 0 )
	      t->y = 0;
		else t->y = t->win->planesHeight - t->ts->tiles[ t->sv[ t->actualSeq ]->currentFrame ]->h;
	    t->movDY = 0;
		if( t->collisionCheck ) tileSequencesPushEvent( t, EVENT_TILESET_COLLIDED );
	  }*/
	  //t->moving = true;


	} //else t->moving = false;
	if( !t->stop ) {
	  //t->prevSeq = t->actualSeq;

	  if( t->sv[ t->actualSeq ]->currentFrame < t->sv[ t->actualSeq ]->end )
	    t->sv[ t->actualSeq ]->currentFrame++;
	  else {
	    if( t->loopedAnimation )
	      t->sv[ t->actualSeq ]->currentFrame = t->sv[ t->actualSeq ]->begin;
        else {
		  tileSequencesPushEvent( t, EVENT_TILESET_ANIMATION_ENDED_LOOP );
		  t->endThread = true;
		  t->stop = true;
		  break;
		}
	  }
	}

	//t->idleCountActual = t->idleCounter;
	} /*else {
	  if( t->useIdleCheck ) {

	    if( --t->idleCountActual < 0 ) { t->endThread = true; break; }
      } //else { t->endThread = true; break; }
	}*/
	SDL_Delay( t->timing );
	//printf("%d ", t->idleCountActual);
	/*if( t->collided ) {
  	  tileSequencesPushEvent( t, EVENT_TILESET_COLLIDED );
      t->collided = false;
	}*/
	//if( t->touchCollisionCheck )
      //if( t->borderTouch() ) tileSequencesPushEvent( t, EVENT_TILESET_TOUCHED );




  if( t->movDX == 0 && t->movDY == 0 && t->stop ) t->endThread = true;
  }
  if( t->eraseAtEndThread ) {
    t->win->eraseFromPlane( t->ts->tiles[ t->prevFrame ], t->win->planes[t->planeNR ], t->prev_x, t->prev_y );

	tileSequencesPushEvent( t, EVENT_TILESET_ANIMATION );
  }
  allThreads--;
  return 0;
}

void tileSequences::adjust() {
 // SDL_LockMutex( plane_mutex );
  //win->eraseFromPlane( ts->tiles[ prevFrame ], win->planes[ planeNR ], prev_x, prev_y );
  win->eraseFromPlane( true, ts->tiles[ prevFrame ], win->planes[ planeNR ], prev_x, prev_y );
  win->drawOnPlane( ts->tiles[ sv[ actualSeq ]->currentFrame ], win->planes[ planeNR ], x, y );
 // SDL_UnlockMutex( plane_mutex );

  tileSequencesPushEvent( this, EVENT_TILESET_ANIMATION );
}

void tileSequences::newThread() {

  SDL_Thread *t = SDL_CreateThread( tileSequencesThread, this );

}

bool tileSequences::overlap() {
  if( y < 0 || x < 0 ) { collided = true; return true; }
  SDL_Surface *plane = win->planes[ planeNR + planeCollisionOffset ];
  Uint32 *pixels1 = (Uint32 *)ts->tiles[ sv[ actualSeq ]->currentFrame ]->pixels;
  Uint32 *pixels2 = (Uint32 *)plane->pixels;
  int h = ts->tiles[ sv[ actualSeq ]->currentFrame ]->h;
  int w = ts->tiles[ sv[ actualSeq ]->currentFrame ]->w;

  for( int i = 0; i < h; i++ ) {
    int dRow = (i + y) * plane->w;
	int sRow = i * w;
    for( int j = 0; j < w; j++ ) {

	//printf( "0x%08x\n", pixels2[ dRow + j + x ] );
	//printf( "!!! 0x%08x 0x%08x\n", pixels1[ sRow + j ], pixels2[ dRow + j + x ] );
	  if( (pixels1[ sRow + j ] & 0xff) != 0x00 )
	    if( (pixels2[ dRow + j + x ] & 0xff) != 0x00 ) {
		//printf( "!!! 0x%08x 0x%08x\n", pixels1[ sRow + j ], pixels2[ dRow + j + x ] );
          if( collisionX == -1 || collisionY == -1 ) { collisionX = j + x; collisionY = i + y; }
		  collided = true;
          return true;

		}
	}
  }

  return false;
}


bool tileSequences::overlapFull() {
//printf( "$ ");

  if( y < 0 || x < 0 ) { collided = true; return true; }
  SDL_Surface *plane = win->planes[ planeNR + planeCollisionOffset ];
  Uint32 *pixels1 = (Uint32 *)ts->tiles[ sv[ actualSeq ]->currentFrame ]->pixels;
  Uint32 *pixels2 = (Uint32 *)plane->pixels;
  int h = ts->tiles[ sv[ actualSeq ]->currentFrame ]->h;
  int w = ts->tiles[ sv[ actualSeq ]->currentFrame ]->w;

  if( collisionPercentage >= 100 ) {
  for( int i = 0; i < h; i++ ) {
    int dRow = (i + y) * plane->w;
	int sRow = i * w;
    for( int j = 0; j < w; j++ ) {

	//printf( "!!! 0x%08x 0x%08x\n", pixels1[ sRow + j ], pixels2[ dRow + j + x ] );
      if( (pixels1[ sRow + j ] & 0xff) == 0xff ) {
       // printf( "!!! 0x%08x 0x%08x\n", pixels1[ sRow + j ], pixels2[ dRow + j + x ] );
	    if( (pixels2[ dRow + j + x ] & 0xff) == 0x00 ) {
		//printf( "!!! 0x%08x 0x%08x\n", pixels1[ sRow + j ], pixels2[ dRow + j + x ] );
          collided = false;
          return false;

		} else if( collisionX == -1 || collisionY == -1 ) { collisionX = j + x; collisionY = i + y; }


     }
		//printf( "(%d, %d) ", x+j, y+i );
	}
  }

  collided = true;
  return true;
  } else {
    int collidedSum = 0, allPixels = 0;
    for( int i = 0; i < h; i++ ) {
    int dRow = (i + y) * plane->w;
	int sRow = i * w;
    for( int j = 0; j < w; j++ ) {

	//printf( "!!! 0x%08x 0x%08x\n", pixels1[ sRow + j ], pixels2[ dRow + j + x ] );
      if( (pixels1[ sRow + j ] & 0xff) == 0xff ) {
	    allPixels++;
       // printf( "!!! 0x%08x 0x%08x\n", pixels1[ sRow + j ], pixels2[ dRow + j + x ] );
	    if( (pixels2[ dRow + j + x ] & 0xff) != 0x00 ) {
		//printf( "!!! 0x%08x 0x%08x\n", pixels1[ sRow + j ], pixels2[ dRow + j + x ] );
          if( collisionX == -1 || collisionY == -1 ) { collisionX = j + x; collisionY = i + y; }

		  collidedSum++;


		}
     }
		//printf( "(%d, %d) ", x+j, y+i );
	}
  }
  //printf( " {%d} ", (int)((float)(collidedSum) / allPixels * 100) );
  if( (int)((float)(collidedSum) / allPixels * 100) >= collisionPercentage ) {
    collided = true;
//	printf( " [%d] ", (int)((float)(collidedSum) / allPixels * 100) );
    return true;
  } else { collided = false; return false; }
  }
}

void windowPushEvent( Window *w, int event_code ) {
    SDL_Event event;
    event.type = SDL_USEREVENT;
    event.user.code = event_code;
    event.user.data1 = (void*)w;
    event.user.data2 = 0;
    SDL_PushEvent( &event );
}

int scrollWindowThread( void *data ) {
  Window *w = (Window *)data;
  Uint8 *keystate;
  if( w->actualScroll ) return 0;
  //int sDelta = SCROLL_DELTA;
  w->actualScroll = true;
  int savedBgPosX = w->bgPosX, savedBgPosY = w->bgPosY;
  while( true ) {
  bool s = false;

    keystate = SDL_GetKeyState( NULL );
	//if( keystate[ SDLK_RCTRL ] || keystate[ SDLK_LCTRL ] ) {
	if( keystate[ SDLK_SPACE ] ) {
	  if( w->scrollH && keystate[ SDLK_RIGHT ] ) { if( w->bgPosX + w->winWidth + SCROLL_DELTA < w->planesWidth ) w->bgPosX += SCROLL_DELTA; else w->bgPosX = w->planesWidth - w->winWidth; s = true; }
      if( w->scrollH && keystate[ SDLK_LEFT ] ) { if( w->bgPosX - SCROLL_DELTA > 0 ) w->bgPosX -= SCROLL_DELTA; else w->bgPosX = 0; s = true; }
	  if( w->scrollV && keystate[ SDLK_UP ] ) { if( w->bgPosY - SCROLL_DELTA > 0 ) w->bgPosY -= SCROLL_DELTA; else w->bgPosY = 0; s = true; }
	  if( w->scrollV && keystate[ SDLK_DOWN ] ) { if( w->bgPosY + w->winHeight + SCROLL_DELTA < w->planesHeight ) w->bgPosY += SCROLL_DELTA; else w->bgPosY = w->planesHeight - w->winHeight; s = true; }

	  if( s ) {

	    windowPushEvent( w, EVENT_WINDOW_SCROLL );
		//w->redrawAllPlanes();


      }
       SDL_Delay( SCROLL_DELAY );
       continue;
    }
  break;
  }

  w->bgPosX = savedBgPosX;
  w->bgPosY = savedBgPosY;

  windowPushEvent( w, EVENT_WINDOW_SCROLL );
  //w->redrawAllPlanes();
  w->actualScroll = false;
  return 0;
}
/*void Window::scroll() {
  SDL_Thread *t = SDL_CreateThread( scrollWindowThread, this );

}*/

Window::Window() {
  actualScroll = false;
 // blitPlanesEvenNotOnView = true;
 // redrawAllView = false;
  winPosX = winPosY = bgPosX = bgPosY = regularPlanesNR = 0;

}

void Window::associate( uchar planeNR, tileSequences *t, int seqNR, Uint32 sx, Uint32 sy, int timing ) {
  t->win = this;
  //t->sv.resize( sv.size() );
  //t->sv.swap( sv );
  t->actualSeq = seqNR;
  t->prevSeq = -1;
  t->prevFrame = t->sv[ seqNR ]->begin;
  t->planeNR = planeNR;
  t->x = sx;
  t->y = sy;
  t->prev_x = sx;
  t->prev_y = sy;
  t->timing = timing;
  t->prev_timing = 0;
  t->prev_movDX = 0;
  t->prev_movDY = 0;

}
/*
void Window::drawBackground() {
  SDL_Rect s;
  s.w = winWidth;
  s.h = winHeight;
  s.x = bgPosX;
  s.y = bgPosY;
  SDL_Rect d;
  d.w = winWidth;
  d.h = winHeight;
  d.x = winPosX;
  d.y = winPosY;

  SDL_BlitSurface( background, &s, scr, &d );
}
*/

void Window::redrawPlane( SDL_Surface *plane, Uint32 x, Uint32 y, int w, int h ) {

  Uint32 rbX = x + w;
  Uint32 rbY = y + h;

if( rbX > bgPosX && x < bgPosX + winWidth && rbY > bgPosY  && y < bgPosY + winHeight ) {


  int tileWidth = w;
  int tileHeight = h;
  SDL_Rect s, d;

  s.y = y;
  d.y = y + (winPosY - bgPosY);
  s.x = x;
  d.x = x + (winPosX - bgPosX);
  if( bgPosX > x && bgPosX < rbX ) {

	tileWidth = rbX - bgPosX;
	s.x = x + (bgPosX - x);
	d.x = x + (bgPosX - x) + (winPosX - bgPosX);
  }
  if( bgPosX + winWidth > x && bgPosX + winWidth < rbX ) {

	tileWidth = bgPosX + winWidth - x;
    s.x = x;
	d.x = x + (winPosX - bgPosX);
  }
  if( bgPosY > y && bgPosY < rbY ) {

	tileHeight = rbY - bgPosY;
    s.y = y + (bgPosY - y);
	d.y = y + (bgPosY - y) + (winPosY - bgPosY);
  }
  if( bgPosY + winHeight > y && bgPosY + winHeight < rbY ) {

	tileHeight = bgPosY + winHeight - y;
    s.y = y;
	d.y = y + (winPosY - bgPosY);
  }


  s.w = tileWidth;
  s.h = tileHeight;
  d.w = tileWidth;
  d.h = tileHeight;

  //printf( "%d %d; %d %d; %d %d\n", s.x, s.y, d.x, d.y, d.w, d.h );
  //SDL_LockMutex( plane_mutex );
  SDL_SetAlpha( plane, SDL_SRCALPHA, SDL_ALPHA_OPAQUE );
  //SDL_SetAlpha( plane, 0, SDL_ALPHA_OPAQUE );

  SDL_BlitSurface( plane, &s, MainScreen, &d );


}
}

void Window::redrawPlane( SDL_Surface *plane, Uint32 x, Uint32 y, int w, int h, int &in_winX, int &in_winY, int &in_winW, int &in_winH ) {

  Uint32 rbX = x + w;
  Uint32 rbY = y + h;

if( rbX > bgPosX && x < bgPosX + winWidth && rbY > bgPosY  && y < bgPosY + winHeight ) {


  int tileWidth = w;
  int tileHeight = h;
  SDL_Rect s, d;

  s.y = y;
  d.y = y + (winPosY - bgPosY);
  s.x = x;
  d.x = x + (winPosX - bgPosX);
  if( bgPosX > x && bgPosX < rbX ) {

	tileWidth = rbX - bgPosX;
	s.x = x + (bgPosX - x);
	d.x = x + (bgPosX - x) + (winPosX - bgPosX);
  }
  if( bgPosX + winWidth > x && bgPosX + winWidth < rbX ) {

	tileWidth = bgPosX + winWidth - x;
    s.x = x;
	d.x = x + (winPosX - bgPosX);
  }
  if( bgPosY > y && bgPosY < rbY ) {

	tileHeight = rbY - bgPosY;
    s.y = y + (bgPosY - y);
	d.y = y + (bgPosY - y) + (winPosY - bgPosY);
  }
  if( bgPosY + winHeight > y && bgPosY + winHeight < rbY ) {

	tileHeight = bgPosY + winHeight - y;
    s.y = y;
	d.y = y + (winPosY - bgPosY);
  }


  s.w = tileWidth;
  s.h = tileHeight;
  d.w = tileWidth;
  d.h = tileHeight;

  //printf( "%d %d; %d %d; %d %d\n", s.x, s.y, d.x, d.y, d.w, d.h );
  //SDL_LockMutex( plane_mutex );
  SDL_SetAlpha( plane, SDL_SRCALPHA, SDL_ALPHA_OPAQUE );
  //SDL_SetAlpha( plane, 0, SDL_ALPHA_OPAQUE );

  SDL_BlitSurface( plane, &s, MainScreen, &d );

  in_winX = d.x;
  in_winY = d.y;
  in_winW = d.w;
  in_winH = d.h;


}
}


void Window::drawOnPlane( SDL_Surface *source, SDL_Surface *destination, int x, int y ) {
if( x >= 0 && y >= 0 ) {

  //SDL_SetAlpha( destination, SDL_SRCALPHA, SDL_ALPHA_OPAQUE );
  Uint32 *pixels1 = (Uint32 *)source->pixels;
  Uint32 *pixels2 = (Uint32 *)destination->pixels;
  SDL_LockMutex( plane_mutex );
  for( int i = 0; i < source->h; i++ ) {
    int dRow = (i + y) * destination->w;
	int sRow = i * source->w;
    for( int j = 0; j < source->w; j++ ) {
	  if( (pixels1[ sRow + j ] & 0xff) != 0 )
	    pixels2[ dRow + j + x ] = pixels1[ sRow + j ];
	}
  }

  SDL_UnlockMutex( plane_mutex );

}

}

void Window::eraseFromPlane( SDL_Surface *source, SDL_Surface *plane, int x, int y ) {
  if( x >= 0 && y >= 0 ) {

  Uint32 *pixels1 = (Uint32 *)source->pixels;
  Uint32 *pixels2 = (Uint32 *)plane->pixels;
  SDL_LockMutex( plane_mutex );
  for( int i = 0; i < source->h; i++ ) {
    int dRow = (i + y) * plane->w;
	int sRow = i * source->w;
    for( int j = 0; j < source->w; j++ ) {
	  if( (pixels1[ sRow + j ] & 0xff) != 0 )
	    pixels2[ dRow + j + x ] = 0;
	}
  }
  SDL_UnlockMutex( plane_mutex );

  }
}
void Window::eraseFromPlane( bool all, SDL_Surface *source, SDL_Surface *plane, int x, int y ) {
  if( x >= 0 && y >= 0 ) {

  Uint32 *pixels1 = (Uint32 *)source->pixels;
  Uint32 *pixels2 = (Uint32 *)plane->pixels;
  SDL_LockMutex( plane_mutex );
  for( int i = 0; i < source->h; i++ ) {
    int dRow = (i + y) * plane->w;
	int sRow = i * source->w;
    for( int j = 0; j < source->w; j++ ) {
	  if( (pixels1[ sRow + j ] & 0xff) != 0 || all )
	    pixels2[ dRow + j + x ] = 0;
	}
  }
  SDL_UnlockMutex( plane_mutex );

  }
}

void Window::eraseFromPlane( int w, int h, SDL_Surface *plane, int x, int y ) {
  if( x >= 0 && y >= 0 ) {

  Uint32 *pixels2 = (Uint32 *)plane->pixels;
  SDL_LockMutex( plane_mutex );
  for( int i = 0; i < h; i++ ) {
    int dRow = (i + y) * plane->w;
	int sRow = i * w;
    for( int j = 0; j < w; j++ ) {

	    pixels2[ dRow + j + x ] = 0;
	}
  }
  SDL_UnlockMutex( plane_mutex );

  }
}

void Window::redrawAllPlanes() {
  SDL_Rect s;
  s.w = winWidth;
  s.h = winHeight;
  s.x = bgPosX;
  s.y = bgPosY;
  SDL_Rect d;
  d.w = winWidth;
  d.h = winHeight;
  d.x = winPosX;
  d.y = winPosY;
  //int pNR = planes.size();
  SDL_LockMutex( plane_mutex );
  for( int i = 0; i < regularPlanesNR; i++ ) {
    SDL_BlitSurface( planes[ i ], &s, MainScreen, &d );
  }
  SDL_UnlockMutex( plane_mutex );
  SDL_UpdateRect( MainScreen, d.x, d.y, d.w, d.h );
}



void tileSequences::redraw() {


  if( sv.size() == 0 ) return;
  if( ts == NULL ) return;
  if( ts->tiles.size() == 0 ) return;
  if( actualSeq < 0 || actualSeq >= sv.size() ) return;
  if( sv[ actualSeq ]->currentFrame < 0 || sv[ actualSeq ]->currentFrame >= ts->tiles.size() ) return;
  //int pw = t->ts->tiles[ t->prevFrame ]->w;
  //int ph = t->ts->tiles[ t->prevFrame ]->h;
  int w = ts->tiles[ sv[ actualSeq ]->currentFrame ]->w;
  int h = ts->tiles[ sv[ actualSeq ]->currentFrame ]->h;
  int x_ = x, deltaWidth = 0;
  int y_ = y, deltaHeight = 0;

  if( x < prev_x ) {

	w = prev_x + w - x;

  } else {

	w = x + w - prev_x;
	x_ = prev_x;
  }
  if( y < prev_y ) {

	h = prev_y + h - y;

  } else {

	h = y + h - prev_y;
	y_ = prev_y;
  }

  /*if( redrawAllView ) {
    pw = w = winWidth;
    ph = h = winHeight;
	px = x = bgPosX;
	py = y = bgPosY;
  }else {*/
    y_ -= REDRAW_MOD_PX;
	if( y_ < 0 ) y_ = 0;
    h += REDRAW_MOD_PX << 1;

    x_ -= REDRAW_MOD_PX;
    if( x_ < 0 ) x_ = 0;
    w += REDRAW_MOD_PX << 1;


  //printf( "//%d %d//", y, py );

  int in_winX, in_winY, in_winW, in_winH;
  if( win == NULL ) return;
  //SDL_LockMutex( plane_mutex );
  for( int i = 0; i < win->regularPlanesNR; i++ )
    win->redrawPlane( win->planes[ i ], x_, y_, w, h, in_winX, in_winY, in_winW, in_winH );
  //SDL_UnlockMutex( plane_mutex );
  SDL_UpdateRect( MainScreen, in_winX, in_winY, in_winW, in_winH );

}
int deleteTileSeq( void *data ) {
  tileSequences *t = (tileSequences *)data;
  SDL_Delay( t->timing );
  while( t->endThread == false ) {
    t->endThread = true;
	SDL_Delay( t->timing + 1000 );
 //   printf( "$ " );
  }
  t->sv.clear();
  delete t;
  t = NULL;
  return 0;
}

void Window::setWindowBgPos( int x, int y ) {
  bgPosX = x;
  bgPosY = y;
  //windowPushEvent( this, EVENT_WINDOW_SCROLL );
  redrawAllPlanes();
}

void Window::checkWindowBgPos( int xpos, int ypos, int movX, int movY ) {
//  if( movX == 0 && movY == 0 ) return;
  int x_in_win = xpos - bgPosX;
  int y_in_win = ypos - bgPosY;
  int setX, setY;
  if( scrollH ) {
  if( movX < 0 ) {
    if( x_in_win < marginX && bgPosX > 0 ) {
	  setX = xpos - winWidth / 2;
	  setY = bgPosY;
	  if( setX < 0 ) setX = 0;
	  setWindowBgPos( setX, setY );
	  return;
	}
  } else if( movX > 0 ) {
    if( x_in_win > winWidth - marginX && bgPosX < planes[ 0 ]->w - winWidth ) {
	  setX = xpos - winWidth / 2;
	  setY = bgPosY;
	  if( setX > planes[ 0 ]->w - winWidth ) setX = planes[ 0 ]->w - winWidth;
	  setWindowBgPos( setX, setY );
	  return;
	}
  }
  }
  if( scrollV ) {
  if( movY < 0 ) {
    if( y_in_win < marginY && bgPosY > 0 ) {
	  setY = ypos - winHeight / 2;
	  setX = bgPosX;
	  if( setY < 0 ) setY = 0;
	  setWindowBgPos( setX, setY );
	  return;
	}
  } else if( movY > 0 ) {
    if( y_in_win > winHeight - marginY && bgPosY < planes[ 0 ]->h - winHeight ) {
	  setY = ypos - winHeight / 2;
	  setX = bgPosX;
	  if( setY > planes[ 0 ]->h - winHeight ) setY = planes[ 0 ]->h - winHeight;
	  setWindowBgPos( setX, setY );
	  return;
	}
  }
  }

}

void Window::centerWindowBg( int x, int y ) {
  int setX = x - winWidth / 2 , setY = y - winHeight / 2;
  if( !scrollH ) setX = bgPosX;
  if( !scrollV ) setY = bgPosY;

  if( setX > planes[ 0 ]->w - winWidth && x > winWidth ) setX = planes[ 0 ]->w - winWidth;
  if( setY > planes[ 0 ]->h - winHeight && y > winHeight ) setY = planes[ 0 ]->h - winHeight;
  if( setX < 0 ) setX = 0;
  if( setY < 0 ) setY = 0;
  setWindowBgPos( setX, setY );
}

void makeGrid( int x, int y, SDL_Surface *ds, int width, int height, int rows, int cols, int border, Uint32 borderColor ) {
  Uint32 *pixels = (Uint32 *)ds->pixels;
  int endY = height * rows + border;
  int endX = width * cols + border;

  for( int i = 0; i < endY; i++ ) {
	int row = (i + y) * ds->w;
    for( int j = 0; j < endX; j++ ) {
	  bool g = false;
	  for( int k = 0; k < border; k++ ) {
	    if( !((j - k) % width) ) g = true;
		if( !((i - k) % height) ) g = true;
		if( j == endX - 1 - k ) g = true;
		if( i == endY - 1 - k ) g = true;

	  }
	  if( g )
	    pixels[ row + j + x ] = borderColor;

	}
  }

}

/*
void ScaleLine(Uint32 *Target, Uint32 *Source, int SrcWidth, int TgtWidth)
{
  int NumPixels = TgtWidth;
  int IntPart = SrcWidth / TgtWidth;
  int FractPart = SrcWidth % TgtWidth;
  int E = 0;

  while (NumPixels-- > 0) {
    *Target++ = *Source;
    Source += IntPart;
    E += FractPart;
    if (E >= TgtWidth) {
      E -= TgtWidth;
      Source++;
    }
  }
}

void ScaleRect( Uint32 *Target, Uint32 *Source, int SrcWidth, int SrcHeight, int TgtWidth, int TgtHeight)
{
  int NumPixels = TgtHeight;
  int IntPart = (SrcHeight / TgtHeight) * SrcWidth;
  int FractPart = SrcHeight % TgtHeight;
  int E = 0;
  Uint32 *PrevSource = NULL;

  while (NumPixels-- > 0) {
    if (Source == PrevSource) {
      memcpy(Target, Target-TgtWidth, TgtWidth*sizeof(*Target));
    } else {
      ScaleLine(Target, Source, SrcWidth, TgtWidth);
      PrevSource = Source;
    }
    Target += TgtWidth;
    Source += IntPart;
    E += FractPart;
    if (E >= TgtHeight) {
      E -= TgtHeight;
      Source += SrcWidth;
    }
  }
}
*/
